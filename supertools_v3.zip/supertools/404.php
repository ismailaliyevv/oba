<?php
http_response_code(404);
$siteName = 'SuperTools';
try { require_once __DIR__.'/admin/includes/config.php'; $siteName=ST_Settings::get('site_name','SuperTools'); } catch(Exception $e){}
?>
<!DOCTYPE html>
<html><head><meta charset="UTF-8"><title>404 — <?= htmlspecialchars($siteName) ?></title>
<style>body{font-family:sans-serif;background:#0f172a;color:#fff;display:flex;align-items:center;justify-content:center;min-height:100vh;text-align:center;padding:20px;} h1{font-size:80px;margin-bottom:16px;} p{color:rgba(255,255,255,.5);margin-bottom:24px;} a{padding:12px 28px;background:#6366f1;color:#fff;border-radius:10px;text-decoration:none;font-weight:700;}</style>
</head><body><div><h1>404</h1><p>Page not found.</p><a href="index.php">Go Home</a></div></body></html>
