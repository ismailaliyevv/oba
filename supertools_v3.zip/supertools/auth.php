<?php
require_once __DIR__ . '/admin/includes/config.php';

UserAuth::start();
$lang = Lang::detect();
Lang::load($lang);

$action = $_GET['action'] ?? 'login';
$error  = '';
$success= '';

$siteName   = ST_Settings::get('site_name', 'SuperTools');
$themeColor = ST_Settings::get('theme_color', '#6366f1');
$logoIcon   = ST_Settings::get('logo_icon', '⚡');

// Logout
if ($action === 'logout') {
    UserAuth::logout();
    header('Location: index.php'); exit;
}

// Already logged in
if (UserAuth::check() && in_array($action, ['login','register'])) {
    header('Location: profile.php'); exit;
}

// Profile requires login
if ($action === 'profile' && !UserAuth::check()) {
    header('Location: auth.php?action=login'); exit;
}

// ── POST ──
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if ($action === 'login') {
        $email = trim($_POST['email'] ?? '');
        $pass  = $_POST['password'] ?? '';
        if (!$email || !$pass) { $error = 'Please fill all fields.'; }
        else {
            $u = DB::fetch("SELECT * FROM users WHERE email=? AND status='active'", [$email]);
            if (!$u || !password_verify($pass, $u['password'] ?? '')) {
                $error = 'Invalid email or password.';
            } else {
                UserAuth::login($u);
                $redirect = $_GET['redirect'] ?? 'profile.php';
                header('Location: '.$redirect); exit;
            }
        }
    }

    elseif ($action === 'register') {
        $name  = sanitize($_POST['name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $pass  = $_POST['password'] ?? '';
        $pass2 = $_POST['password2'] ?? '';
        if (!$name || !$email || !$pass) { $error = 'All fields are required.'; }
        elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) { $error = 'Invalid email address.'; }
        elseif (strlen($pass) < 6) { $error = 'Password must be at least 6 characters.'; }
        elseif ($pass !== $pass2) { $error = 'Passwords do not match.'; }
        else {
            $exists = DB::fetch("SELECT id FROM users WHERE email=?", [$email]);
            if ($exists) { $error = 'Email already registered.'; }
            else {
                $plan = (int)($_GET['plan'] ?? 1);
                $id = DB::insert('users', [
                    'name'       => $name,
                    'email'      => $email,
                    'password'   => password_hash($pass, PASSWORD_BCRYPT, ['cost'=>12]),
                    'plan_id'    => $plan ?: 1,
                    'status'     => 'active',
                    'lang'       => $lang,
                    'joined_ip'  => get_client_ip(),
                    'created_at' => date('Y-m-d H:i:s'),
                ]);
                UserAuth::login(['id'=>$id,'email'=>$email,'name'=>$name]);
                header('Location: profile.php'); exit;
            }
        }
    }

    elseif ($action === 'forgot') {
        $email = trim($_POST['email'] ?? '');
        $u = DB::fetch("SELECT id FROM users WHERE email=?", [$email]);
        if ($u) {
            $token = bin2hex(random_bytes(32));
            DB::query("UPDATE users SET reset_token=?, reset_expires=DATE_ADD(NOW(),INTERVAL 1 HOUR) WHERE id=?", [$token, $u['id']]);
            $resetLink = BASE_URL.'/auth.php?action=reset&token='.$token;
            send_email($email, 'Password Reset — '.$siteName,
                "<p>Click to reset your password: <a href='$resetLink'>$resetLink</a></p>");
        }
        $success = 'If that email exists, a reset link has been sent.';
    }

    elseif ($action === 'reset') {
        $token = sanitize($_GET['token'] ?? '');
        $pass  = $_POST['password'] ?? '';
        $pass2 = $_POST['password2'] ?? '';
        if ($pass !== $pass2 || strlen($pass) < 6) { $error = 'Passwords must match and be 6+ chars.'; }
        else {
            $u = DB::fetch("SELECT id FROM users WHERE reset_token=? AND reset_expires>NOW()", [$token]);
            if (!$u) { $error = 'Invalid or expired reset link.'; }
            else {
                DB::query("UPDATE users SET password=?, reset_token=NULL, reset_expires=NULL WHERE id=?",
                    [password_hash($pass, PASSWORD_BCRYPT, ['cost'=>12]), $u['id']]);
                $success = 'Password updated! You can now log in.';
                $action = 'login';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="<?= esc($lang) ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= ucfirst($action) ?> — <?= esc($siteName) ?></title>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=DM+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
:root{--accent:<?= esc($themeColor) ?>;--dark:#0f172a;--dark2:#1e293b;--border:#e5e7eb;--text:#111827;--muted:#6b7280;--inp:#f9fafb;}
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:'DM Sans',sans-serif;background:var(--dark);min-height:100vh;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:24px;position:relative;overflow:hidden;}
body::before{content:'';position:absolute;inset:0;background:radial-gradient(ellipse 70% 60% at 50% -10%,color-mix(in srgb,var(--accent) 30%,transparent),transparent 70%);pointer-events:none;}
.logo-wrap{text-align:center;margin-bottom:32px;position:relative;}
.logo-mark{width:52px;height:52px;background:var(--accent);border-radius:14px;display:flex;align-items:center;justify-content:center;font-size:26px;margin:0 auto 12px;}
.logo-name{font-family:'Syne',sans-serif;font-size:24px;font-weight:800;color:#fff;}
.box{background:rgba(255,255,255,.04);backdrop-filter:blur(20px);border:1px solid rgba(255,255,255,.1);border-radius:20px;padding:36px 32px;width:100%;max-width:420px;position:relative;}
.box::before{content:'';position:absolute;top:0;left:0;right:0;height:2px;background:linear-gradient(90deg,var(--accent),color-mix(in srgb,var(--accent) 50%,white));border-radius:20px 20px 0 0;}
h2{font-family:'Syne',sans-serif;font-size:22px;font-weight:800;color:#fff;margin-bottom:4px;}
.sub{font-size:13px;color:rgba(255,255,255,.5);margin-bottom:24px;}
.form-group{margin-bottom:16px;}
label{display:block;font-size:12px;font-weight:600;color:rgba(255,255,255,.5);text-transform:uppercase;letter-spacing:.5px;margin-bottom:7px;}
input{width:100%;padding:12px 14px;background:rgba(255,255,255,.07);border:1.5px solid rgba(255,255,255,.12);border-radius:9px;color:#fff;font-family:'DM Sans',sans-serif;font-size:14px;outline:none;transition:.2s;}
input:focus{border-color:var(--accent);background:rgba(255,255,255,.1);}
input::placeholder{color:rgba(255,255,255,.3);}
.btn{width:100%;padding:13px;background:var(--accent);color:#fff;border:none;border-radius:10px;font-family:'DM Sans',sans-serif;font-size:14px;font-weight:700;cursor:pointer;transition:.2s;margin-top:4px;}
.btn:hover{opacity:.9;transform:translateY(-1px);}
.alert{padding:11px 14px;border-radius:9px;font-size:13px;margin-bottom:16px;display:flex;align-items:center;gap:8px;}
.alert.error{background:rgba(239,68,68,.15);border:1px solid rgba(239,68,68,.3);color:#fca5a5;}
.alert.success{background:rgba(34,197,94,.12);border:1px solid rgba(34,197,94,.25);color:#86efac;}
.switch{text-align:center;margin-top:20px;font-size:13px;color:rgba(255,255,255,.4);}
.switch a{color:var(--accent);font-weight:600;text-decoration:none;}
.switch a:hover{text-decoration:underline;}
.divider{display:flex;align-items:center;gap:12px;margin:20px 0;font-size:12px;color:rgba(255,255,255,.3);}
.divider::before,.divider::after{content:'';flex:1;height:1px;background:rgba(255,255,255,.1);}
.back-link{display:block;text-align:center;margin-top:16px;font-size:13px;color:rgba(255,255,255,.4);text-decoration:none;}
.back-link:hover{color:rgba(255,255,255,.7);}
</style>
</head>
<body>
<div class="logo-wrap">
  <div class="logo-mark"><?= esc($logoIcon) ?></div>
  <div class="logo-name"><?= esc($siteName) ?></div>
</div>

<div class="box">
  <?php if($error): ?>
  <div class="alert error">⚠️ <?= esc($error) ?></div>
  <?php endif; ?>
  <?php if($success): ?>
  <div class="alert success">✅ <?= esc($success) ?></div>
  <?php endif; ?>

  <?php if($action === 'login'): ?>
  <h2>Welcome back</h2>
  <div class="sub">Sign in to your account</div>
  <form method="POST">
    <div class="form-group"><label>Email</label><input name="email" type="email" placeholder="you@example.com" value="<?= esc($_POST['email']??'') ?>" required autofocus></div>
    <div class="form-group"><label>Password</label><input name="password" type="password" placeholder="••••••••" required></div>
    <button class="btn">Sign in →</button>
  </form>
  <div class="switch">
    <a href="auth.php?action=forgot" style="color:rgba(255,255,255,.4)">Forgot password?</a>
    &nbsp;·&nbsp; No account? <a href="auth.php?action=register">Sign up free</a>
  </div>

  <?php elseif($action === 'register'): ?>
  <h2>Create account</h2>
  <div class="sub">Free · No credit card required</div>
  <form method="POST">
    <div class="form-group"><label>Full Name</label><input name="name" placeholder="Your name" value="<?= esc($_POST['name']??'') ?>" required autofocus></div>
    <div class="form-group"><label>Email</label><input name="email" type="email" placeholder="you@example.com" value="<?= esc($_POST['email']??'') ?>" required></div>
    <div class="form-group"><label>Password</label><input name="password" type="password" placeholder="Min 6 characters" required></div>
    <div class="form-group"><label>Confirm Password</label><input name="password2" type="password" placeholder="Repeat password" required></div>
    <button class="btn">Create Account →</button>
  </form>
  <div class="switch">Have an account? <a href="auth.php?action=login">Sign in</a></div>

  <?php elseif($action === 'forgot'): ?>
  <h2>Reset Password</h2>
  <div class="sub">Enter your email and we'll send a reset link</div>
  <form method="POST">
    <div class="form-group"><label>Email</label><input name="email" type="email" placeholder="you@example.com" required autofocus></div>
    <button class="btn">Send Reset Link →</button>
  </form>
  <div class="switch"><a href="auth.php?action=login">← Back to login</a></div>

  <?php elseif($action === 'reset'): ?>
  <h2>New Password</h2>
  <div class="sub">Set your new password below</div>
  <form method="POST">
    <div class="form-group"><label>New Password</label><input name="password" type="password" placeholder="Min 6 characters" required></div>
    <div class="form-group"><label>Confirm Password</label><input name="password2" type="password" placeholder="Repeat password" required></div>
    <button class="btn">Update Password →</button>
  </form>
  <?php endif; ?>
</div>

<a href="index.php" class="back-link">← Back to <?= esc($siteName) ?></a>
</body>
</html>
