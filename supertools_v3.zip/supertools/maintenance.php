<?php
http_response_code(503);
$siteName = 'SuperTools';
try { $siteName=ST_Settings::get('site_name','SuperTools'); } catch(Exception $e){}
?>
<!DOCTYPE html>
<html><head><meta charset="UTF-8"><title>Maintenance — <?= htmlspecialchars($siteName) ?></title>
<style>body{font-family:sans-serif;background:#0f172a;color:#fff;display:flex;align-items:center;justify-content:center;min-height:100vh;text-align:center;padding:20px;} h1{font-size:40px;font-weight:800;margin-bottom:12px;} p{color:rgba(255,255,255,.5);}</style>
</head><body><div><h1>🚧 Under Maintenance</h1><p>We'll be back shortly. Thank you for your patience.</p></div></body></html>
