<?php
/**
 * SuperTools — Auto Installer
 */
if (file_exists(__DIR__ . '/installed.lock')) {
    die('<h2 style="font-family:sans-serif;color:#e11d48;padding:40px">Already installed. Delete <code>installed.lock</code> to reinstall.</h2>');
}

$step = (int)($_POST['step'] ?? 0);
$errors = [];
$success = [];

function test_db(string $host, string $port, string $name, string $user, string $pass): ?PDO {
    try {
        $dsn = "mysql:host=$host;port=$port;charset=utf8mb4";
        $pdo = new PDO($dsn, $user, $pass, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
        return $pdo;
    } catch (Exception $e) { return null; }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>SuperTools Installer</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:'Segoe UI',sans-serif;background:linear-gradient(135deg,#0f0c29,#302b63,#24243e);min-height:100vh;display:flex;align-items:center;justify-content:center;padding:20px}
.box{background:#fff;border-radius:20px;padding:40px;width:100%;max-width:600px;box-shadow:0 32px 80px rgba(0,0,0,.4)}
.logo{text-align:center;margin-bottom:32px}
.logo h1{font-size:32px;font-weight:900;background:linear-gradient(135deg,#6366f1,#8b5cf6);-webkit-background-clip:text;-webkit-text-fill-color:transparent}
.logo p{color:#6b7280;font-size:14px;margin-top:4px}
.steps{display:flex;gap:8px;margin-bottom:32px}
.step{flex:1;height:4px;border-radius:4px;background:#e5e7eb}
.step.done{background:#6366f1}
.step.active{background:linear-gradient(90deg,#6366f1,#8b5cf6)}
h2{font-size:18px;font-weight:700;color:#111827;margin-bottom:20px}
.form-group{margin-bottom:16px}
label{display:block;font-size:13px;font-weight:600;color:#374151;margin-bottom:6px}
input,select{width:100%;padding:10px 14px;border:1.5px solid #e5e7eb;border-radius:8px;font-family:inherit;font-size:14px;outline:none;transition:.2s}
input:focus,select:focus{border-color:#6366f1}
.btn{width:100%;padding:13px;background:linear-gradient(135deg,#6366f1,#8b5cf6);color:#fff;border:none;border-radius:10px;font-size:15px;font-weight:700;cursor:pointer;margin-top:8px}
.btn:hover{opacity:.9}
.alert{padding:12px 16px;border-radius:8px;font-size:13px;margin-bottom:16px}
.alert.error{background:#fef2f2;border:1px solid #fecaca;color:#dc2626}
.alert.success{background:#f0fdf4;border:1px solid #bbf7d0;color:#16a34a}
.alert.info{background:#eff6ff;border:1px solid #bfdbfe;color:#2563eb}
.grid2{display:grid;grid-template-columns:1fr 1fr;gap:12px}
.done-icon{text-align:center;font-size:64px;margin:20px 0}
code{background:#f3f4f6;padding:2px 6px;border-radius:4px;font-family:monospace;font-size:12px}
.result{max-height:300px;overflow-y:auto;background:#f9fafb;border:1px solid #e5e7eb;border-radius:8px;padding:12px;font-size:12px;font-family:monospace;line-height:1.8}
.result .ok{color:#16a34a}
.result .err{color:#dc2626}
</style>
</head>
<body>
<div class="box">
  <div class="logo">
    <h1>⚡ SuperTools</h1>
    <p>Auto Installer v1.0</p>
  </div>

  <div class="steps">
    <?php for($i=1;$i<=4;$i++): ?>
    <div class="step <?= $step>=$i?($step>$i?'done':'active'):'' ?>"></div>
    <?php endfor; ?>
  </div>

<?php if ($step === 0): ?>
  <h2>📋 Requirements Check</h2>
  <?php
  $checks = [
    'PHP >= 8.0'        => version_compare(PHP_VERSION, '8.0', '>='),
    'PDO Extension'     => extension_loaded('pdo'),
    'PDO MySQL'         => extension_loaded('pdo_mysql'),
    'JSON Extension'    => extension_loaded('json'),
    'cURL Extension'    => extension_loaded('curl'),
    'Writable uploads/' => is_writable(dirname(__DIR__).'/uploads') || mkdir(dirname(__DIR__).'/uploads', 0755, true),
    'Writable admin/'   => is_writable(__DIR__),
  ];
  $allOk = true;
  foreach ($checks as $name => $ok) {
    if (!$ok) $allOk = false;
    echo '<div class="alert '.($ok?'success':'error').'">'.($ok?'✅':'❌').' '.$name.'</div>';
  }
  ?>
  <?php if ($allOk): ?>
  <form method="POST">
    <input type="hidden" name="step" value="1">
    <button class="btn">Continue → Database Setup</button>
  </form>
  <?php else: ?>
  <div class="alert error">Please fix the issues above before continuing.</div>
  <?php endif; ?>

<?php elseif ($step === 1): ?>
  <h2>🗄️ Database Configuration</h2>
  <form method="POST">
    <input type="hidden" name="step" value="2">
    <div class="grid2">
      <div class="form-group"><label>DB Host</label><input name="db_host" value="<?= esc($_POST['db_host']??'localhost') ?>" required></div>
      <div class="form-group"><label>DB Port</label><input name="db_port" value="<?= esc($_POST['db_port']??'3306') ?>"></div>
    </div>
    <div class="form-group"><label>Database Name</label><input name="db_name" value="<?= esc($_POST['db_name']??'supertools') ?>" required></div>
    <div class="grid2">
      <div class="form-group"><label>DB Username</label><input name="db_user" value="<?= esc($_POST['db_user']??'root') ?>" required></div>
      <div class="form-group"><label>DB Password</label><input name="db_pass" type="password" value=""></div>
    </div>
    <button class="btn">Test & Continue</button>
  </form>

<?php elseif ($step === 2): ?>
  <?php
  $h=$_POST['db_host']??'localhost';$port=$_POST['db_port']??'3306';
  $n=$_POST['db_name']??'supertools';$u=$_POST['db_user']??'root';$p=$_POST['db_pass']??'';
  $pdo = test_db($h,$port,$n,$u,$p);
  if (!$pdo) {
    // Try creating DB
    $pdo2 = test_db($h,$port,'',$u,$p);
    if ($pdo2) { try{$pdo2->exec("CREATE DATABASE IF NOT EXISTS `$n` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");$pdo=test_db($h,$port,$n,$u,$p);}catch(Exception $e){} }
  }
  if (!$pdo) {
    echo '<div class="alert error">❌ Cannot connect to database. Check credentials.</div>';
    echo '<form method="POST"><input type="hidden" name="step" value="1"><button class="btn">← Back</button></form>';
  } else {
    // Run SQL
    $sql = file_get_contents(__DIR__.'/database.sql');
    $statements = array_filter(array_map('trim', explode(';', $sql)));
    $results = [];
    foreach ($statements as $stmt) {
      if (!$stmt) continue;
      try { $pdo->exec($stmt); $results[]=['ok'=>true,'msg'=>substr($stmt,0,60).'…']; }
      catch(Exception $e){ $results[]=['ok'=>false,'msg'=>$e->getMessage()]; }
    }
  ?>
  <h2>🗄️ Installing Database</h2>
  <div class="result">
    <?php foreach($results as $r): ?>
    <div class="<?= $r['ok']?'ok':'err' ?>"><?= $r['ok']?'✅':'❌' ?> <?= esc($r['msg']) ?></div>
    <?php endforeach; ?>
  </div>
  <form method="POST" style="margin-top:16px">
    <input type="hidden" name="step" value="3">
    <input type="hidden" name="db_host" value="<?= esc($h) ?>">
    <input type="hidden" name="db_port" value="<?= esc($port) ?>">
    <input type="hidden" name="db_name" value="<?= esc($n) ?>">
    <input type="hidden" name="db_user" value="<?= esc($u) ?>">
    <input type="hidden" name="db_pass" value="<?= esc($p) ?>">
    <button class="btn">Continue → Admin Setup</button>
  </form>
  <?php } ?>

<?php elseif ($step === 3): ?>
  <h2>👤 Admin Account & Site Setup</h2>
  <form method="POST">
    <input type="hidden" name="step" value="4">
    <?php foreach(['db_host','db_port','db_name','db_user','db_pass'] as $f): ?>
    <input type="hidden" name="<?= $f ?>" value="<?= esc($_POST[$f]??'') ?>">
    <?php endforeach; ?>
    <div class="form-group"><label>Site Name</label><input name="site_name" value="SuperTools" required></div>
    <div class="form-group"><label>Site URL</label><input name="site_url" placeholder="https://yoursite.com" required></div>
    <div class="form-group"><label>Admin Email</label><input name="admin_email" type="email" required></div>
    <div class="grid2">
      <div class="form-group"><label>Admin Username</label><input name="admin_user" value="admin" required></div>
      <div class="form-group"><label>Admin Password</label><input name="admin_pass" type="password" minlength="6" required></div>
    </div>
    <button class="btn">Finish Installation ✨</button>
  </form>

<?php elseif ($step === 4): ?>
  <?php
  $h=$_POST['db_host'];$port=$_POST['db_port'];$n=$_POST['db_name'];$u=$_POST['db_user'];$p=$_POST['db_pass'];
  $siteName=$_POST['site_name']??'SuperTools';$siteUrl=rtrim($_POST['site_url']??'','/');
  $adminEmail=$_POST['admin_email'];$adminUser=$_POST['admin_user'];$adminPass=$_POST['admin_pass'];
  $pdo=test_db($h,$port,$n,$u,$p);
  $ok=true;
  if($pdo){
    // Insert admin
    try{
      $hash=password_hash($adminPass,PASSWORD_BCRYPT,['cost'=>12]);
      $pdo->prepare("INSERT IGNORE INTO admin_users(username,email,password,role,status) VALUES(?,?,?,'superadmin',1)")
          ->execute([$adminUser,$adminEmail,$hash]);
      // Update settings
      $pdo->prepare("INSERT INTO settings(setting_key,setting_value) VALUES('site_name',?) ON DUPLICATE KEY UPDATE setting_value=?")->execute([$siteName,$siteName]);
      $pdo->prepare("INSERT INTO settings(setting_key,setting_value) VALUES('site_url',?) ON DUPLICATE KEY UPDATE setting_value=?")->execute([$siteUrl,$siteUrl]);
      $pdo->prepare("INSERT INTO settings(setting_key,setting_value) VALUES('admin_email',?) ON DUPLICATE KEY UPDATE setting_value=?")->execute([$adminEmail,$adminEmail]);
    }catch(Exception $e){$ok=false;$errors[]=$e->getMessage();}

    // Write config
    $configContent = "<?php\n// SuperTools — Configuration\ndefine('MT_VERSION','1.0.0');\ndefine('DB_HOST','".addslashes($h)."');\ndefine('DB_PORT','".addslashes($port)."');\ndefine('DB_NAME','".addslashes($n)."');\ndefine('DB_USER','".addslashes($u)."');\ndefine('DB_PASS','".addslashes($p)."');\ndefine('DB_CHARSET','utf8mb4');\ndefine('SECRET_KEY','".bin2hex(random_bytes(32))."');\ndefine('SESSION_EXPIRE',3600*8);\ndefine('BCRYPT_COST',12);\ndefine('BASE_URL','".addslashes($siteUrl)."');\ndefine('ADMIN_URL',BASE_URL.'/admin');\ndefine('UPLOAD_PATH',dirname(dirname(__DIR__)).'/uploads/');\ndefine('UPLOAD_URL',BASE_URL.'/uploads/');\ndate_default_timezone_set('UTC');\nerror_reporting(0);\n";
    $configContent .= file_get_contents(__DIR__.'/includes/config.php');
    // Just update the defines in config
    $cfg = file_get_contents(__DIR__.'/includes/config.php');
    $cfg = preg_replace("/define\('DB_HOST',.*?\);/", "define('DB_HOST','".addslashes($h)."');", $cfg);
    $cfg = preg_replace("/define\('DB_PORT',.*?\);/", "define('DB_PORT','".addslashes($port)."');", $cfg);
    $cfg = preg_replace("/define\('DB_NAME',.*?\);/", "define('DB_NAME','".addslashes($n)."');", $cfg);
    $cfg = preg_replace("/define\('DB_USER',.*?\);/", "define('DB_USER','".addslashes($u)."');", $cfg);
    $cfg = preg_replace("/define\('DB_PASS',.*?\);/", "define('DB_PASS','".addslashes($p)."');", $cfg);
    $cfg = preg_replace("/define\('BASE_URL',.*?\);/", "define('BASE_URL','".addslashes($siteUrl)."');", $cfg);
    $secret = bin2hex(random_bytes(32));
    $cfg = preg_replace("/define\('SECRET_KEY',.*?\);/", "define('SECRET_KEY','$secret');", $cfg);
    file_put_contents(__DIR__.'/includes/config.php', $cfg);
    // Lock file
    file_put_contents(__DIR__.'/installed.lock', date('Y-m-d H:i:s'));
  } else { $ok=false; $errors[]='DB connection failed'; }
  ?>
  <?php if($ok): ?>
  <div class="done-icon">🎉</div>
  <h2 style="text-align:center">Installation Complete!</h2>
  <div class="alert success" style="margin-top:16px">
    ✅ SuperTools installed successfully!<br>
    Admin: <code><?= esc($siteUrl) ?>/admin</code><br>
    Site: <code><?= esc($siteUrl) ?></code>
  </div>
  <div class="alert info">
    ⚠️ Please <strong>delete install.php</strong> from your server for security.
  </div>
  <a href="<?= esc($siteUrl) ?>/admin/login.php" class="btn" style="display:block;text-align:center;text-decoration:none;margin-top:8px">Go to Admin Panel →</a>
  <?php else: ?>
  <div class="alert error">❌ Installation failed: <?= implode('<br>', array_map('esc', $errors)) ?></div>
  <form method="POST"><input type="hidden" name="step" value="3">
  <?php foreach(['db_host','db_port','db_name','db_user','db_pass'] as $f):?><input type="hidden" name="<?=$f?>" value="<?=esc($_POST[$f]??'')?>">
  <?php endforeach; ?><button class="btn">← Back</button></form>
  <?php endif; ?>
<?php endif; ?>
</div>
</body>
</html>
