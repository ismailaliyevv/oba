-- SuperTools Database Schema
SET NAMES utf8mb4;
SET time_zone = '+00:00';

CREATE TABLE IF NOT EXISTS `settings` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `setting_key` VARCHAR(100) NOT NULL UNIQUE,
  `setting_value` LONGTEXT,
  `setting_group` VARCHAR(50) DEFAULT 'general',
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `languages` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `code` VARCHAR(10) NOT NULL UNIQUE,
  `name` VARCHAR(100) NOT NULL,
  `flag` VARCHAR(10) DEFAULT '🌐',
  `is_default` TINYINT(1) DEFAULT 0,
  `status` TINYINT(1) DEFAULT 1,
  `sort_order` INT DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `translations` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `lang_code` VARCHAR(10) NOT NULL,
  `trans_key` VARCHAR(200) NOT NULL,
  `trans_value` TEXT,
  UNIQUE KEY `lang_key` (`lang_code`, `trans_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `categories` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL,
  `slug` VARCHAR(100) NOT NULL UNIQUE,
  `icon` VARCHAR(50) DEFAULT '🔧',
  `color` VARCHAR(20) DEFAULT '#6366f1',
  `description` TEXT,
  `sort_order` INT DEFAULT 0,
  `status` TINYINT(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `tools` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(200) NOT NULL,
  `slug` VARCHAR(200) NOT NULL UNIQUE,
  `icon` VARCHAR(50) DEFAULT '🔧',
  `category_id` INT DEFAULT NULL,
  `description` TEXT,
  `path` VARCHAR(300),
  `meta_title` VARCHAR(200),
  `meta_desc` TEXT,
  `status` ENUM('active','inactive','coming_soon') DEFAULT 'active',
  `is_featured` TINYINT(1) DEFAULT 0,
  `is_premium` TINYINT(1) DEFAULT 0,
  `views` INT DEFAULT 0,
  `views_week` INT DEFAULT 0,
  `sort_order` INT DEFAULT 0,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`category_id`) REFERENCES `categories`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `plans` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL,
  `slug` VARCHAR(100) NOT NULL UNIQUE,
  `price` DECIMAL(10,2) DEFAULT 0.00,
  `billing_cycle` ENUM('monthly','yearly','lifetime') DEFAULT 'monthly',
  `features` JSON,
  `tool_limit` INT DEFAULT -1,
  `is_popular` TINYINT(1) DEFAULT 0,
  `status` TINYINT(1) DEFAULT 1,
  `sort_order` INT DEFAULT 0,
  `stripe_price_id` VARCHAR(100) DEFAULT NULL,
  `paypal_plan_id` VARCHAR(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(100),
  `email` VARCHAR(150) NOT NULL UNIQUE,
  `password` VARCHAR(255),
  `avatar` VARCHAR(300),
  `plan_id` INT DEFAULT 1,
  `plan_expires_at` DATETIME DEFAULT NULL,
  `status` ENUM('active','banned','unverified') DEFAULT 'active',
  `email_verified` TINYINT(1) DEFAULT 0,
  `verify_token` VARCHAR(100),
  `reset_token` VARCHAR(100),
  `reset_expires` DATETIME,
  `lang` VARCHAR(10) DEFAULT 'en',
  `stripe_customer_id` VARCHAR(100),
  `paypal_subscription_id` VARCHAR(100),
  `joined_ip` VARCHAR(45),
  `last_active` DATETIME,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`plan_id`) REFERENCES `plans`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `transactions` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT,
  `plan_id` INT,
  `amount` DECIMAL(10,2),
  `currency` VARCHAR(10) DEFAULT 'USD',
  `payment_method` ENUM('stripe','paypal','manual') DEFAULT 'stripe',
  `payment_id` VARCHAR(200),
  `status` ENUM('completed','pending','failed','refunded') DEFAULT 'pending',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE SET NULL,
  FOREIGN KEY (`plan_id`) REFERENCES `plans`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `posts` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `title` VARCHAR(200) NOT NULL,
  `slug` VARCHAR(200) NOT NULL UNIQUE,
  `content` LONGTEXT,
  `excerpt` TEXT,
  `featured_image` TEXT,
  `cat_id` INT DEFAULT NULL,
  `tags` VARCHAR(500),
  `status` ENUM('published','draft') DEFAULT 'published',
  `views` INT DEFAULT 0,
  `meta_title` VARCHAR(200),
  `meta_desc` TEXT,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `post_categories` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL,
  `slug` VARCHAR(100) NOT NULL UNIQUE,
  `description` TEXT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `pages` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `title` VARCHAR(200) NOT NULL,
  `slug` VARCHAR(200) NOT NULL UNIQUE,
  `content` LONGTEXT,
  `status` ENUM('published','draft') DEFAULT 'published',
  `meta_desc` TEXT,
  `featured_image` TEXT,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `advertisements` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(100),
  `slot` VARCHAR(50),
  `type` ENUM('adsense','custom_html') DEFAULT 'custom_html',
  `code` TEXT,
  `impressions` INT DEFAULT 0,
  `clicks` INT DEFAULT 0,
  `status` TINYINT(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `admin_users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `username` VARCHAR(100) NOT NULL UNIQUE,
  `email` VARCHAR(150) NOT NULL UNIQUE,
  `password` VARCHAR(255) NOT NULL,
  `role` ENUM('superadmin','admin','editor') DEFAULT 'admin',
  `status` TINYINT(1) DEFAULT 1,
  `last_login` DATETIME,
  `login_ip` VARCHAR(45),
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `activity_log` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `admin_id` INT,
  `action` VARCHAR(200),
  `entity_type` VARCHAR(50),
  `entity_id` INT DEFAULT 0,
  `new_value` TEXT,
  `ip` VARCHAR(45),
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `page_views` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `page` VARCHAR(300),
  `tool_id` INT DEFAULT NULL,
  `ip` VARCHAR(45),
  `country` VARCHAR(5),
  `user_agent` VARCHAR(300),
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Default data
INSERT IGNORE INTO `languages` (`code`,`name`,`flag`,`is_default`,`status`,`sort_order`) VALUES
('en','English','🇬🇧',1,1,1),
('az','Azərbaycan','🇦🇿',0,1,2),
('ru','Русский','🇷🇺',0,1,3),
('tr','Türkçe','🇹🇷',0,1,4),
('de','Deutsch','🇩🇪',0,1,5),
('fr','Français','🇫🇷',0,1,6),
('es','Español','🇪🇸',0,1,7),
('ar','العربية','🇸🇦',0,1,8),
('zh','中文','🇨🇳',0,1,9),
('pt','Português','🇵🇹',0,1,10),
('it','Italiano','🇮🇹',0,1,11),
('ja','日本語','🇯🇵',0,1,12),
('ko','한국어','🇰🇷',0,1,13),
('hi','हिन्दी','🇮🇳',0,1,14),
('nl','Nederlands','🇳🇱',0,1,15),
('pl','Polski','🇵🇱',0,1,16),
('uk','Українська','🇺🇦',0,1,17),
('fa','فارسی','🇮🇷',0,1,18),
('id','Indonesia','🇮🇩',0,1,19),
('vi','Tiếng Việt','🇻🇳',0,1,20),
('th','ภาษาไทย','🇹🇭',0,1,21),
('sv','Svenska','🇸🇪',0,1,22),
('no','Norsk','🇳🇴',0,1,23),
('da','Dansk','🇩🇰',0,1,24),
('fi','Suomi','🇫🇮',0,1,25),
('cs','Čeština','🇨🇿',0,1,26),
('hu','Magyar','🇭🇺',0,1,27),
('ro','Română','🇷🇴',0,1,28),
('el','Ελληνικά','🇬🇷',0,1,29),
('he','עברית','🇮🇱',0,1,30),
('bn','বাংলা','🇧🇩',0,1,31),
('ms','Melayu','🇲🇾',0,1,32);

INSERT IGNORE INTO `plans` (`name`,`slug`,`price`,`billing_cycle`,`features`,`tool_limit`,`is_popular`,`status`,`sort_order`) VALUES
('Free','free',0.00,'lifetime','["Access to 10 free tools","1 GB storage","Basic support"]',10,0,1,0),
('Pro','pro',9.99,'monthly','["Access to all tools","Unlimited usage","Priority support","No ads","API access"]',-1,1,1,1),
('Enterprise','enterprise',29.99,'monthly','["Everything in Pro","Team accounts","Custom integrations","Dedicated support","White label"]',-1,0,1,2);

INSERT IGNORE INTO `categories` (`name`,`slug`,`icon`,`color`,`sort_order`) VALUES
('Text & AI Tools','text-ai','🤖','#6366f1',1),
('Document Tools','document','📄','#f59e0b',2),
('Image Tools','image','🖼️','#10b981',3),
('SEO & Marketing','seo-marketing','📈','#3b82f6',4),
('Developer Tools','developer','💻','#8b5cf6',5),
('Converter Tools','converter','🔄','#ef4444',6);

INSERT IGNORE INTO `settings` (`setting_key`,`setting_value`,`setting_group`) VALUES
('site_name','SuperTools','general'),
('site_tagline','Free Online Tools for Everyone','general'),
('site_url','https://yoursite.com','general'),
('admin_email','admin@yoursite.com','general'),
('footer_text','© 2024 SuperTools. All rights reserved.','general'),
('theme_color','#6366f1','appearance'),
('logo_icon','⚡','appearance'),
('maintenance_mode','0','general'),
('stripe_public_key','','payments'),
('stripe_secret_key','','payments'),
('paypal_client_id','','payments'),
('paypal_secret','','payments'),
('paypal_mode','sandbox','payments'),
('meta_title','SuperTools — Free Online Tools','seo'),
('meta_description','Free online tools for text, documents, images, SEO and more.','seo'),
('og_image','','seo'),
('google_analytics_id','','analytics'),
('recaptcha_site_key','','security'),
('recaptcha_secret_key','','security'),
('smtp_host','','email'),
('smtp_port','587','email'),
('smtp_user','','email'),
('smtp_pass','','email'),
('smtp_from','','email'),
('faqs','[]','general');

-- Default Tools
INSERT IGNORE INTO `tools` (`name`,`slug`,`icon`,`category_id`,`description`,`path`,`status`,`is_featured`,`sort_order`) VALUES
('Word to PDF','word-to-pdf','📄',2,'Convert Word documents (.doc, .docx) to PDF format','tools/word-to-pdf.php','active',1,1),
('PDF Merger','pdf-merge','🔀',2,'Merge multiple PDF files into one document','tools/pdf-merge.php','active',1,2),
('Image Compressor','image-compressor','🗜️',3,'Compress JPG, PNG and WebP images without losing quality','tools/image-compressor.php','active',1,3);
