<?php
require_once __DIR__ . '/includes/config.php';
Auth::require();
require_once __DIR__ . '/includes/sync-hook.php';

// Auto sync on every load (only adds new, fast)
$syncResult = sync_tools();

$admin = Auth::user();
$siteName   = ST_Settings::get('site_name', 'SuperTools');
$themeColor = ST_Settings::get('theme_color', '#6366f1');
$logoIcon   = ST_Settings::get('logo_icon', '⚡');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Admin — <?= esc($siteName) ?></title>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@600;700;800&family=DM+Sans:wght@400;500;600;700&family=JetBrains+Mono:wght@400;600&display=swap" rel="stylesheet">
<style>
:root{
  --accent:<?= esc($themeColor) ?>;
  --bg:#0a0f1e;--surface:#111827;--card:#161f35;--border:#1f2d4a;
  --text:#e8edf5;--muted:#6b7a99;--green:#22c55e;--red:#ef4444;
  --yellow:#f59e0b;--purple:#8b5cf6;--blue:#3b82f6;
  --sidebar-w:240px;--topbar-h:60px;--radius:12px;
}
*{margin:0;padding:0;box-sizing:border-box}
html{scroll-behavior:smooth}
body{font-family:'DM Sans',sans-serif;background:var(--bg);color:var(--text);min-height:100vh;display:flex;}

/* ── SIDEBAR ── */
.sidebar{width:var(--sidebar-w);background:var(--surface);border-right:1px solid var(--border);position:fixed;top:0;left:0;height:100vh;display:flex;flex-direction:column;z-index:100;transition:.3s;}
.sidebar-logo{padding:18px 16px 14px;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:10px;}
.logo-mark{width:36px;height:36px;background:var(--accent);border-radius:9px;display:flex;align-items:center;justify-content:center;font-size:18px;flex-shrink:0;}
.logo-name{font-family:'Syne',sans-serif;font-size:16px;font-weight:800;color:#fff;}
.logo-ver{font-size:10px;color:var(--muted);}
.nav-scroll{flex:1;overflow-y:auto;padding:10px 0;}
.nav-scroll::-webkit-scrollbar{width:3px;}
.nav-scroll::-webkit-scrollbar-thumb{background:var(--border);}
.nav-group{padding:14px 14px 4px;font-size:10px;font-weight:700;color:var(--muted);text-transform:uppercase;letter-spacing:1px;}
.nav-item{display:flex;align-items:center;gap:9px;padding:8px 14px;color:var(--muted);font-size:13px;font-weight:600;cursor:pointer;transition:.15s;margin:1px 8px;border-radius:8px;}
.nav-item:hover{background:var(--card);color:var(--text);}
.nav-item.active{background:rgba(255,255,255,.06);color:var(--accent);}
.nav-item .nav-icon{width:16px;text-align:center;font-size:14px;flex-shrink:0;}
.nav-badge{margin-left:auto;background:var(--accent);color:#fff;font-size:10px;font-weight:700;padding:1px 6px;border-radius:20px;}
.sidebar-footer{padding:14px;border-top:1px solid var(--border);}
.admin-pill{display:flex;align-items:center;gap:9px;padding:9px 12px;background:var(--card);border-radius:10px;}
.admin-av{width:30px;height:30px;background:linear-gradient(135deg,var(--blue),var(--purple));border-radius:7px;display:flex;align-items:center;justify-content:center;font-size:13px;font-weight:800;color:#fff;flex-shrink:0;}
.admin-name{font-size:13px;font-weight:700;color:var(--text);}
.admin-role{font-size:10px;color:var(--muted);}
.logout-btn{width:100%;margin-top:8px;padding:7px;background:rgba(239,68,68,.08);color:#ef4444;border:1px solid rgba(239,68,68,.2);border-radius:8px;font-family:inherit;font-size:12px;font-weight:600;cursor:pointer;transition:.15s;}
.logout-btn:hover{background:rgba(239,68,68,.16);}

/* ── TOPBAR ── */
.sidebar-overlay{display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:99;backdrop-filter:blur(2px);}
.sidebar-overlay.open{display:block;}
.topbar{height:var(--topbar-h);background:var(--surface);border-bottom:1px solid var(--border);position:fixed;top:0;left:var(--sidebar-w);right:0;z-index:90;display:flex;align-items:center;padding:0 20px;gap:12px;transition:left .3s;}
.page-title{font-family:'Syne',sans-serif;font-size:17px;font-weight:800;color:#fff;flex:1;}
.hamburger{display:none;background:none;border:none;cursor:pointer;padding:6px;color:var(--text);}
.topbar-actions{display:flex;align-items:center;gap:8px;margin-left:auto;}
.clock{background:var(--card);border:1px solid var(--border);border-radius:7px;padding:5px 10px;font-size:12px;font-weight:600;color:var(--text);font-family:'JetBrains Mono',monospace;}
.icon-btn{width:34px;height:34px;background:var(--card);border:1px solid var(--border);border-radius:7px;display:flex;align-items:center;justify-content:center;cursor:pointer;font-size:15px;transition:.15s;}
.icon-btn:hover{border-color:var(--accent);}
.sync-btn{display:flex;align-items:center;gap:6px;padding:7px 14px;background:rgba(34,197,94,.1);border:1px solid rgba(34,197,94,.25);border-radius:8px;color:var(--green);font-family:inherit;font-size:12px;font-weight:700;cursor:pointer;transition:.15s;}
.sync-btn:hover{background:rgba(34,197,94,.18);}

/* ── MAIN ── */
.main{margin-left:var(--sidebar-w);margin-top:var(--topbar-h);flex:1;padding:20px;min-height:calc(100vh - var(--topbar-h));width:calc(100% - var(--sidebar-w));box-sizing:border-box;transition:margin-left .3s,width .3s;}

/* ── SECTIONS ── */
.section{display:none;animation:fadeIn .2s ease;}
.section.active{display:block;}
@keyframes fadeIn{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:none}}

/* ── CARDS ── */
.card{background:var(--card);border:1px solid var(--border);border-radius:var(--radius);padding:18px;}
.card-title{font-size:13px;font-weight:700;color:#fff;margin-bottom:14px;display:flex;align-items:center;gap:8px;}
.grid2{display:grid;grid-template-columns:1fr 1fr;gap:14px;}
.grid3{display:grid;grid-template-columns:1fr 1fr 1fr;gap:14px;}
.grid4{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;}

/* ── STAT CARDS ── */
.stat{background:var(--card);border:1px solid var(--border);border-radius:var(--radius);padding:18px;position:relative;overflow:hidden;}
.stat::before{content:'';position:absolute;top:0;left:0;right:0;height:2px;}
.stat.or::before{background:linear-gradient(90deg,var(--accent),transparent);}
.stat.bl::before{background:linear-gradient(90deg,var(--blue),transparent);}
.stat.gr::before{background:linear-gradient(90deg,var(--green),transparent);}
.stat.pu::before{background:linear-gradient(90deg,var(--purple),transparent);}
.stat-icon{width:40px;height:40px;border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:18px;margin-bottom:10px;}
.stat-icon.or{background:rgba(249,115,22,.12);}
.stat-icon.bl{background:rgba(59,130,246,.12);}
.stat-icon.gr{background:rgba(34,197,94,.12);}
.stat-icon.pu{background:rgba(139,92,246,.12);}
.stat-num{font-family:'Syne',sans-serif;font-size:28px;font-weight:800;color:#fff;}
.stat-label{font-size:12px;color:var(--muted);}
.stat-sub{font-size:11px;color:var(--muted);margin-top:6px;}

/* ── TABLE ── */
.tbl-wrap{overflow-x:auto;border-radius:8px;}
table{width:100%;border-collapse:collapse;font-size:13px;}
thead tr{border-bottom:1px solid var(--border);}
th{padding:9px 12px;color:var(--muted);font-weight:700;font-size:10px;text-transform:uppercase;letter-spacing:.5px;text-align:left;white-space:nowrap;}
td{padding:10px 12px;border-bottom:1px solid rgba(255,255,255,.04);color:var(--text);vertical-align:middle;}
tr:last-child td{border-bottom:none;}
tr:hover td{background:rgba(255,255,255,.02);}
.tbl-name{font-weight:700;color:#fff;}
.tbl-sub{font-size:11px;color:var(--muted);margin-top:2px;}

/* ── BADGES ── */
.badge{display:inline-flex;align-items:center;padding:2px 8px;border-radius:20px;font-size:11px;font-weight:700;}
.b-green{background:rgba(34,197,94,.12);color:var(--green);}
.b-red{background:rgba(239,68,68,.12);color:var(--red);}
.b-blue{background:rgba(59,130,246,.12);color:var(--blue);}
.b-orange{background:rgba(249,115,22,.12);color:var(--accent);}
.b-yellow{background:rgba(245,158,11,.12);color:var(--yellow);}
.b-gray{background:rgba(107,122,153,.12);color:var(--muted);}
.b-purple{background:rgba(139,92,246,.12);color:var(--purple);}

/* ── BUTTONS ── */
.btn{display:inline-flex;align-items:center;gap:5px;padding:7px 14px;border-radius:8px;border:none;font-family:inherit;font-size:12px;font-weight:700;cursor:pointer;transition:.15s;white-space:nowrap;}
.btn:hover{transform:translateY(-1px);}
.btn-primary{background:var(--accent);color:#fff;}
.btn-secondary{background:var(--card);color:var(--text);border:1px solid var(--border);}
.btn-secondary:hover{border-color:var(--accent);color:var(--accent);}
.btn-danger{background:rgba(239,68,68,.1);color:var(--red);border:1px solid rgba(239,68,68,.2);}
.btn-danger:hover{background:var(--red);color:#fff;}
.btn-sm{padding:4px 9px;font-size:11px;}
.btn-green{background:rgba(34,197,94,.1);color:var(--green);border:1px solid rgba(34,197,94,.2);}

/* ── FORMS ── */
.form-grid{display:grid;grid-template-columns:1fr 1fr;gap:14px;}
.form-full{grid-column:1/-1;}
.form-group{display:flex;flex-direction:column;gap:5px;}
.form-group label{font-size:11px;font-weight:700;color:var(--muted);text-transform:uppercase;letter-spacing:.4px;}
.form-group input,.form-group select,.form-group textarea,.fi{background:var(--bg);border:1.5px solid var(--border);border-radius:8px;padding:9px 11px;color:var(--text);font-family:inherit;font-size:13px;outline:none;transition:.2s;width:100%;}
.form-group input:focus,.form-group select:focus,.form-group textarea:focus,.fi:focus{border-color:var(--accent);}
.form-group textarea{resize:vertical;min-height:70px;}

/* ── TOOLBAR ── */
.toolbar{display:flex;align-items:center;gap:8px;margin-bottom:16px;flex-wrap:wrap;}
.search-wrap{position:relative;}
.search-wrap::before{content:'🔍';position:absolute;left:9px;top:50%;transform:translateY(-50%);font-size:12px;pointer-events:none;}
.search-input{background:var(--card);border:1.5px solid var(--border);border-radius:8px;padding:7px 12px 7px 30px;color:var(--text);font-family:inherit;font-size:12px;outline:none;transition:.2s;width:220px;}
.search-input:focus{border-color:var(--accent);}
.sel{background:var(--card);border:1.5px solid var(--border);border-radius:8px;padding:7px 11px;color:var(--text);font-family:inherit;font-size:12px;outline:none;cursor:pointer;}
.spacer{flex:1;}

/* ── MODAL ── */
.modal-overlay{position:fixed;inset:0;background:rgba(0,0,0,.75);backdrop-filter:blur(4px);z-index:200;display:none;align-items:center;justify-content:center;padding:16px;}
.modal-overlay.open{display:flex;}
.modal{background:var(--surface);border:1px solid var(--border);border-radius:16px;width:100%;max-width:560px;max-height:90vh;overflow-y:auto;padding:24px;}
.modal-header{display:flex;align-items:center;justify-content:space-between;margin-bottom:20px;}
.modal-title{font-family:'Syne',sans-serif;font-size:16px;font-weight:800;color:#fff;}
.modal-close{width:28px;height:28px;background:var(--card);border:1px solid var(--border);border-radius:7px;cursor:pointer;font-size:16px;color:var(--muted);display:flex;align-items:center;justify-content:center;}
.modal-close:hover{color:#fff;border-color:var(--accent);}
.modal-footer{display:flex;gap:8px;margin-top:20px;justify-content:flex-end;}

/* ── TOAST ── */
#toast-container{position:fixed;bottom:20px;right:20px;z-index:999;display:flex;flex-direction:column;gap:7px;}
.toast{background:var(--surface);border:1px solid var(--border);border-radius:9px;padding:12px 16px;font-size:12px;font-weight:600;display:flex;align-items:center;gap:9px;max-width:300px;animation:slideIn .25s ease;}
.toast.success{border-left:3px solid var(--green);}
.toast.error{border-left:3px solid var(--red);}
.toast.info{border-left:3px solid var(--blue);}
@keyframes slideIn{from{opacity:0;transform:translateX(20px)}to{opacity:1;transform:none}}

/* ── TOGGLE ── */
.toggle{width:38px;height:20px;background:var(--border);border-radius:10px;position:relative;cursor:pointer;transition:.2s;flex-shrink:0;}
.toggle.on{background:var(--green);}
.toggle::after{content:'';width:14px;height:14px;background:#fff;border-radius:50%;position:absolute;top:3px;left:3px;transition:.2s;}
.toggle.on::after{left:21px;}

/* ── PROGRESS ── */
.progress-bar{height:5px;background:var(--border);border-radius:3px;overflow:hidden;}
.progress-fill{height:100%;background:linear-gradient(90deg,var(--accent),#fb923c);border-radius:3px;transition:.4s;}

/* ── SYNC NOTICE ── */
.sync-notice{background:rgba(34,197,94,.08);border:1px solid rgba(34,197,94,.2);border-radius:9px;padding:10px 14px;font-size:12px;color:var(--green);margin-bottom:16px;display:flex;align-items:center;gap:8px;}

/* ── RESPONSIVE ── */
@media(max-width:768px){
  :root{--sidebar-w:0px}
  .sidebar{transform:translateX(-240px);width:240px;z-index:300;}
  .sidebar.open{transform:translateX(0);}
  .topbar{left:0;}
  .main{margin-left:0;width:100%;}
  .hamburger{display:flex!important;}
  .grid4{grid-template-columns:1fr 1fr;}
  .grid3,.grid2{grid-template-columns:1fr;}
  .clock{display:none;}
}
@media(max-width:480px){
  .grid4{grid-template-columns:1fr;}
}
</style>
</head>
<body>

<!-- SIDEBAR -->
<nav class="sidebar" id="sidebar">
  <div class="sidebar-logo">
    <div class="logo-mark"><?= esc($logoIcon) ?></div>
    <div>
      <div class="logo-name"><?= esc($siteName) ?></div>
      <div class="logo-ver">Admin v1.0</div>
    </div>
  </div>

  <div class="nav-scroll">
    <div class="nav-group">Main</div>
    <div class="nav-item active" data-sec="dashboard"><span class="nav-icon">📊</span>Dashboard</div>
    <div class="nav-item" data-sec="tools"><span class="nav-icon">🔧</span>Tools <span class="nav-badge" id="nb-tools">—</span></div>
    <div class="nav-item" data-sec="categories"><span class="nav-icon">📁</span>Categories</div>
    <div class="nav-item" data-sec="analytics"><span class="nav-icon">📈</span>Analytics</div>

    <div class="nav-group">Users</div>
    <div class="nav-item" data-sec="users"><span class="nav-icon">👤</span>Users</div>
    <div class="nav-item" data-sec="plans"><span class="nav-icon">💎</span>Plans</div>
    <div class="nav-item" data-sec="transactions"><span class="nav-icon">💳</span>Transactions</div>

    <div class="nav-group">Content</div>
    <div class="nav-item" data-sec="posts"><span class="nav-icon">✍️</span>Blog Posts</div>
    <div class="nav-item" data-sec="pages"><span class="nav-icon">🗒️</span>Pages</div>
    <div class="nav-item" data-sec="ads"><span class="nav-icon">📢</span>Advertisements</div>

    <div class="nav-group">System</div>
    <div class="nav-item" data-sec="settings"><span class="nav-icon">⚙️</span>Settings</div>
    <div class="nav-item" data-sec="langs"><span class="nav-icon">🌐</span>Languages</div>
    <div class="nav-item" data-sec="admins"><span class="nav-icon">🛡️</span>Admin Users</div>
    <div class="nav-item" data-sec="seo"><span class="nav-icon">🔍</span>SEO</div>
    <div class="nav-item" data-sec="activity"><span class="nav-icon">📋</span>Activity Log</div>
  </div>

  <div class="sidebar-footer">
    <div class="admin-pill">
      <div class="admin-av"><?= strtoupper(substr($admin['username']??'A',0,1)) ?></div>
      <div>
        <div class="admin-name"><?= esc($admin['username']??'Admin') ?></div>
        <div class="admin-role"><?= esc($admin['role']??'admin') ?></div>
      </div>
    </div>
    <button class="logout-btn" onclick="doLogout()">Sign Out</button>
  </div>
</nav>

<!-- TOPBAR -->
<div class="sidebar-overlay" id="sidebar-overlay" onclick="closeSidebar()"></div>
<header class="topbar">
  <button class="hamburger" onclick="toggleSidebar()" style="display:none;background:none;border:none;cursor:pointer;padding:5px">
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="18" x2="21" y2="18"/></svg>
  </button>
  <div class="page-title" id="page-title">Dashboard</div>
  <div class="topbar-actions">
    <?php if($syncResult['added'] > 0): ?>
    <span class="sync-btn" style="cursor:default">✅ <?= $syncResult['added'] ?> new tool(s) synced</span>
    <?php endif; ?>
    <button class="sync-btn" onclick="manualSync()">🔄 Sync Tools</button>
    <div class="clock" id="clock">00:00:00</div>
    <a href="../index.php" target="_blank" class="icon-btn" title="View Site">🌐</a>
    <div class="admin-av" style="cursor:pointer" onclick="navTo('admins')" title="Profile">
      <?= strtoupper(substr($admin['username']??'A',0,1)) ?>
    </div>
  </div>
</header>

<main class="main">

<!-- ═══ DASHBOARD ═══ -->
<div class="section active" id="sec-dashboard">
  <?php if($syncResult['added'] > 0): ?>
  <div class="sync-notice">✅ <?= $syncResult['added'] ?> new tool(s) automatically detected and added to database!</div>
  <?php endif; ?>

  <div class="grid4" style="margin-bottom:16px">
    <div class="stat or"><div class="stat-icon or">🔧</div><div class="stat-num" id="s-tools">—</div><div class="stat-label">Active Tools</div></div>
    <div class="stat bl"><div class="stat-icon bl">👥</div><div class="stat-num" id="s-users">—</div><div class="stat-label">Total Users</div></div>
    <div class="stat gr"><div class="stat-icon gr">💰</div><div class="stat-num" id="s-rev">—</div><div class="stat-label">Revenue</div></div>
    <div class="stat pu"><div class="stat-icon pu">👁️</div><div class="stat-num" id="s-views">—</div><div class="stat-label">Views This Week</div></div>
  </div>

  <div class="grid2" style="margin-bottom:16px">
    <div class="card">
      <div class="card-title">🏆 Top Tools This Week</div>
      <div id="top-tools-list"></div>
    </div>
    <div class="card">
      <div class="card-title">🆕 New Users</div>
      <div class="tbl-wrap">
        <table><thead><tr><th>User</th><th>Plan</th><th>Joined</th></tr></thead>
        <tbody id="new-users-table"></tbody></table>
      </div>
    </div>
  </div>

  <!-- Tools File Manager hint -->
  <div class="card">
    <div class="card-title">📂 Tools File Manager Guide</div>
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:12px">
      <div style="background:var(--bg);border:1px solid var(--border);border-radius:10px;padding:14px">
        <div style="font-size:18px;margin-bottom:6px">1️⃣</div>
        <div style="font-size:13px;font-weight:700;color:#fff;margin-bottom:4px">Upload Tool File</div>
        <div style="font-size:12px;color:var(--muted)">Upload your <code style="background:var(--card);padding:1px 5px;border-radius:4px;font-family:monospace">.html</code> tool file to <code style="background:var(--card);padding:1px 5px;border-radius:4px;font-family:monospace">tools/</code> folder via cPanel File Manager</div>
      </div>
      <div style="background:var(--bg);border:1px solid var(--border);border-radius:10px;padding:14px">
        <div style="font-size:18px;margin-bottom:6px">2️⃣</div>
        <div style="font-size:13px;font-weight:700;color:#fff;margin-bottom:4px">Auto Detection</div>
        <div style="font-size:12px;color:var(--muted)">Next time you open Admin Panel, the tool is automatically detected and added to the database</div>
      </div>
      <div style="background:var(--bg);border:1px solid var(--border);border-radius:10px;padding:14px">
        <div style="font-size:18px;margin-bottom:6px">3️⃣</div>
        <div style="font-size:13px;font-weight:700;color:#fff;margin-bottom:4px">Edit Details</div>
        <div style="font-size:12px;color:var(--muted)">Go to Tools section, click ✏️ to edit name, icon, category, description</div>
      </div>
      <div style="background:var(--bg);border:1px solid var(--border);border-radius:10px;padding:14px">
        <div style="font-size:18px;margin-bottom:6px">4️⃣</div>
        <div style="font-size:13px;font-weight:700;color:#fff;margin-bottom:4px">Goes Live</div>
        <div style="font-size:12px;color:var(--muted)">Tool appears on homepage automatically. Use 🔄 Sync button to manually trigger</div>
      </div>
    </div>
    <div style="margin-top:14px;padding:12px 14px;background:rgba(34,197,94,.06);border:1px solid rgba(34,197,94,.2);border-radius:8px;font-size:12px;color:var(--green)">
      💡 <strong>Tip:</strong> Put tools in subfolders like <code style="background:rgba(0,0,0,.2);padding:1px 5px;border-radius:3px">tools/pdf/</code> or <code style="background:rgba(0,0,0,.2);padding:1px 5px;border-radius:3px">tools/image/</code> — categories will be created automatically!
    </div>
  </div>
</div>

<!-- ═══ TOOLS ═══ -->
<div class="section" id="sec-tools">
  <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px">
    <div style="font-family:'Syne',sans-serif;font-size:18px;font-weight:800;color:#fff">🔧 Manage Tools</div>
    <div style="display:flex;gap:8px">
      <button class="sync-btn" onclick="manualSync()">🔄 Sync Files</button>
      <button class="btn btn-primary" onclick="openToolModal()">+ Add Tool</button>
    </div>
  </div>
  <div class="toolbar">
    <div class="search-wrap"><input class="search-input" id="tool-search" placeholder="Search tools…" oninput="loadTools()"></div>
    <select class="sel" id="tool-cat-filter" onchange="loadTools()"><option value="">All Categories</option></select>
    <select class="sel" id="tool-status-filter" onchange="loadTools()">
      <option value="">All Status</option>
      <option value="active">Active</option>
      <option value="inactive">Inactive</option>
      <option value="coming_soon">Coming Soon</option>
    </select>
    <div class="spacer"></div>
    <span style="font-size:12px;color:var(--muted)" id="tool-count-lbl"></span>
  </div>
  <div class="card" style="padding:0">
    <div class="tbl-wrap">
      <table>
        <thead><tr><th>#</th><th>Tool</th><th>File Path</th><th>Category</th><th>Views</th><th>Status</th><th>Featured</th><th>Actions</th></tr></thead>
        <tbody id="tools-tbody"></tbody>
      </table>
    </div>
    <div style="padding:10px 16px;border-top:1px solid var(--border)" id="tools-pag"></div>
  </div>
</div>

<!-- ═══ CATEGORIES ═══ -->
<div class="section" id="sec-categories">
  <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px">
    <div style="font-family:'Syne',sans-serif;font-size:18px;font-weight:800;color:#fff">📁 Categories</div>
    <button class="btn btn-primary" onclick="openCatModal()">+ Add Category</button>
  </div>
  <div class="card" style="padding:0">
    <div class="tbl-wrap">
      <table><thead><tr><th>Icon</th><th>Name</th><th>Slug</th><th>Tools</th><th>Color</th><th>Status</th><th>Actions</th></tr></thead>
      <tbody id="cats-tbody"></tbody></table>
    </div>
  </div>
</div>

<!-- ═══ ANALYTICS ═══ -->
<div class="section" id="sec-analytics">
  <div style="font-family:'Syne',sans-serif;font-size:18px;font-weight:800;color:#fff;margin-bottom:16px">📈 Analytics</div>
  <div class="grid4" style="margin-bottom:16px">
    <div class="stat or"><div class="stat-icon or">📊</div><div class="stat-num" id="a-total">—</div><div class="stat-label">Total Views</div></div>
    <div class="stat bl"><div class="stat-icon bl">🌍</div><div class="stat-num" id="a-countries">—</div><div class="stat-label">Countries</div></div>
    <div class="stat gr"><div class="stat-icon gr">📄</div><div class="stat-num" id="a-pages">—</div><div class="stat-label">Unique Pages</div></div>
    <div class="stat pu"><div class="stat-icon pu">🔧</div><div class="stat-num" id="a-tools-v">—</div><div class="stat-label">Tool Views</div></div>
  </div>
  <div class="card">
    <div class="card-title">Top Countries</div>
    <div id="countries-list"></div>
  </div>
</div>

<!-- ═══ USERS ═══ -->
<div class="section" id="sec-users">
  <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px">
    <div style="font-family:'Syne',sans-serif;font-size:18px;font-weight:800;color:#fff">👤 Users</div>
    <button class="btn btn-primary" onclick="openUserModal()">+ Add User</button>
  </div>
  <div class="toolbar">
    <div class="search-wrap"><input class="search-input" id="user-search" placeholder="Search…" oninput="loadUsers()"></div>
    <select class="sel" id="user-status-filter" onchange="loadUsers()"><option value="">All Status</option><option value="active">Active</option><option value="banned">Banned</option></select>
    <select class="sel" id="user-plan-filter" onchange="loadUsers()"><option value="">All Plans</option></select>
  </div>
  <div class="card" style="padding:0">
    <div class="tbl-wrap">
      <table><thead><tr><th>#</th><th>User</th><th>Plan</th><th>Status</th><th>Joined</th><th>Actions</th></tr></thead>
      <tbody id="users-tbody"></tbody></table>
    </div>
    <div style="padding:10px 16px;border-top:1px solid var(--border)" id="users-pag"></div>
  </div>
</div>

<!-- ═══ PLANS ═══ -->
<div class="section" id="sec-plans">
  <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px">
    <div style="font-family:'Syne',sans-serif;font-size:18px;font-weight:800;color:#fff">💎 Plans</div>
    <button class="btn btn-primary" onclick="openPlanModal()">+ Add Plan</button>
  </div>
  <div id="plans-grid" class="grid3"></div>
</div>

<!-- ═══ TRANSACTIONS ═══ -->
<div class="section" id="sec-transactions">
  <div style="font-family:'Syne',sans-serif;font-size:18px;font-weight:800;color:#fff;margin-bottom:16px">💳 Transactions</div>
  <div class="card" style="padding:0">
    <div class="tbl-wrap">
      <table><thead><tr><th>ID</th><th>User</th><th>Plan</th><th>Amount</th><th>Method</th><th>Status</th><th>Date</th></tr></thead>
      <tbody id="tx-tbody"></tbody></table>
    </div>
  </div>
</div>

<!-- ═══ BLOG POSTS ═══ -->
<div class="section" id="sec-posts">
  <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px">
    <div style="font-family:'Syne',sans-serif;font-size:18px;font-weight:800;color:#fff">✍️ Blog Posts</div>
    <button class="btn btn-primary" onclick="navTo('post-editor')">+ New Post</button>
  </div>
  <div class="card" style="padding:0">
    <div class="tbl-wrap">
      <table><thead><tr><th>Title</th><th>Status</th><th>Views</th><th>Date</th><th>Actions</th></tr></thead>
      <tbody id="posts-tbody"></tbody></table>
    </div>
  </div>
</div>

<!-- ═══ POST EDITOR ═══ -->
<div class="section" id="sec-post-editor">
  <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px">
    <div style="font-family:'Syne',sans-serif;font-size:18px;font-weight:800;color:#fff">✍️ <span id="post-editor-title">New Post</span></div>
    <button class="btn btn-secondary" onclick="navTo('posts')">← Back</button>
  </div>
  <input type="hidden" id="post-id">
  <div style="display:grid;grid-template-columns:1fr 280px;gap:16px;align-items:start">
    <div>
      <div class="card" style="margin-bottom:12px;padding:18px 20px">
        <input id="post-title" class="fi" placeholder="Post title" style="font-size:20px;font-weight:700;border:none;border-bottom:2px solid var(--border);border-radius:0;background:transparent;padding:0 0 10px;margin-bottom:12px">
        <div style="display:flex;align-items:center;gap:8px">
          <span style="font-size:11px;color:var(--muted)">Slug:</span>
          <input id="post-slug" class="fi" style="border:none;border-bottom:1px solid var(--border);border-radius:0;padding:3px 0;background:transparent;font-size:12px;color:var(--muted);flex:1" oninput="this.dataset.manual=1">
        </div>
      </div>
      <div class="card" style="margin-bottom:12px;padding:0;overflow:hidden">
        <div style="padding:5px 8px;background:var(--card);border-bottom:1px solid var(--border);display:flex;flex-wrap:wrap;gap:2px;align-items:center">
          <select class="sel" style="height:26px;font-size:11px;padding:2px 6px" onchange="edFmt(this.value);this.value=''"><option value="">Format</option><option value="h2">H2</option><option value="h3">H3</option><option value="p">Normal</option><option value="blockquote">Quote</option></select>
          <button type="button" class="btn btn-sm btn-secondary" onclick="edCmd('bold')"><b>B</b></button>
          <button type="button" class="btn btn-sm btn-secondary" onclick="edCmd('italic')"><i>I</i></button>
          <button type="button" class="btn btn-sm btn-secondary" onclick="edCmd('insertUnorderedList')">•List</button>
          <button type="button" class="btn btn-sm btn-secondary" onclick="edLink()">🔗</button>
          <button type="button" class="btn btn-sm btn-secondary" onclick="edImg()">🖼️</button>
          <div style="flex:1"></div>
          <button type="button" class="btn btn-sm btn-secondary" onclick="toggleSrc()" id="src-btn">&lt;/&gt;</button>
        </div>
        <div id="post-editor" contenteditable="true" data-placeholder="Write post content…" style="min-height:300px;padding:18px 20px;outline:none;font-size:14px;line-height:1.8;color:var(--text);caret-color:var(--accent)"></div>
        <textarea id="post-content" style="display:none;width:100%;min-height:300px;padding:16px 20px;border:none;font-family:'JetBrains Mono',monospace;font-size:12px;resize:vertical;background:#111827;color:#9ca3af"></textarea>
      </div>
      <div class="card" style="margin-bottom:12px;padding:16px 18px">
        <div style="font-size:12px;font-weight:700;color:var(--text);margin-bottom:8px">Excerpt</div>
        <textarea id="post-excerpt" class="fi" rows="3" style="resize:vertical" placeholder="Short description…"></textarea>
      </div>
    </div>
    <div style="position:sticky;top:70px;display:flex;flex-direction:column;gap:12px">
      <button class="btn btn-primary" style="width:100%;padding:11px;font-size:14px" onclick="savePost()">💾 Save Post</button>
      <div class="card" style="padding:14px 16px">
        <div style="font-size:11px;font-weight:700;color:var(--muted);text-transform:uppercase;letter-spacing:.4px;margin-bottom:8px">Status</div>
        <select id="post-status" class="fi"><option value="published">✅ Published</option><option value="draft">📝 Draft</option></select>
      </div>
      <div class="card" style="padding:14px 16px">
        <div style="font-size:11px;font-weight:700;color:var(--muted);text-transform:uppercase;letter-spacing:.4px;margin-bottom:8px">Featured Image</div>
        <input id="post-image" class="fi" placeholder="https://..." style="font-size:12px" oninput="postImgPreview(this.value)">
        <div id="post-img-preview" style="display:none;margin-top:8px"><img id="post-img-tag" src="" style="width:100%;border-radius:8px;max-height:140px;object-fit:cover"></div>
      </div>
    </div>
  </div>
</div>

<!-- ═══ PAGES ═══ -->
<div class="section" id="sec-pages">
  <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px">
    <div style="font-family:'Syne',sans-serif;font-size:18px;font-weight:800;color:#fff">🗒️ Pages</div>
    <button class="btn btn-primary" onclick="navTo('page-editor')">+ New Page</button>
  </div>
  <div class="card" style="padding:0">
    <div class="tbl-wrap">
      <table><thead><tr><th>Title</th><th>Slug</th><th>Status</th><th>Date</th><th>Actions</th></tr></thead>
      <tbody id="pages-tbody"></tbody></table>
    </div>
  </div>
</div>

<!-- ═══ PAGE EDITOR ═══ -->
<div class="section" id="sec-page-editor">
  <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px">
    <div style="font-family:'Syne',sans-serif;font-size:18px;font-weight:800;color:#fff">🗒️ <span id="page-editor-title">New Page</span></div>
    <button class="btn btn-secondary" onclick="navTo('pages')">← Back</button>
  </div>
  <input type="hidden" id="page-id">
  <div style="display:grid;grid-template-columns:1fr 280px;gap:16px;align-items:start">
    <div>
      <div class="card" style="margin-bottom:12px;padding:18px 20px">
        <input id="page-title-inp" class="fi" placeholder="Page title" style="font-size:20px;font-weight:700;border:none;border-bottom:2px solid var(--border);border-radius:0;background:transparent;padding:0 0 10px;margin-bottom:12px" oninput="pgAutoSlug()">
        <div style="display:flex;align-items:center;gap:8px">
          <span style="font-size:11px;color:var(--muted)">Slug:</span>
          <input id="page-slug" class="fi" style="border:none;border-bottom:1px solid var(--border);border-radius:0;padding:3px 0;background:transparent;font-size:12px;color:var(--muted);flex:1" oninput="this.dataset.manual=1">
        </div>
      </div>
      <div class="card" style="margin-bottom:12px;padding:0;overflow:hidden">
        <div style="padding:5px 8px;background:var(--card);border-bottom:1px solid var(--border);display:flex;flex-wrap:wrap;gap:2px;align-items:center">
          <button type="button" class="btn btn-sm btn-secondary" onclick="pgEdCmd('bold')"><b>B</b></button>
          <button type="button" class="btn btn-sm btn-secondary" onclick="pgEdCmd('italic')"><i>I</i></button>
          <button type="button" class="btn btn-sm btn-secondary" onclick="pgEdCmd('insertUnorderedList')">•List</button>
          <button type="button" class="btn btn-sm btn-secondary" onclick="pgEdLink()">🔗</button>
          <div style="flex:1"></div>
          <button type="button" class="btn btn-sm btn-secondary" onclick="pgToggleSrc()" id="pg-src-btn">&lt;/&gt;</button>
        </div>
        <div id="page-editor" contenteditable="true" data-placeholder="Write page content…" style="min-height:280px;padding:18px 20px;outline:none;font-size:14px;line-height:1.8;color:var(--text);caret-color:var(--accent)"></div>
        <textarea id="page-content" style="display:none;width:100%;min-height:280px;padding:16px 20px;border:none;font-family:'JetBrains Mono',monospace;font-size:12px;resize:vertical;background:#111827;color:#9ca3af"></textarea>
      </div>
    </div>
    <div style="position:sticky;top:70px;display:flex;flex-direction:column;gap:12px">
      <button class="btn btn-primary" style="width:100%;padding:11px;font-size:14px" onclick="savePage()">💾 Save Page</button>
      <div class="card" style="padding:14px 16px">
        <div style="font-size:11px;font-weight:700;color:var(--muted);text-transform:uppercase;letter-spacing:.4px;margin-bottom:8px">Status</div>
        <select id="page-status" class="fi"><option value="published">✅ Published</option><option value="draft">📝 Draft</option></select>
      </div>
      <div class="card" style="padding:14px 16px">
        <div style="font-size:11px;font-weight:700;color:var(--muted);text-transform:uppercase;letter-spacing:.4px;margin-bottom:8px">Featured Image</div>
        <input id="page-image" class="fi" placeholder="https://..." style="font-size:12px" oninput="pgImgPreview(this.value)">
        <div id="page-img-preview" style="display:none;margin-top:8px"><img id="page-img-tag" src="" style="width:100%;border-radius:8px;max-height:140px;object-fit:cover"></div>
      </div>
      <div class="card" style="padding:14px 16px">
        <div style="font-size:11px;font-weight:700;color:var(--muted);text-transform:uppercase;letter-spacing:.4px;margin-bottom:8px">Meta Description</div>
        <textarea id="page-meta" class="fi" rows="3" style="font-size:12px;resize:vertical" placeholder="Meta description…"></textarea>
      </div>
    </div>
  </div>
</div>

<!-- ═══ ADS ═══ -->
<div class="section" id="sec-ads">
  <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px">
    <div style="font-family:'Syne',sans-serif;font-size:18px;font-weight:800;color:#fff">📢 Advertisements</div>
    <button class="btn btn-primary" onclick="openAdModal()">+ Add Ad</button>
  </div>
  <div id="ads-container"></div>
</div>

<!-- ═══ SETTINGS ═══ -->
<div class="section" id="sec-settings">
  <div style="font-family:'Syne',sans-serif;font-size:18px;font-weight:800;color:#fff;margin-bottom:16px">⚙️ Site Settings</div>
  <div class="grid2">
    <div class="card">
      <div class="card-title">General</div>
      <div class="form-group" style="margin-bottom:12px"><label>Site Name</label><input type="text" id="st-name"></div>
      <div class="form-group" style="margin-bottom:12px"><label>Site URL</label><input type="text" id="st-url"></div>
      <div class="form-group" style="margin-bottom:12px"><label>Tagline</label><input type="text" id="st-tagline"></div>
      <div class="form-group" style="margin-bottom:12px"><label>Admin Email</label><input type="email" id="st-email"></div>
      <div class="form-group" style="margin-bottom:12px"><label>Footer Text</label><input type="text" id="st-footer"></div>
      <button class="btn btn-primary" onclick="saveSettings()">💾 Save</button>
    </div>
    <div class="card">
      <div class="card-title">Appearance</div>
      <div class="form-group" style="margin-bottom:12px"><label>Logo Icon (emoji)</label><input type="text" id="st-logo" maxlength="8"></div>
      <div class="form-group" style="margin-bottom:12px"><label>Theme Color</label>
        <div style="display:flex;gap:8px;align-items:center">
          <input type="color" id="st-color" style="width:48px;height:36px;padding:2px;border:1px solid var(--border);border-radius:8px;background:var(--bg);cursor:pointer">
          <input type="text" id="st-color-hex" style="flex:1" placeholder="#6366f1">
        </div>
      </div>
      <div class="form-group" style="margin-bottom:12px"><label>Maintenance Mode</label>
        <div style="display:flex;align-items:center;gap:10px;padding-top:4px">
          <div class="toggle" id="maint-toggle" onclick="this.classList.toggle('on');saveMaintenance(this.classList.contains('on'))"></div>
          <span id="maint-label" style="font-size:13px">Off</span>
        </div>
      </div>
      <button class="btn btn-primary" onclick="saveAppearance()">💾 Save</button>
    </div>
    <div class="card">
      <div class="card-title">Payments</div>
      <div class="form-group" style="margin-bottom:12px"><label>Stripe Public Key</label><input type="text" id="st-stripe-pub" placeholder="pk_live_…"></div>
      <div class="form-group" style="margin-bottom:12px"><label>Stripe Secret Key</label><input type="password" id="st-stripe-sec" placeholder="sk_live_…"></div>
      <div class="form-group" style="margin-bottom:12px"><label>PayPal Client ID</label><input type="text" id="st-pp-id"></div>
      <div class="form-group" style="margin-bottom:12px"><label>PayPal Mode</label>
        <select id="st-pp-mode"><option value="sandbox">Sandbox</option><option value="live">Live</option></select>
      </div>
      <button class="btn btn-primary" onclick="savePayments()">💾 Save</button>
    </div>
    <div class="card">
      <div class="card-title">Email / SMTP</div>
      <div class="form-group" style="margin-bottom:12px"><label>SMTP Host</label><input type="text" id="smtp-host"></div>
      <div class="form-group" style="margin-bottom:12px"><label>SMTP Port</label><input type="number" id="smtp-port"></div>
      <div class="form-group" style="margin-bottom:12px"><label>SMTP User</label><input type="text" id="smtp-user"></div>
      <div class="form-group" style="margin-bottom:12px"><label>SMTP Password</label><input type="password" id="smtp-pass"></div>
      <div class="form-group" style="margin-bottom:12px"><label>From Email</label><input type="email" id="smtp-from"></div>
      <button class="btn btn-primary" onclick="saveSMTP()">💾 Save</button>
    </div>
  </div>
</div>

<!-- ═══ LANGUAGES ═══ -->
<div class="section" id="sec-langs">
  <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px">
    <div style="font-family:'Syne',sans-serif;font-size:18px;font-weight:800;color:#fff">🌐 Languages</div>
  </div>
  <div class="card" style="padding:0">
    <div class="tbl-wrap">
      <table><thead><tr><th>Flag</th><th>Name</th><th>Code</th><th>Default</th><th>Status</th><th>Actions</th></tr></thead>
      <tbody id="langs-tbody"></tbody></table>
    </div>
  </div>
</div>

<!-- ═══ SEO ═══ -->
<div class="section" id="sec-seo">
  <div style="font-family:'Syne',sans-serif;font-size:18px;font-weight:800;color:#fff;margin-bottom:16px">🔍 SEO Settings</div>
  <div class="card" style="max-width:600px">
    <div class="form-group" style="margin-bottom:12px"><label>Meta Title</label><input type="text" id="seo-title"></div>
    <div class="form-group" style="margin-bottom:12px"><label>Meta Description</label><textarea id="seo-desc" rows="3"></textarea></div>
    <div class="form-group" style="margin-bottom:12px"><label>OG Image URL</label><input type="text" id="seo-og"></div>
    <div class="form-group" style="margin-bottom:12px"><label>Google Analytics ID</label><input type="text" id="seo-ga" placeholder="G-XXXXXXXXXX"></div>
    <button class="btn btn-primary" onclick="saveSEO()">💾 Save SEO</button>
  </div>
</div>

<!-- ═══ ADMINS ═══ -->
<div class="section" id="sec-admins">
  <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px">
    <div style="font-family:'Syne',sans-serif;font-size:18px;font-weight:800;color:#fff">🛡️ Admin Users</div>
    <button class="btn btn-primary" onclick="openAdminModal()">+ Add Admin</button>
  </div>
  <div class="card" style="padding:0;margin-bottom:16px">
    <div class="tbl-wrap">
      <table><thead><tr><th>User</th><th>Role</th><th>Last Login</th><th>Status</th><th>Actions</th></tr></thead>
      <tbody id="admins-tbody"></tbody></table>
    </div>
  </div>
  <div class="card" style="max-width:480px">
    <div class="card-title">🔑 Change My Password</div>
    <div class="form-group" style="margin-bottom:12px"><label>Current Password</label><input type="password" id="pw-old"></div>
    <div class="form-group" style="margin-bottom:12px"><label>New Password</label><input type="password" id="pw-new"></div>
    <div class="form-group" style="margin-bottom:12px"><label>Confirm</label><input type="password" id="pw-conf"></div>
    <button class="btn btn-primary" onclick="changeMyPw()">Update Password</button>
  </div>
</div>

<!-- ═══ ACTIVITY ═══ -->
<div class="section" id="sec-activity">
  <div style="font-family:'Syne',sans-serif;font-size:18px;font-weight:800;color:#fff;margin-bottom:16px">📋 Activity Log</div>
  <div class="card" style="padding:0">
    <div class="tbl-wrap">
      <table><thead><tr><th>Time</th><th>Admin</th><th>Action</th><th>IP</th></tr></thead>
      <tbody id="activity-tbody"></tbody></table>
    </div>
  </div>
</div>

</main>

<!-- ═══ MODALS ═══ -->

<!-- Tool Modal -->
<div class="modal-overlay" id="tool-modal">
  <div class="modal">
    <div class="modal-header"><div class="modal-title" id="tool-modal-title">Add Tool</div><div class="modal-close" onclick="closeModal('tool-modal')">✕</div></div>
    <input type="hidden" id="tool-id">
    <div class="form-grid">
      <div class="form-group"><label>Name *</label><input type="text" id="tool-name"></div>
      <div class="form-group"><label>Icon</label><input type="text" id="tool-icon" value="🔧" maxlength="4"></div>
      <div class="form-group"><label>Category</label><select id="tool-cat"><option value="">— None —</option></select></div>
      <div class="form-group"><label>Status</label><select id="tool-status"><option value="active">Active</option><option value="inactive">Inactive</option><option value="coming_soon">Coming Soon</option></select></div>
      <div class="form-group form-full"><label>File Path *</label><input type="text" id="tool-path" placeholder="tools/pdf/word-to-pdf.html"></div>
      <div class="form-group form-full"><label>Description</label><textarea id="tool-desc" rows="2"></textarea></div>
      <div class="form-group"><label>Sort Order</label><input type="number" id="tool-order" value="0"></div>
      <div class="form-group" style="flex-direction:row;align-items:center;gap:16px;padding-top:8px">
        <label style="display:flex;align-items:center;gap:6px;cursor:pointer;font-size:12px;color:var(--muted)"><input type="checkbox" id="tool-featured"> Featured</label>
        <label style="display:flex;align-items:center;gap:6px;cursor:pointer;font-size:12px;color:var(--muted)"><input type="checkbox" id="tool-premium"> Premium</label>
      </div>
    </div>
    <div class="modal-footer"><button class="btn btn-secondary" onclick="closeModal('tool-modal')">Cancel</button><button class="btn btn-primary" onclick="saveTool()">💾 Save</button></div>
  </div>
</div>

<!-- Category Modal -->
<div class="modal-overlay" id="cat-modal">
  <div class="modal">
    <div class="modal-header"><div class="modal-title" id="cat-modal-title">Add Category</div><div class="modal-close" onclick="closeModal('cat-modal')">✕</div></div>
    <input type="hidden" id="cat-id">
    <div class="form-grid">
      <div class="form-group"><label>Name *</label><input type="text" id="cat-name"></div>
      <div class="form-group"><label>Icon</label><input type="text" id="cat-icon" value="📁" maxlength="4"></div>
      <div class="form-group"><label>Color</label><input type="color" id="cat-color" value="#6366f1" style="height:38px;padding:3px"></div>
      <div class="form-group"><label>Sort Order</label><input type="number" id="cat-order" value="0"></div>
      <div class="form-group form-full"><label>Description</label><textarea id="cat-desc" rows="2"></textarea></div>
    </div>
    <div class="modal-footer"><button class="btn btn-secondary" onclick="closeModal('cat-modal')">Cancel</button><button class="btn btn-primary" onclick="saveCat()">💾 Save</button></div>
  </div>
</div>

<!-- User Modal -->
<div class="modal-overlay" id="user-modal">
  <div class="modal">
    <div class="modal-header"><div class="modal-title" id="user-modal-title">Add User</div><div class="modal-close" onclick="closeModal('user-modal')">✕</div></div>
    <input type="hidden" id="user-id">
    <div class="form-grid">
      <div class="form-group"><label>Name</label><input type="text" id="user-name"></div>
      <div class="form-group"><label>Email *</label><input type="email" id="user-email"></div>
      <div class="form-group" id="user-pw-wrap"><label>Password</label><input type="password" id="user-pass"></div>
      <div class="form-group"><label>Plan</label><select id="user-plan"></select></div>
      <div class="form-group"><label>Status</label><select id="user-status"><option value="active">Active</option><option value="banned">Banned</option></select></div>
    </div>
    <div class="modal-footer"><button class="btn btn-secondary" onclick="closeModal('user-modal')">Cancel</button><button class="btn btn-primary" onclick="saveUser()">💾 Save</button></div>
  </div>
</div>

<!-- Plan Modal -->
<div class="modal-overlay" id="plan-modal">
  <div class="modal">
    <div class="modal-header"><div class="modal-title" id="plan-modal-title">Add Plan</div><div class="modal-close" onclick="closeModal('plan-modal')">✕</div></div>
    <input type="hidden" id="plan-id">
    <div class="form-grid">
      <div class="form-group"><label>Name *</label><input type="text" id="plan-name"></div>
      <div class="form-group"><label>Price (USD)</label><input type="number" id="plan-price" step="0.01" min="0" value="0"></div>
      <div class="form-group"><label>Billing</label><select id="plan-cycle"><option value="monthly">Monthly</option><option value="yearly">Yearly</option><option value="lifetime">Lifetime</option></select></div>
      <div class="form-group"><label>Tool Limit (-1=unlimited)</label><input type="number" id="plan-limit" value="-1"></div>
      <div class="form-group form-full"><label>Features (one per line)</label><textarea id="plan-features" rows="5"></textarea></div>
      <div class="form-group"><label><input type="checkbox" id="plan-popular"> Mark as Popular</label></div>
    </div>
    <div class="modal-footer"><button class="btn btn-secondary" onclick="closeModal('plan-modal')">Cancel</button><button class="btn btn-primary" onclick="savePlan()">💾 Save</button></div>
  </div>
</div>

<!-- Admin Modal -->
<div class="modal-overlay" id="admin-modal">
  <div class="modal">
    <div class="modal-header"><div class="modal-title" id="admin-modal-title">Add Admin</div><div class="modal-close" onclick="closeModal('admin-modal')">✕</div></div>
    <input type="hidden" id="adm-id">
    <div class="form-grid">
      <div class="form-group"><label>Username *</label><input type="text" id="adm-user"></div>
      <div class="form-group"><label>Email *</label><input type="email" id="adm-email"></div>
      <div class="form-group"><label>Role</label><select id="adm-role"><option value="admin">Admin</option><option value="editor">Editor</option><option value="superadmin">Superadmin</option></select></div>
      <div class="form-group"><label>Password</label><input type="password" id="adm-pass" placeholder="Leave blank to keep"></div>
    </div>
    <div class="modal-footer"><button class="btn btn-secondary" onclick="closeModal('admin-modal')">Cancel</button><button class="btn btn-primary" onclick="saveAdmin()">💾 Save</button></div>
  </div>
</div>

<!-- Ad Modal -->
<div class="modal-overlay" id="ad-modal">
  <div class="modal">
    <div class="modal-header"><div class="modal-title">Add Ad</div><div class="modal-close" onclick="closeModal('ad-modal')">✕</div></div>
    <input type="hidden" id="ad-id">
    <div class="form-grid">
      <div class="form-group"><label>Name</label><input type="text" id="ad-name"></div>
      <div class="form-group"><label>Slot</label><select id="ad-slot"><option value="header">Header</option><option value="sidebar">Sidebar</option><option value="incontent">In-Content</option><option value="footer">Footer</option></select></div>
      <div class="form-group form-full"><label>Ad Code (HTML)</label><textarea id="ad-code" rows="5" style="font-family:'JetBrains Mono',monospace;font-size:12px"></textarea></div>
    </div>
    <div class="modal-footer"><button class="btn btn-secondary" onclick="closeModal('ad-modal')">Cancel</button><button class="btn btn-primary" onclick="saveAd()">💾 Save</button></div>
  </div>
</div>

<div id="toast-container"></div>

<script>
const API = 'api/index.php';

async function api(action, data={}) {
  const res = await fetch(`${API}?action=${action}`, {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data),credentials:'include'});
  return res.json();
}

function toast(msg, type='success') {
  const icons={success:'✅',error:'❌',info:'ℹ️'};
  const el=document.createElement('div');
  el.className=`toast ${type}`;
  el.innerHTML=`<span>${icons[type]||'•'}</span><span>${msg}</span>`;
  document.getElementById('toast-container').appendChild(el);
  setTimeout(()=>el.remove(),4000);
}

function openModal(id){document.getElementById(id).classList.add('open');}
function closeModal(id){document.getElementById(id).classList.remove('open');}
function fmtNum(n){return Number(n||0).toLocaleString();}
function fmtMoney(n){return'$'+parseFloat(n||0).toFixed(2);}
function fmtDate(d){if(!d)return'—';return new Date(d).toLocaleDateString('en-US',{month:'short',day:'numeric',year:'numeric'});}
function esc(s){return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');}
function slugify(s){return String(s||'').toLowerCase().trim().replace(/[^a-z0-9\s-]/g,'').replace(/\s+/g,'-').replace(/-+/g,'-');}

function statusBadge(s){
  const map={active:'b-green',inactive:'b-red',coming_soon:'b-yellow',completed:'b-green',pending:'b-yellow',failed:'b-red',superadmin:'b-orange',admin:'b-blue',editor:'b-purple',banned:'b-red'};
  return`<span class="badge ${map[s]||'b-gray'}">${s.replace('_',' ')}</span>`;
}

// ── NAVIGATION ──
document.querySelectorAll('.nav-item[data-sec]').forEach(el=>{
  el.addEventListener('click',function(){
    const sec=this.dataset.sec;
    document.querySelectorAll('.nav-item').forEach(n=>n.classList.remove('active'));
    document.querySelectorAll('.section').forEach(s=>s.classList.remove('active'));
    this.classList.add('active');
    document.getElementById('sec-'+sec).classList.add('active');
    document.getElementById('page-title').textContent=this.textContent.trim().replace(/[0-9—]/g,'').trim();
    const loaders={dashboard:loadDashboard,tools:loadTools,categories:loadCategories,analytics:loadAnalytics,users:loadUsers,plans:loadPlans,transactions:loadTx,posts:loadPosts,pages:loadPages,ads:loadAds,settings:loadSettings,langs:loadLangs,admins:loadAdmins,seo:loadSEO,activity:loadActivity};
    if(loaders[sec])loaders[sec]();
    if(window.innerWidth<=768)closeSidebar();
  });
});

function navTo(sec){
  document.querySelectorAll('.section').forEach(s=>s.classList.remove('active'));
  document.getElementById('sec-'+sec)?.classList.add('active');
}

document.querySelectorAll('.modal-overlay').forEach(o=>{o.addEventListener('click',e=>{if(e.target===o)o.classList.remove('open');});});

// ── MOBILE SIDEBAR ──
function toggleSidebar(){document.getElementById('sidebar').classList.toggle('open');document.getElementById('sidebar-overlay').classList.toggle('open');}
function closeSidebar(){document.getElementById('sidebar').classList.remove('open');document.getElementById('sidebar-overlay').classList.remove('open');}

// ── INIT ──
async function init(){
  loadDashboard();
  setInterval(()=>document.getElementById('clock').textContent=new Date().toLocaleTimeString(),1000);
}

// ── MANUAL SYNC ──
async function manualSync(){
  const btn=document.querySelector('.sync-btn');
  if(btn)btn.textContent='🔄 Syncing…';
  const r=await api('sync_tools');
  if(r.success){
    toast(`✅ Sync done: ${r.data.added} added, ${r.data.skipped} skipped`);
    loadTools();
    loadDashboard();
  } else toast(r.error||'Sync failed','error');
  if(btn)btn.textContent='🔄 Sync Tools';
}

// ── DASHBOARD ──
async function loadDashboard(){
  const r=await api('dashboard');
  if(!r.success)return;const d=r.data;
  document.getElementById('s-tools').textContent=fmtNum(d.tools_active);
  document.getElementById('s-users').textContent=fmtNum(d.users_total);
  document.getElementById('s-rev').textContent=fmtMoney(d.revenue_total);
  document.getElementById('s-views').textContent=fmtNum(d.views_week);
  document.getElementById('nb-tools').textContent=d.tools_active;
  const maxV=d.top_tools[0]?.views_week||1;
  document.getElementById('top-tools-list').innerHTML=d.top_tools.map((t,i)=>`
    <div style="display:flex;align-items:center;gap:10px;margin-bottom:10px">
      <span style="font-size:11px;color:var(--muted);width:18px;text-align:center;font-weight:700">${i+1}</span>
      <div style="flex:1"><div style="font-size:12px;font-weight:700;margin-bottom:3px">${esc(t.name)}</div>
      <div class="progress-bar"><div class="progress-fill" style="width:${Math.round((t.views_week/maxV)*100)}%"></div></div></div>
      <span style="font-size:11px;color:var(--accent);font-weight:700">${fmtNum(t.views_week)}</span>
    </div>`).join('');
  document.getElementById('new-users-table').innerHTML=d.new_users.map(u=>`
    <tr><td><div style="font-size:12px;font-weight:600">${esc(u.email)}</div></td>
    <td><span class="badge b-blue">${esc(u.plan_name||'Free')}</span></td>
    <td style="font-size:11px;color:var(--muted)">${fmtDate(u.created_at)}</td></tr>`).join('')||'<tr><td colspan="3" style="text-align:center;color:var(--muted);padding:20px">No users yet</td></tr>';
}

// ── TOOLS ──
let toolPage=1;
async function loadTools(page=1){
  toolPage=page;
  const r=await api('tools_list',{q:document.getElementById('tool-search').value,cat:document.getElementById('tool-cat-filter').value,status:document.getElementById('tool-status-filter').value,page});
  if(!r.success)return;const d=r.data;
  document.getElementById('tool-count-lbl').textContent=`${fmtNum(d.total)} tools`;
  document.getElementById('tools-tbody').innerHTML=d.tools.map((t,i)=>`
    <tr>
      <td style="color:var(--muted)">${(page-1)*20+i+1}</td>
      <td><div class="tbl-name">${esc(t.icon||'🔧')} ${esc(t.name)}</div></td>
      <td><code style="font-size:10px;color:var(--muted);font-family:'JetBrains Mono',monospace">${esc(t.path||'—')}</code></td>
      <td><span class="badge b-blue">${esc(t.cat_name||'—')}</span></td>
      <td><span style="font-weight:700">${fmtNum(t.views_week)}</span></td>
      <td id="ts-${t.id}">${statusBadge(t.status)}</td>
      <td><div class="toggle ${t.is_featured=='1'?'on':''}" onclick="toggleFeatured(${t.id},this)"></div></td>
      <td><div style="display:flex;gap:4px">
        <button class="btn btn-sm btn-secondary" onclick="editTool(${t.id})">✏️</button>
        <button class="btn btn-sm ${t.status==='active'?'btn-secondary':'btn-green'}" onclick="toggleTool(${t.id},this,'${t.status}')">${t.status==='active'?'⏸':'▶'}</button>
        <button class="btn btn-sm btn-danger" onclick="deleteTool(${t.id},'${esc(t.name)}')">🗑</button>
      </div></td>
    </tr>`).join('')||'<tr><td colspan="8" style="text-align:center;padding:30px;color:var(--muted)">No tools found</td></tr>';
  // populate cat filter
  const opts=r.data.categories?.map(c=>`<option value="${c.id}">${esc(c.icon)} ${esc(c.name)}</option>`).join('')||'';
  ['tool-cat-filter','tool-cat'].forEach(id=>{const el=document.getElementById(id);if(el&&!el.dataset.loaded){el.innerHTML=(el.id.includes('filter')?'<option value="">All Categories</option>':'')+opts;el.dataset.loaded=1;}});
}

function openToolModal(t=null){
  document.getElementById('tool-modal-title').textContent=t?'Edit Tool':'Add Tool';
  document.getElementById('tool-id').value=t?.id||'';
  document.getElementById('tool-name').value=t?.name||'';
  document.getElementById('tool-icon').value=t?.icon||'🔧';
  document.getElementById('tool-cat').value=t?.category_id||'';
  document.getElementById('tool-status').value=t?.status||'active';
  document.getElementById('tool-path').value=t?.path||'';
  document.getElementById('tool-desc').value=t?.description||'';
  document.getElementById('tool-order').value=t?.sort_order||0;
  document.getElementById('tool-featured').checked=t?.is_featured=='1';
  document.getElementById('tool-premium').checked=t?.is_premium=='1';
  openModal('tool-modal');
}
async function editTool(id){const r=await api('tool_get',{id});if(r.success)openToolModal(r.data);}
async function saveTool(){
  const r=await api('tool_save',{id:document.getElementById('tool-id').value,name:document.getElementById('tool-name').value,icon:document.getElementById('tool-icon').value,category_id:document.getElementById('tool-cat').value,status:document.getElementById('tool-status').value,path:document.getElementById('tool-path').value,description:document.getElementById('tool-desc').value,sort_order:document.getElementById('tool-order').value,is_featured:document.getElementById('tool-featured').checked?1:0,is_premium:document.getElementById('tool-premium').checked?1:0});
  if(r.success){toast(r.data.msg);closeModal('tool-modal');loadTools(toolPage);}else toast(r.error,'error');
}
async function deleteTool(id,name){if(!confirm(`Delete "${name}"?`))return;const r=await api('tool_delete',{id});if(r.success){toast('Deleted');loadTools(toolPage);}else toast(r.error,'error');}
async function toggleTool(id,btn,status){const r=await api('tool_toggle',{id});if(r.success){const s=r.data.status;document.getElementById('ts-'+id).innerHTML=statusBadge(s);btn.textContent=s==='active'?'⏸':'▶';btn.className='btn btn-sm '+(s==='active'?'btn-secondary':'btn-green');}else toast(r.error,'error');}
async function toggleFeatured(id,el){const t=await api('tool_get',{id});if(!t.success)return;const will=!el.classList.contains('on');const r=await api('tool_save',{...t.data,is_featured:will?1:0});if(r.success)el.classList.toggle('on',will);else toast(r.error,'error');}

// ── CATEGORIES ──
async function loadCategories(){
  const r=await api('cats_list');if(!r.success)return;
  document.getElementById('cats-tbody').innerHTML=r.data.map(c=>`
    <tr><td style="font-size:18px">${esc(c.icon)}</td><td><div class="tbl-name">${esc(c.name)}</div></td>
    <td style="font-size:11px;color:var(--muted);font-family:'JetBrains Mono',monospace">${esc(c.slug)}</td>
    <td><span class="badge b-blue">${c.tool_count} tools</span></td>
    <td><span style="display:inline-block;width:14px;height:14px;background:${esc(c.color)};border-radius:4px"></span></td>
    <td>${c.status=='1'?'<span class="badge b-green">Active</span>':'<span class="badge b-red">Inactive</span>'}</td>
    <td><div style="display:flex;gap:4px"><button class="btn btn-sm btn-secondary" onclick='editCat(${JSON.stringify(c)})'>✏️</button><button class="btn btn-sm btn-danger" onclick="deleteCat(${c.id},'${esc(c.name)}')">🗑</button></div></td>
    </tr>`).join('');
}
function openCatModal(c=null){document.getElementById('cat-modal-title').textContent=c?'Edit Category':'Add Category';document.getElementById('cat-id').value=c?.id||'';document.getElementById('cat-name').value=c?.name||'';document.getElementById('cat-icon').value=c?.icon||'📁';document.getElementById('cat-color').value=c?.color||'#6366f1';document.getElementById('cat-order').value=c?.sort_order||0;document.getElementById('cat-desc').value=c?.description||'';openModal('cat-modal');}
function editCat(c){openCatModal(c);}
async function saveCat(){const r=await api('cat_save',{id:document.getElementById('cat-id').value,name:document.getElementById('cat-name').value,icon:document.getElementById('cat-icon').value,color:document.getElementById('cat-color').value,sort_order:document.getElementById('cat-order').value,description:document.getElementById('cat-desc').value,status:1});if(r.success){toast(r.data.msg);closeModal('cat-modal');loadCategories();}else toast(r.error,'error');}
async function deleteCat(id,name){if(!confirm(`Delete "${name}"?`))return;const r=await api('cat_delete',{id});if(r.success){toast('Deleted');loadCategories();}else toast(r.error,'error');}

// ── ANALYTICS ──
async function loadAnalytics(){
  const r=await api('analytics',{days:30});if(!r.success)return;const d=r.data;
  document.getElementById('a-total').textContent=fmtNum(d.total_views);
  document.getElementById('a-countries').textContent=d.countries.length;
  document.getElementById('a-pages').textContent=d.top_pages.length;
  document.getElementById('a-tools-v').textContent=fmtNum(d.total_views);
  const maxC=d.countries[0]?.hits||1;
  document.getElementById('countries-list').innerHTML=d.countries.map(c=>`
    <div style="display:flex;align-items:center;gap:10px;margin-bottom:8px">
      <span style="width:28px;font-size:12px;font-weight:700;color:var(--muted)">${esc(c.country||'??')}</span>
      <div style="flex:1"><div class="progress-bar"><div class="progress-fill" style="width:${Math.round((c.hits/maxC)*100)}%"></div></div></div>
      <span style="font-size:11px;color:var(--accent);font-weight:700">${fmtNum(c.hits)}</span>
    </div>`).join('')||'<div style="color:var(--muted);font-size:12px">No data</div>';
}

// ── USERS ──
let userPage=1;
async function loadUsers(page=1){
  userPage=page;
  const r=await api('users_list',{q:document.getElementById('user-search').value,status:document.getElementById('user-status-filter').value,plan:document.getElementById('user-plan-filter').value,page});
  if(!r.success)return;const d=r.data;
  document.getElementById('users-tbody').innerHTML=d.users.map((u,i)=>`
    <tr><td style="color:var(--muted)">${(page-1)*20+i+1}</td>
    <td><div style="display:flex;align-items:center;gap:8px">
      <div style="width:28px;height:28px;border-radius:7px;background:linear-gradient(135deg,var(--blue),var(--purple));display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:700;color:#fff">${(u.name||u.email||'U')[0].toUpperCase()}</div>
      <div><div class="tbl-name">${esc(u.name||'—')}</div><div class="tbl-sub">${esc(u.email)}</div></div></div></td>
    <td><span class="badge b-blue">${esc(u.plan_name||'Free')}</span></td>
    <td>${statusBadge(u.status)}</td>
    <td style="font-size:11px;color:var(--muted)">${fmtDate(u.created_at)}</td>
    <td><div style="display:flex;gap:4px">
      <button class="btn btn-sm btn-secondary" onclick="editUser(${u.id})">✏️</button>
      <button class="btn btn-sm btn-danger" onclick="banUser(${u.id},'${u.status}')">🚫</button>
      <button class="btn btn-sm btn-danger" onclick="delUser(${u.id})">🗑</button>
    </div></td></tr>`).join('')||'<tr><td colspan="6" style="text-align:center;padding:20px;color:var(--muted)">No users</td></tr>';
}
function openUserModal(u=null){document.getElementById('user-modal-title').textContent=u?'Edit User':'Add User';document.getElementById('user-id').value=u?.id||'';document.getElementById('user-name').value=u?.name||'';document.getElementById('user-email').value=u?.email||'';document.getElementById('user-pass').value='';document.getElementById('user-status').value=u?.status||'active';document.getElementById('user-pw-wrap').style.display=u?'none':'flex';openModal('user-modal');}
async function editUser(id){const r=await api('user_get',{id});if(r.success)openUserModal(r.data);}
async function saveUser(){const r=await api('user_save',{id:document.getElementById('user-id').value,name:document.getElementById('user-name').value,email:document.getElementById('user-email').value,password:document.getElementById('user-pass').value,plan_id:document.getElementById('user-plan').value,status:document.getElementById('user-status').value});if(r.success){toast(r.data.msg);closeModal('user-modal');loadUsers();}else toast(r.error,'error');}
async function banUser(id,status){const r=await api('user_ban',{id,status:status==='banned'?'active':'banned'});if(r.success){toast(r.data.msg);loadUsers();}else toast(r.error,'error');}
async function delUser(id){if(!confirm('Delete user?'))return;const r=await api('user_delete',{id});if(r.success){toast('Deleted');loadUsers();}else toast(r.error,'error');}

// ── PLANS ──
async function loadPlans(){
  const r=await api('plans_list');if(!r.success)return;
  document.getElementById('plans-grid').innerHTML=r.data.map(p=>{const feats=JSON.parse(p.features||'[]');return`
    <div class="card" style="${p.is_popular=='1'?'border-color:var(--accent)':''};position:relative">
      ${p.is_popular=='1'?'<div style="position:absolute;top:-10px;left:50%;transform:translateX(-50%);background:var(--accent);color:#fff;font-size:10px;font-weight:700;padding:2px 12px;border-radius:20px;">⭐ POPULAR</div>':''}
      <div style="text-align:center;margin-bottom:14px"><div style="font-family:\'Syne\',sans-serif;font-size:18px;font-weight:800;color:#fff">${esc(p.name)}</div>
      <div style="font-family:\'Syne\',sans-serif;font-size:30px;font-weight:900;color:var(--accent)">${fmtMoney(p.price)}<span style="font-size:12px;color:var(--muted)">/${esc(p.billing_cycle)}</span></div></div>
      <ul style="list-style:none;margin-bottom:14px">${feats.map(f=>`<li style="font-size:12px;padding:4px 0;color:var(--text);display:flex;gap:6px"><span style="color:var(--green)">✓</span>${esc(f)}</li>`).join('')}</ul>
      <div style="display:flex;gap:6px"><button class="btn btn-secondary" style="flex:1" onclick='editPlan(${JSON.stringify(p)})'>✏️ Edit</button><button class="btn btn-danger" onclick="delPlan(${p.id},'${esc(p.name)}')">🗑</button></div>
    </div>`;}).join('');
  const opts=r.data.map(p=>`<option value="${p.id}">${esc(p.name)}</option>`).join('');
  ['user-plan','user-plan-filter'].forEach(id=>{const el=document.getElementById(id);if(el)el.innerHTML=(id.includes('filter')?'<option value="">All Plans</option>':'')+opts;});
}
function openPlanModal(p=null){document.getElementById('plan-modal-title').textContent=p?'Edit Plan':'Add Plan';document.getElementById('plan-id').value=p?.id||'';document.getElementById('plan-name').value=p?.name||'';document.getElementById('plan-price').value=p?.price||0;document.getElementById('plan-cycle').value=p?.billing_cycle||'monthly';document.getElementById('plan-limit').value=p?.tool_limit??-1;document.getElementById('plan-features').value=JSON.parse(p?.features||'[]').join('\n');document.getElementById('plan-popular').checked=p?.is_popular=='1';openModal('plan-modal');}
function editPlan(p){openPlanModal(p);}
async function savePlan(){const r=await api('plan_save',{id:document.getElementById('plan-id').value,name:document.getElementById('plan-name').value,price:document.getElementById('plan-price').value,billing_cycle:document.getElementById('plan-cycle').value,tool_limit:document.getElementById('plan-limit').value,features:document.getElementById('plan-features').value,is_popular:document.getElementById('plan-popular').checked?1:0});if(r.success){toast(r.data.msg);closeModal('plan-modal');loadPlans();}else toast(r.error,'error');}
async function delPlan(id,name){if(!confirm(`Delete plan "${name}"?`))return;const r=await api('plan_delete',{id});if(r.success){toast('Deleted');loadPlans();}else toast(r.error,'error');}

// ── TRANSACTIONS ──
async function loadTx(){
  const r=await api('tx_list',{page:1});if(!r.success)return;
  document.getElementById('tx-tbody').innerHTML=r.data.txs.map(t=>`
    <tr><td style="color:var(--muted);font-size:11px">#${t.id}</td>
    <td style="font-size:12px">${esc(t.user_email||'—')}</td>
    <td><span class="badge b-orange">${esc(t.plan_name||'—')}</span></td>
    <td style="font-weight:700;color:var(--green)">${fmtMoney(t.amount)}</td>
    <td style="font-size:11px;color:var(--muted)">${esc(t.payment_method||'—')}</td>
    <td>${statusBadge(t.status)}</td>
    <td style="font-size:11px;color:var(--muted)">${fmtDate(t.created_at)}</td></tr>`).join('')||'<tr><td colspan="7" style="text-align:center;padding:20px;color:var(--muted)">No transactions</td></tr>';
}

// ── BLOG POSTS ──
async function loadPosts(){
  const r=await api('posts_list',{page:1});if(!r.success)return;
  document.getElementById('posts-tbody').innerHTML=(r.data.posts||[]).map(p=>`
    <tr><td><div class="tbl-name">${esc(p.title)}</div></td>
    <td><span class="badge ${p.status==='published'?'b-green':'b-gray'}">${p.status}</span></td>
    <td style="font-size:11px;color:var(--muted)">${fmtNum(p.views)}</td>
    <td style="font-size:11px;color:var(--muted)">${fmtDate(p.created_at)}</td>
    <td><div style="display:flex;gap:4px">
      <button class="btn btn-sm btn-secondary" onclick="editPost(${p.id})">✏️</button>
      <button class="btn btn-sm btn-danger" onclick="delPost(${p.id})">🗑</button>
    </div></td></tr>`).join('')||'<tr><td colspan="5" style="text-align:center;padding:20px;color:var(--muted)">No posts</td></tr>';
}

// Post editor
let postSrcMode=false;
function edCmd(c){document.getElementById('post-editor').focus();document.execCommand(c,false,null);}
function edFmt(t){if(!t)return;document.getElementById('post-editor').focus();document.execCommand('formatBlock',false,t);}
function edLink(){const u=prompt('URL:','https://');if(u){document.getElementById('post-editor').focus();document.execCommand('createLink',false,u);}}
function edImg(){const u=prompt('Image URL:','https://');if(u){document.getElementById('post-editor').focus();document.execCommand('insertImage',false,u);}}
function toggleSrc(){const ed=document.getElementById('post-editor'),src=document.getElementById('post-content'),btn=document.getElementById('src-btn');postSrcMode=!postSrcMode;if(postSrcMode){src.value=ed.innerHTML;ed.style.display='none';src.style.display='block';btn.style.background='var(--accent)';}else{ed.innerHTML=src.value;src.style.display='none';ed.style.display='block';btn.style.background='';}}
function postImgPreview(v){if(v.startsWith('http')){document.getElementById('post-img-tag').src=v;document.getElementById('post-img-preview').style.display='block';}else document.getElementById('post-img-preview').style.display='none';}
document.getElementById('post-title').addEventListener('input',function(){const s=document.getElementById('post-slug');if(!s.dataset.manual)s.value=slugify(this.value);});

async function savePost(){
  if(!postSrcMode)document.getElementById('post-content').value=document.getElementById('post-editor').innerHTML;
  const id=document.getElementById('post-id').value;const title=document.getElementById('post-title').value.trim();if(!title)return toast('Title required','error');
  const data={title,slug:document.getElementById('post-slug').value||slugify(title),content:document.getElementById('post-content').value,excerpt:document.getElementById('post-excerpt').value,status:document.getElementById('post-status').value,featured_image:document.getElementById('post-image').value};
  if(id)data.id=id;
  const r=await api('post_save',data);if(r.success){toast('Post saved!');navTo('posts');loadPosts();}else toast(r.error,'error');
}
async function editPost(id){
  const r=await api('post_get',{id});if(!r.success)return;const p=r.data;
  document.getElementById('post-id').value=p.id;document.getElementById('post-title').value=p.title;
  document.getElementById('post-slug').value=p.slug;document.getElementById('post-content').value=p.content||'';
  document.getElementById('post-editor').innerHTML=p.content||'';document.getElementById('post-excerpt').value=p.excerpt||'';
  document.getElementById('post-status').value=p.status;document.getElementById('post-image').value=p.featured_image||'';
  if(p.featured_image)postImgPreview(p.featured_image);
  document.getElementById('post-editor-title').textContent='Edit Post';
  navTo('post-editor');
}
async function delPost(id){if(!confirm('Delete?'))return;const r=await api('post_delete',{id});if(r.success){toast('Deleted');loadPosts();}else toast(r.error,'error');}

// ── PAGES ──
async function loadPages(){
  const r=await api('pages_list');if(!r.success)return;
  document.getElementById('pages-tbody').innerHTML=(r.data||[]).map(p=>`
    <tr><td><strong>${esc(p.title)}</strong></td>
    <td><code style="font-size:10px;font-family:'JetBrains Mono',monospace;color:var(--muted)">${esc(p.slug)}</code></td>
    <td><span class="badge ${p.status==='published'?'b-green':'b-gray'}">${p.status}</span></td>
    <td style="font-size:11px;color:var(--muted)">${(p.created_at||'').split('T')[0]}</td>
    <td><div style="display:flex;gap:4px">
      <button class="btn btn-sm btn-secondary" onclick="editPage(${p.id})">✏️</button>
      <button class="btn btn-sm btn-danger" onclick="delPage(${p.id})">🗑</button>
    </div></td></tr>`).join('')||'<tr><td colspan="5" style="text-align:center;padding:20px;color:var(--muted)">No pages</td></tr>';
}

// Page editor
let pgSrcMode=false;
function pgEdCmd(c){document.getElementById('page-editor').focus();document.execCommand(c,false,null);}
function pgEdLink(){const u=prompt('URL:','https://');if(u){document.getElementById('page-editor').focus();document.execCommand('createLink',false,u);}}
function pgToggleSrc(){const ed=document.getElementById('page-editor'),src=document.getElementById('page-content'),btn=document.getElementById('pg-src-btn');pgSrcMode=!pgSrcMode;if(pgSrcMode){src.value=ed.innerHTML;ed.style.display='none';src.style.display='block';btn.style.background='var(--accent)';}else{ed.innerHTML=src.value;src.style.display='none';ed.style.display='block';btn.style.background='';}}
function pgAutoSlug(){const s=document.getElementById('page-slug');if(!s.dataset.manual)s.value=slugify(document.getElementById('page-title-inp').value);}
function pgImgPreview(v){if(v.startsWith('http')){document.getElementById('page-img-tag').src=v;document.getElementById('page-img-preview').style.display='block';}else document.getElementById('page-img-preview').style.display='none';}

async function savePage(){
  if(!pgSrcMode)document.getElementById('page-content').value=document.getElementById('page-editor').innerHTML;
  const id=document.getElementById('page-id').value;const title=document.getElementById('page-title-inp').value.trim();if(!title)return toast('Title required','error');
  const data={title,slug:document.getElementById('page-slug').value||slugify(title),content:document.getElementById('page-content').value,status:document.getElementById('page-status').value,meta_desc:document.getElementById('page-meta').value,featured_image:document.getElementById('page-image').value};
  if(id)data.id=id;
  const r=await api('page_save',data);if(r.success){toast('Page saved!');navTo('pages');loadPages();}else toast(r.error,'error');
}
async function editPage(id){
  const r=await api('page_get',{id});if(!r.success)return;const p=r.data;
  document.getElementById('page-id').value=p.id;document.getElementById('page-title-inp').value=p.title;
  document.getElementById('page-slug').value=p.slug;document.getElementById('page-content').value=p.content||'';
  document.getElementById('page-editor').innerHTML=p.content||'';document.getElementById('page-status').value=p.status;
  document.getElementById('page-meta').value=p.meta_desc||'';document.getElementById('page-image').value=p.featured_image||'';
  if(p.featured_image)pgImgPreview(p.featured_image);
  document.getElementById('page-editor-title').textContent='Edit Page';
  navTo('page-editor');
}
async function delPage(id){if(!confirm('Delete?'))return;const r=await api('page_delete',{id});if(r.success){toast('Deleted');loadPages();}else toast(r.error,'error');}

// ── ADS ──
async function loadAds(){
  const r=await api('ads_list');if(!r.success)return;
  document.getElementById('ads-container').innerHTML=['header','sidebar','incontent','footer'].map(slot=>{
    const ads=r.data.filter(a=>a.slot===slot);
    return`<div class="card" style="margin-bottom:12px"><div class="card-title" style="display:flex;justify-content:space-between"><span>📢 ${slot}</span><button class="btn btn-sm btn-primary" onclick="openAdModal('${slot}')">+ Add</button></div>${ads.length?ads.map(a=>`<div style="background:var(--bg);border:1px solid var(--border);border-radius:8px;padding:10px;margin-bottom:8px;display:flex;align-items:center;gap:10px"><div style="flex:1"><div style="font-weight:700;font-size:12px">${esc(a.name)}</div></div><button class="btn btn-sm btn-danger" onclick="delAd(${a.id})">🗑</button></div>`).join(''):'<div style="color:var(--muted);font-size:12px">No ads</div>'}</div>`;
  }).join('');
}
function openAdModal(slot='header'){document.getElementById('ad-id').value='';document.getElementById('ad-name').value='';document.getElementById('ad-slot').value=slot;document.getElementById('ad-code').value='';openModal('ad-modal');}
async function saveAd(){const r=await api('ad_save',{id:document.getElementById('ad-id').value,name:document.getElementById('ad-name').value,slot:document.getElementById('ad-slot').value,type:'custom_html',code:document.getElementById('ad-code').value,status:1});if(r.success){toast(r.data.msg);closeModal('ad-modal');loadAds();}else toast(r.error,'error');}
async function delAd(id){if(!confirm('Delete?'))return;const r=await api('ad_delete',{id});if(r.success){toast('Deleted');loadAds();}else toast(r.error,'error');}

// ── SETTINGS ──
async function loadSettings(){
  const g=await api('settings_get',{group:'general'});if(!g.success)return;const d=g.data;
  document.getElementById('st-name').value=d.site_name||'';document.getElementById('st-url').value=d.site_url||'';
  document.getElementById('st-tagline').value=d.site_tagline||'';document.getElementById('st-email').value=d.admin_email||'';
  document.getElementById('st-footer').value=d.footer_text||'';document.getElementById('st-logo').value=d.logo_icon||'⚡';
  const c=d.theme_color||'#6366f1';document.getElementById('st-color').value=c;document.getElementById('st-color-hex').value=c;
  document.getElementById('maint-toggle').classList.toggle('on',d.maintenance_mode==='1');
  document.getElementById('maint-label').textContent=d.maintenance_mode==='1'?'ON':'Off';
  const p=await api('settings_get',{group:'payments'});if(p.success){const pd=p.data;document.getElementById('st-stripe-pub').value=pd.stripe_public_key||'';document.getElementById('st-pp-id').value=pd.paypal_client_id||'';document.getElementById('st-pp-mode').value=pd.paypal_mode||'sandbox';}
  const e=await api('settings_get',{group:'email'});if(e.success){const ed=e.data;document.getElementById('smtp-host').value=ed.smtp_host||'';document.getElementById('smtp-port').value=ed.smtp_port||587;document.getElementById('smtp-user').value=ed.smtp_user||'';document.getElementById('smtp-from').value=ed.smtp_from||'';}
}
async function saveSettings(){const r=await api('settings_save',{settings:{site_name:document.getElementById('st-name').value,site_url:document.getElementById('st-url').value,site_tagline:document.getElementById('st-tagline').value,admin_email:document.getElementById('st-email').value,footer_text:document.getElementById('st-footer').value}});if(r.success)toast('Saved!');else toast(r.error,'error');}
async function saveAppearance(){const c=document.getElementById('st-color-hex').value||document.getElementById('st-color').value;const r=await api('settings_save',{settings:{logo_icon:document.getElementById('st-logo').value,theme_color:c}});if(r.success)toast('Saved!');else toast(r.error,'error');}
async function savePayments(){const r=await api('settings_save',{settings:{stripe_public_key:document.getElementById('st-stripe-pub').value,stripe_secret_key:document.getElementById('st-stripe-sec').value,paypal_client_id:document.getElementById('st-pp-id').value,paypal_mode:document.getElementById('st-pp-mode').value}});if(r.success)toast('Saved!');else toast(r.error,'error');}
async function saveSMTP(){const r=await api('settings_save',{settings:{smtp_host:document.getElementById('smtp-host').value,smtp_port:document.getElementById('smtp-port').value,smtp_user:document.getElementById('smtp-user').value,smtp_from:document.getElementById('smtp-from').value,...(document.getElementById('smtp-pass').value?{smtp_pass:document.getElementById('smtp-pass').value}:{})}});if(r.success)toast('Saved!');else toast(r.error,'error');}
async function saveMaintenance(on){await api('settings_save',{settings:{maintenance_mode:on?'1':'0'}});document.getElementById('maint-label').textContent=on?'ON':'Off';}
document.getElementById('st-color').addEventListener('input',e=>{document.getElementById('st-color-hex').value=e.target.value;});

// ── LANGUAGES ──
async function loadLangs(){
  const r=await api('langs_list');if(!r.success)return;
  document.getElementById('langs-tbody').innerHTML=r.data.map(l=>`
    <tr><td style="font-size:18px">${esc(l.flag)}</td><td><strong>${esc(l.name)}</strong></td>
    <td><code style="font-size:11px;font-family:'JetBrains Mono',monospace">${esc(l.code)}</code></td>
    <td>${l.is_default=='1'?'<span class="badge b-green">Default</span>':''}</td>
    <td>${l.status=='1'?'<span class="badge b-green">Active</span>':'<span class="badge b-red">Inactive</span>'}</td>
    <td><div style="display:flex;gap:4px">
      <button class="btn btn-sm btn-secondary" onclick="setDefaultLang(${l.id})">${l.is_default=='1'?'Default':'Set Default'}</button>
      <button class="btn btn-sm ${l.status=='1'?'btn-secondary':'btn-green'}" onclick="toggleLang(${l.id},'${l.status}')">${l.status=='1'?'Disable':'Enable'}</button>
    </div></td></tr>`).join('');
}
async function setDefaultLang(id){const r=await api('lang_set_default',{id});if(r.success){toast('Default language updated');loadLangs();}else toast(r.error,'error');}
async function toggleLang(id,status){const r=await api('lang_toggle',{id,status:status=='1'?0:1});if(r.success){loadLangs();}else toast(r.error,'error');}

// ── SEO ──
async function loadSEO(){const r=await api('settings_get',{group:'seo'});if(!r.success)return;const d=r.data;document.getElementById('seo-title').value=d.meta_title||'';document.getElementById('seo-desc').value=d.meta_description||'';document.getElementById('seo-og').value=d.og_image||'';document.getElementById('seo-ga').value=d.google_analytics_id||'';}
async function saveSEO(){const r=await api('settings_save',{settings:{meta_title:document.getElementById('seo-title').value,meta_description:document.getElementById('seo-desc').value,og_image:document.getElementById('seo-og').value,google_analytics_id:document.getElementById('seo-ga').value}});if(r.success)toast('SEO saved!');else toast(r.error,'error');}

// ── ADMINS ──
async function loadAdmins(){const r=await api('admins_list');if(!r.success)return;document.getElementById('admins-tbody').innerHTML=r.data.map(a=>`
  <tr><td><div style="display:flex;align-items:center;gap:8px"><div style="width:26px;height:26px;border-radius:7px;background:linear-gradient(135deg,var(--blue),var(--purple));display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:700;color:#fff">${a.username[0].toUpperCase()}</div><div><div class="tbl-name">${esc(a.username)}</div><div class="tbl-sub">${esc(a.email)}</div></div></div></td>
  <td>${statusBadge(a.role)}</td><td style="font-size:11px;color:var(--muted)">${fmtDate(a.last_login)}</td>
  <td>${a.status=='1'?'<span class="badge b-green">Active</span>':'<span class="badge b-red">Inactive</span>'}</td>
  <td><div style="display:flex;gap:4px"><button class="btn btn-sm btn-secondary" onclick='editAdmin(${JSON.stringify(a)})'>✏️</button><button class="btn btn-sm btn-danger" onclick="delAdmin(${a.id},'${esc(a.username)}')">🗑</button></div></td></tr>`).join('');}
function openAdminModal(a=null){document.getElementById('admin-modal-title').textContent=a?'Edit Admin':'Add Admin';document.getElementById('adm-id').value=a?.id||'';document.getElementById('adm-user').value=a?.username||'';document.getElementById('adm-email').value=a?.email||'';document.getElementById('adm-role').value=a?.role||'admin';document.getElementById('adm-pass').value='';openModal('admin-modal');}
function editAdmin(a){openAdminModal(a);}
async function saveAdmin(){const r=await api('admin_save',{id:document.getElementById('adm-id').value,username:document.getElementById('adm-user').value,email:document.getElementById('adm-email').value,role:document.getElementById('adm-role').value,password:document.getElementById('adm-pass').value,status:1});if(r.success){toast(r.data.msg);closeModal('admin-modal');loadAdmins();}else toast(r.error,'error');}
async function delAdmin(id,name){if(!confirm(`Delete "${name}"?`))return;const r=await api('admin_delete',{id});if(r.success){toast('Deleted');loadAdmins();}else toast(r.error,'error');}
async function changeMyPw(){const o=document.getElementById('pw-old').value,n=document.getElementById('pw-new').value,c=document.getElementById('pw-conf').value;if(n!==c)return toast('Passwords do not match','error');const r=await api('change_pw',{old_password:o,new_password:n});if(r.success){toast('Password updated');['pw-old','pw-new','pw-conf'].forEach(id=>document.getElementById(id).value='');}else toast(r.error,'error');}

// ── ACTIVITY ──
async function loadActivity(){const r=await api('activity_log',{page:1});if(!r.success)return;document.getElementById('activity-tbody').innerHTML=(r.data.logs||[]).map(l=>`<tr><td style="font-size:10px;color:var(--muted);font-family:'JetBrains Mono',monospace">${new Date(l.created_at).toLocaleString()}</td><td><span class="badge b-blue">${esc(l.username||'system')}</span></td><td style="font-size:12px">${esc(l.action)}</td><td style="font-size:10px;color:var(--muted);font-family:'JetBrains Mono',monospace">${esc(l.ip||'—')}</td></tr>`).join('')||'<tr><td colspan="4" style="text-align:center;padding:20px;color:var(--muted)">No activity</td></tr>';}

// ── LOGOUT ──
async function doLogout(){await api('logout');window.location.href='login.php';}

// ── BOOT ──
init();
</script>
</body>
</html>
