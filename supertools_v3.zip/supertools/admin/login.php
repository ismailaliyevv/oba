<?php
require_once __DIR__ . '/includes/config.php';

if (Auth::check()) { header('Location: dashboard.php'); exit; }

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!Auth::login($_POST['username']??'', $_POST['password']??'')) {
        $error = 'Invalid credentials.';
    } else {
        header('Location: dashboard.php'); exit;
    }
}

$siteName   = ST_Settings::get('site_name', 'SuperTools');
$themeColor = ST_Settings::get('theme_color', '#6366f1');
$logoIcon   = ST_Settings::get('logo_icon', '⚡');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Admin Login — <?= esc($siteName) ?></title>
<style>
:root{--accent:<?= esc($themeColor) ?>;}
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:'Segoe UI',sans-serif;background:#0f172a;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:20px;}
body::before{content:'';position:absolute;inset:0;background:radial-gradient(ellipse 60% 50% at 50% 0%,color-mix(in srgb,var(--accent) 25%,transparent),transparent);pointer-events:none;}
.box{background:rgba(255,255,255,.05);backdrop-filter:blur(20px);border:1px solid rgba(255,255,255,.1);border-radius:20px;padding:40px 36px;width:100%;max-width:400px;position:relative;}
.box::before{content:'';position:absolute;top:0;left:0;right:0;height:2px;background:var(--accent);border-radius:20px 20px 0 0;}
.logo{text-align:center;margin-bottom:32px;}
.logo-icon{font-size:36px;display:block;margin-bottom:8px;}
.logo-name{font-size:22px;font-weight:800;color:#fff;}
.logo-sub{font-size:12px;color:rgba(255,255,255,.4);margin-top:4px;}
label{display:block;font-size:11px;font-weight:600;color:rgba(255,255,255,.5);text-transform:uppercase;letter-spacing:.5px;margin-bottom:7px;}
input{width:100%;padding:12px 14px;background:rgba(255,255,255,.07);border:1.5px solid rgba(255,255,255,.12);border-radius:9px;color:#fff;font-size:14px;outline:none;transition:.2s;font-family:inherit;margin-bottom:14px;}
input:focus{border-color:var(--accent);}
input::placeholder{color:rgba(255,255,255,.3);}
.btn{width:100%;padding:13px;background:var(--accent);color:#fff;border:none;border-radius:10px;font-size:14px;font-weight:700;cursor:pointer;transition:.2s;}
.btn:hover{opacity:.9;}
.error{background:rgba(239,68,68,.15);border:1px solid rgba(239,68,68,.3);color:#fca5a5;padding:10px 14px;border-radius:8px;font-size:13px;margin-bottom:16px;}
a{color:rgba(255,255,255,.4);font-size:13px;text-decoration:none;display:block;text-align:center;margin-top:16px;}
a:hover{color:rgba(255,255,255,.7);}
</style>
</head>
<body>
<div class="box">
  <div class="logo">
    <span class="logo-icon"><?= esc($logoIcon) ?></span>
    <div class="logo-name"><?= esc($siteName) ?></div>
    <div class="logo-sub">Admin Panel</div>
  </div>
  <?php if($error): ?><div class="error">⚠️ <?= esc($error) ?></div><?php endif; ?>
  <form method="POST">
    <label>Username or Email</label>
    <input name="username" placeholder="admin" value="<?= esc($_POST['username']??'') ?>" required autofocus>
    <label>Password</label>
    <input name="password" type="password" placeholder="••••••••" required>
    <button class="btn">Sign In →</button>
  </form>
  <a href="../index.php">← Back to site</a>
</div>
</body>
</html>
