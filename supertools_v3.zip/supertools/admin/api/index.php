<?php
require_once __DIR__ . '/../includes/config.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Credentials: true');

$action = $_GET['action'] ?? '';
$data   = array_merge($_GET, $_POST);
$body   = file_get_contents('php://input');
if ($body) { $json = json_decode($body, true); if ($json) $data = array_merge($data, $json); }

// Public actions
$public = ['login','logout','user_me_public'];
if (!in_array($action, $public) && !Auth::check()) {
    api_error('Unauthorized', 401);
}

try {
    switch ($action) {
        // ── AUTH ──
        case 'me':
            $u = Auth::user(); if(!$u) api_error('Not found',404);
            api_json($u);
        case 'logout':
            Auth::logout(); api_json(['ok'=>true]);
        case 'change_pw':
            $u = Auth::user();
            if (!password_verify($data['old_password']??'', $u['password'])) api_error('Wrong current password');
            $np = $data['new_password']??'';
            if (strlen($np)<6) api_error('Min 6 chars');
            DB::query("UPDATE admin_users SET password=? WHERE id=?", [password_hash($np,PASSWORD_BCRYPT,['cost'=>12]), $u['id']]);
            api_json(['msg'=>'Password updated']);

        // ── DASHBOARD ──
        case 'dashboard':
            $toolsActive = DB::fetch("SELECT COUNT(*) c FROM tools WHERE status='active'")['c']??0;
            $toolsTotal  = DB::fetch("SELECT COUNT(*) c FROM tools")['c']??0;
            $usersTotal  = DB::fetch("SELECT COUNT(*) c FROM users")['c']??0;
            $usersWeek   = DB::fetch("SELECT COUNT(*) c FROM users WHERE created_at>=DATE_SUB(NOW(),INTERVAL 7 DAY)")['c']??0;
            $revTotal    = DB::fetch("SELECT COALESCE(SUM(amount),0) s FROM transactions WHERE status='completed'")['s']??0;
            $revWeek     = DB::fetch("SELECT COALESCE(SUM(amount),0) s FROM transactions WHERE status='completed' AND created_at>=DATE_SUB(NOW(),INTERVAL 7 DAY)")['s']??0;
            $viewsWeek   = DB::fetch("SELECT COALESCE(SUM(views_week),0) s FROM tools")['s']??0;
            $topTools    = DB::fetchAll("SELECT name,views_week FROM tools WHERE status='active' ORDER BY views_week DESC LIMIT 5");
            $newUsers    = DB::fetchAll("SELECT u.email,u.created_at,p.name plan_name FROM users u LEFT JOIN plans p ON p.id=u.plan_id ORDER BY u.created_at DESC LIMIT 5");
            api_json(compact('toolsActive','toolsTotal','usersTotal','usersWeek','revTotal','revWeek','viewsWeek','topTools','newUsers'));

        // ── SYNC ──
        case 'sync_tools':
            require_once __DIR__ . '/../includes/sync-hook.php';
            $r = sync_tools();
            api_json($r);

        // ── TOOLS ──
        case 'tools_list':
            $q      = '%'.($data['q']??'').'%';
            $cat    = $data['cat']??'';
            $status = $data['status']??'';
            $page   = max(1,(int)($data['page']??1));
            $limit  = 20; $offset = ($page-1)*$limit;
            $where  = '1=1'; $params = [];
            if ($data['q']??'') { $where.=' AND (t.name LIKE ? OR t.path LIKE ?)'; $params[]=$q;$params[]=$q; }
            if ($cat)    { $where.=' AND t.category_id=?'; $params[]=(int)$cat; }
            if ($status) { $where.=' AND t.status=?'; $params[]=$status; }
            $total = DB::fetch("SELECT COUNT(*) c FROM tools t WHERE $where", $params)['c']??0;
            $tools = DB::fetchAll("SELECT t.*,c.name cat_name,c.icon cat_icon FROM tools t LEFT JOIN categories c ON c.id=t.category_id WHERE $where ORDER BY t.sort_order,t.name LIMIT $limit OFFSET $offset", $params);
            $categories = DB::fetchAll("SELECT id,name,icon FROM categories WHERE status=1 ORDER BY sort_order");
            api_json(compact('tools','total','categories','page','pages'));

        case 'tool_get':
            $t = DB::fetch("SELECT * FROM tools WHERE id=?", [(int)($data['id']??0)]);
            if (!$t) api_error('Not found',404);
            api_json($t);

        case 'tool_save':
            $id   = (int)($data['id']??0);
            $name = sanitize($data['name']??'');
            if (!$name) api_error('Name required');
            $row = [
                'name'        => $name,
                'slug'        => $data['slug'] ?? slugify($name),
                'icon'        => sanitize($data['icon']??'🔧'),
                'category_id' => ($data['category_id']&&$data['category_id']!='') ? (int)$data['category_id'] : null,
                'description' => sanitize($data['description']??''),
                'path'        => sanitize($data['path']??''),
                'status'      => in_array($data['status']??'',['active','inactive','coming_soon'])?$data['status']:'active',
                'is_featured' => (int)($data['is_featured']??0),
                'is_premium'  => (int)($data['is_premium']??0),
                'sort_order'  => (int)($data['sort_order']??0),
            ];
            // Slug unique check
            $slugExists = DB::fetch("SELECT id FROM tools WHERE slug=? AND id!=?", [$row['slug'], $id]);
            if ($slugExists) $row['slug'] = $row['slug'].'-'.substr(md5(time()),0,4);
            if ($id) {
                DB::update('tools', $row, 'id=:id', ['id'=>$id]);
                Auth::log('tool_update','tool',$id);
                api_json(['msg'=>'Tool updated']);
            } else {
                $newId = DB::insert('tools', $row);
                Auth::log('tool_create','tool',$newId);
                api_json(['msg'=>'Tool created','id'=>$newId]);
            }

        case 'tool_delete':
            $id = (int)($data['id']??0);
            DB::delete('tools','id=?',[$id]);
            Auth::log('tool_delete','tool',$id);
            api_json(['msg'=>'Deleted']);

        case 'tool_toggle':
            $id = (int)($data['id']??0);
            $t  = DB::fetch("SELECT status FROM tools WHERE id=?",[$id]);
            if (!$t) api_error('Not found');
            $ns = $t['status']==='active'?'inactive':'active';
            DB::query("UPDATE tools SET status=? WHERE id=?",[$ns,$id]);
            api_json(['status'=>$ns]);

        // ── CATEGORIES ──
        case 'cats_list':
            $cats = DB::fetchAll("SELECT c.*,(SELECT COUNT(*) FROM tools t WHERE t.category_id=c.id AND t.status='active') tool_count FROM categories c ORDER BY c.sort_order");
            api_json($cats);

        case 'cat_save':
            $id  = (int)($data['id']??0);
            $name= sanitize($data['name']??'');
            if (!$name) api_error('Name required');
            $row = [
                'name'       => $name,
                'slug'       => $data['slug']??slugify($name),
                'icon'       => sanitize($data['icon']??'📁'),
                'color'      => sanitize($data['color']??'#6366f1'),
                'description'=> sanitize($data['description']??''),
                'sort_order' => (int)($data['sort_order']??0),
                'status'     => 1,
            ];
            if ($id) { DB::update('categories',$row,'id=:id',['id'=>$id]); api_json(['msg'=>'Updated']); }
            else { $nid=DB::insert('categories',$row); api_json(['msg'=>'Created','id'=>$nid]); }

        case 'cat_delete':
            $id=(int)($data['id']??0);
            DB::query("UPDATE tools SET category_id=NULL WHERE category_id=?",[$id]);
            DB::delete('categories','id=?',[$id]);
            api_json(['msg'=>'Deleted']);

        // ── ANALYTICS ──
        case 'analytics':
            $days = max(1,min(365,(int)($data['days']??30)));
            $total   = DB::fetch("SELECT COUNT(*) c FROM page_views WHERE created_at>=DATE_SUB(NOW(),INTERVAL ? DAY)",[$days])['c']??0;
            $countries= DB::fetchAll("SELECT country,COUNT(*) hits FROM page_views WHERE created_at>=DATE_SUB(NOW(),INTERVAL ? DAY) GROUP BY country ORDER BY hits DESC LIMIT 10",[$days]);
            $topPages = DB::fetchAll("SELECT page,COUNT(*) hits FROM page_views WHERE created_at>=DATE_SUB(NOW(),INTERVAL ? DAY) GROUP BY page ORDER BY hits DESC LIMIT 10",[$days]);
            $traffic  = DB::fetchAll("SELECT DATE(created_at) d,COUNT(*) hits FROM page_views WHERE created_at>=DATE_SUB(NOW(),INTERVAL ? DAY) GROUP BY DATE(created_at) ORDER BY d",[$days]);
            api_json(compact('total','countries','topPages','traffic'));

        // ── USERS ──
        case 'users_list':
            $q      = '%'.($data['q']??'').'%';
            $status = $data['status']??'';
            $plan   = $data['plan']??'';
            $page   = max(1,(int)($data['page']??1));
            $limit  = 20; $offset=($page-1)*$limit;
            $where  = '1=1'; $params=[];
            if ($data['q']??'') { $where.=' AND (u.name LIKE ? OR u.email LIKE ?)'; $params[]=$q;$params[]=$q; }
            if ($status) { $where.=' AND u.status=?'; $params[]=$status; }
            if ($plan)   { $where.=' AND u.plan_id=?'; $params[]=(int)$plan; }
            $total = DB::fetch("SELECT COUNT(*) c FROM users u WHERE $where",$params)['c']??0;
            $users = DB::fetchAll("SELECT u.*,p.name plan_name FROM users u LEFT JOIN plans p ON p.id=u.plan_id WHERE $where ORDER BY u.created_at DESC LIMIT $limit OFFSET $offset",$params);
            $pages = ceil($total/$limit);
            api_json(compact('users','total','page','pages'));

        case 'user_get':
            $u=DB::fetch("SELECT u.*,p.name plan_name FROM users u LEFT JOIN plans p ON p.id=u.plan_id WHERE u.id=?",[(int)($data['id']??0)]);
            if(!$u) api_error('Not found',404);
            api_json($u);

        case 'user_save':
            $id=$data['id']??(int)0; $id=(int)$id;
            $email=trim($data['email']??'');
            if(!$email) api_error('Email required');
            $row=['name'=>sanitize($data['name']??''),'email'=>$email,'plan_id'=>(int)($data['plan_id']??1),'status'=>$data['status']??'active'];
            if($id){
                DB::update('users',$row,'id=:id',['id'=>$id]);
                api_json(['msg'=>'User updated']);
            } else {
                $pass=$data['password']??'';
                if(strlen($pass)<6) api_error('Password min 6 chars');
                $row['password']=password_hash($pass,PASSWORD_BCRYPT,['cost'=>12]);
                $row['created_at']=date('Y-m-d H:i:s');
                $nid=DB::insert('users',$row);
                api_json(['msg'=>'User created','id'=>$nid]);
            }

        case 'user_ban':
            $id=(int)($data['id']??0); $status=$data['status']??'banned';
            DB::query("UPDATE users SET status=? WHERE id=?",[$status,$id]);
            api_json(['msg'=>$status==='banned'?'User banned':'User unbanned']);

        case 'user_delete':
            $id=(int)($data['id']??0);
            DB::delete('users','id=?',[$id]);
            api_json(['msg'=>'Deleted']);

        // ── PLANS ──
        case 'plans_list':
            $plans=DB::fetchAll("SELECT p.*,(SELECT COUNT(*) FROM users u WHERE u.plan_id=p.id) user_count FROM plans p WHERE p.status=1 ORDER BY p.sort_order");
            api_json($plans);

        case 'plan_save':
            $id=(int)($data['id']??0);
            $name=sanitize($data['name']??'');
            if(!$name) api_error('Name required');
            $feats=$data['features']??'';
            if(is_string($feats)) $feats=array_filter(array_map('trim',explode("\n",$feats)));
            $row=[
                'name'=>$name,'slug'=>slugify($name),
                'price'=>floatval($data['price']??0),
                'billing_cycle'=>in_array($data['billing_cycle']??'',['monthly','yearly','lifetime'])?$data['billing_cycle']:'monthly',
                'features'=>json_encode(array_values($feats)),
                'tool_limit'=>(int)($data['tool_limit']??-1),
                'is_popular'=>(int)($data['is_popular']??0),
                'status'=>1,
                'sort_order'=>(int)($data['sort_order']??0),
            ];
            if($id){DB::update('plans',$row,'id=:id',['id'=>$id]);api_json(['msg'=>'Updated']);}
            else{$nid=DB::insert('plans',$row);api_json(['msg'=>'Created','id'=>$nid]);}

        case 'plan_delete':
            $id=(int)($data['id']??0);
            DB::delete('plans','id=?',[$id]);
            api_json(['msg'=>'Deleted']);

        // ── TRANSACTIONS ──
        case 'tx_list':
            $page=max(1,(int)($data['page']??1));$limit=20;$offset=($page-1)*$limit;
            $txs=DB::fetchAll("SELECT t.*,u.email user_email,p.name plan_name FROM transactions t LEFT JOIN users u ON u.id=t.user_id LEFT JOIN plans p ON p.id=t.plan_id ORDER BY t.created_at DESC LIMIT $limit OFFSET $offset");
            $total=DB::fetch("SELECT COUNT(*) c FROM transactions")['c']??0;
            $pages=ceil($total/$limit);
            api_json(compact('txs','total','page','pages'));

        // ── POSTS ──
        case 'posts_list':
            $page=max(1,(int)($data['page']??1));$limit=20;$offset=($page-1)*$limit;
            $posts=DB::fetchAll("SELECT * FROM posts ORDER BY created_at DESC LIMIT $limit OFFSET $offset");
            $total=DB::fetch("SELECT COUNT(*) c FROM posts")['c']??0;
            api_json(['posts'=>$posts,'total'=>$total,'page'=>$page,'pages'=>ceil($total/$limit)]);

        case 'post_get':
            $p=DB::fetch("SELECT * FROM posts WHERE id=?",[(int)($data['id']??0)]);
            if(!$p) api_error('Not found',404);
            api_json($p);

        case 'post_save':
            $id=(int)($data['id']??0);
            $title=sanitize($data['title']??'');
            if(!$title) api_error('Title required');
            $slug=$data['slug']??slugify($title);
            $slugExists=DB::fetch("SELECT id FROM posts WHERE slug=? AND id!=?",[$slug,$id]);
            if($slugExists) $slug=$slug.'-'.substr(md5(time()),0,4);
            $row=['title'=>$title,'slug'=>$slug,'content'=>$data['content']??'','excerpt'=>sanitize($data['excerpt']??''),'featured_image'=>$data['featured_image']??'','status'=>in_array($data['status']??'',['published','draft'])?$data['status']:'draft','meta_title'=>sanitize($data['meta_title']??''),'meta_desc'=>sanitize($data['meta_desc']??'')];
            if($id){$row['updated_at']=date('Y-m-d H:i:s');DB::update('posts',$row,'id=:id',['id'=>$id]);api_json(['msg'=>'Updated']);}
            else{$row['created_at']=date('Y-m-d H:i:s');$nid=DB::insert('posts',$row);api_json(['msg'=>'Created','id'=>$nid]);}

        case 'post_delete':
            DB::delete('posts','id=?',[(int)($data['id']??0)]);
            api_json(['msg'=>'Deleted']);

        // ── PAGES ──
        case 'pages_list':
            api_json(DB::fetchAll("SELECT * FROM pages ORDER BY created_at DESC"));

        case 'page_get':
            $p=DB::fetch("SELECT * FROM pages WHERE id=?",[(int)($data['id']??0)]);
            if(!$p) api_error('Not found',404);
            api_json($p);

        case 'page_save':
            $id=(int)($data['id']??0);
            $title=sanitize($data['title']??'');
            if(!$title) api_error('Title required');
            $slug=$data['slug']??slugify($title);
            $slugExists=DB::fetch("SELECT id FROM pages WHERE slug=? AND id!=?",[$slug,$id]);
            if($slugExists) $slug=$slug.'-'.substr(md5(time()),0,4);
            $row=['title'=>$title,'slug'=>$slug,'content'=>$data['content']??'','status'=>in_array($data['status']??'',['published','draft'])?$data['status']:'draft','meta_desc'=>sanitize($data['meta_desc']??''),'featured_image'=>$data['featured_image']??''];
            if($id){$row['updated_at']=date('Y-m-d H:i:s');DB::update('pages',$row,'id=:id',['id'=>$id]);api_json(['msg'=>'Updated']);}
            else{$row['created_at']=date('Y-m-d H:i:s');$nid=DB::insert('pages',$row);api_json(['msg'=>'Created','id'=>$nid]);}

        case 'page_delete':
            DB::delete('pages','id=?',[(int)($data['id']??0)]);
            api_json(['msg'=>'Deleted']);

        // ── ADS ──
        case 'ads_list':
            api_json(DB::fetchAll("SELECT * FROM advertisements ORDER BY slot,id"));

        case 'ad_save':
            $id=(int)($data['id']??0);
            $row=['name'=>sanitize($data['name']??''),'slot'=>sanitize($data['slot']??'header'),'type'=>sanitize($data['type']??'custom_html'),'code'=>$data['code']??'','status'=>(int)($data['status']??1)];
            if($id){DB::update('advertisements',$row,'id=:id',['id'=>$id]);api_json(['msg'=>'Updated']);}
            else{$nid=DB::insert('advertisements',$row);api_json(['msg'=>'Created','id'=>$nid]);}

        case 'ad_delete':
            DB::delete('advertisements','id=?',[(int)($data['id']??0)]);
            api_json(['msg'=>'Deleted']);

        // ── SETTINGS ──
        case 'settings_get':
            $group=$data['group']??'general';
            $rows=DB::fetchAll("SELECT setting_key,setting_value FROM settings WHERE setting_group=?",[$group]);
            api_json(array_column($rows,'setting_value','setting_key'));

        case 'settings_save':
            $settings=$data['settings']??[];
            if(!is_array($settings)) api_error('Invalid data');
            foreach($settings as $k=>$v){
                $k=preg_replace('/[^a-z0-9_]/','',$k);
                if($k) ST_Settings::set($k,(string)$v);
            }
            api_json(['msg'=>'Saved']);

        // ── LANGUAGES ──
        case 'langs_list':
            api_json(DB::fetchAll("SELECT * FROM languages ORDER BY sort_order"));

        case 'lang_set_default':
            $id=(int)($data['id']??0);
            DB::query("UPDATE languages SET is_default=0");
            DB::query("UPDATE languages SET is_default=1 WHERE id=?",[$id]);
            api_json(['msg'=>'Default language set']);

        case 'lang_toggle':
            $id=(int)($data['id']??0);$s=(int)($data['status']??0);
            DB::query("UPDATE languages SET status=? WHERE id=?",[$s,$id]);
            api_json(['msg'=>'Updated']);

        // ── ADMINS ──
        case 'admins_list':
            api_json(DB::fetchAll("SELECT id,username,email,role,status,last_login,login_ip FROM admin_users ORDER BY id"));

        case 'admin_save':
            $id=(int)($data['id']??0);
            $user=sanitize($data['username']??'');$email=sanitize($data['email']??'');
            if(!$user||!$email) api_error('Username and email required');
            $row=['username'=>$user,'email'=>$email,'role'=>in_array($data['role']??'',['superadmin','admin','editor'])?$data['role']:'admin','status'=>(int)($data['status']??1)];
            if(!empty($data['password'])){
                if(strlen($data['password'])<6) api_error('Password min 6 chars');
                $row['password']=password_hash($data['password'],PASSWORD_BCRYPT,['cost'=>12]);
            }
            if($id){DB::update('admin_users',$row,'id=:id',['id'=>$id]);api_json(['msg'=>'Updated']);}
            else{if(empty($row['password'])) api_error('Password required');$nid=DB::insert('admin_users',$row);api_json(['msg'=>'Created','id'=>$nid]);}

        case 'admin_delete':
            $id=(int)($data['id']??0);
            $me=Auth::user();
            if($me&&$me['id']==$id) api_error('Cannot delete yourself');
            DB::delete('admin_users','id=?',[$id]);
            api_json(['msg'=>'Deleted']);

        // ── ACTIVITY ──
        case 'activity_log':
            $page=max(1,(int)($data['page']??1));$limit=30;$offset=($page-1)*$limit;
            $logs=DB::fetchAll("SELECT l.*,a.username FROM activity_log l LEFT JOIN admin_users a ON a.id=l.admin_id ORDER BY l.created_at DESC LIMIT $limit OFFSET $offset");
            $total=DB::fetch("SELECT COUNT(*) c FROM activity_log")['c']??0;
            api_json(['logs'=>$logs,'total'=>$total,'page'=>$page,'pages'=>ceil($total/$limit)]);

        // ── USER ME PUBLIC (for frontend navbar) ──
        case 'user_me_public':
            if(session_status()===PHP_SESSION_NONE) session_start();
            $result=['logged_in'=>false,'is_admin'=>false];
            $adminId=$_SESSION['admin_id']??null;
            if($adminId){$result['is_admin']=true;$result['logged_in']=true;$result['admin']=['id'=>$adminId,'name'=>$_SESSION['admin_name']??''];}
            $userId=$_SESSION['user_id']??null;
            if($userId){$u=DB::fetch("SELECT u.id,u.name,u.email,u.status,p.name plan_name FROM users u LEFT JOIN plans p ON p.id=u.plan_id WHERE u.id=?",[$userId]);if($u&&$u['status']==='active'){$result['logged_in']=true;$result['user']=$u;}}
            api_json($result);

        default:
            api_error('Unknown action: '.$action, 400);
    }
} catch (Exception $e) {
    api_error('Server error: '.$e->getMessage(), 500);
}
