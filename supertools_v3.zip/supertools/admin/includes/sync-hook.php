<?php
/**
 * SuperTools — Auto Sync Hook
 * Tools qovluğunu skan edir, DB-yə olmayan faylları avtomatik əlavə edir
 * Bu fayl admin/dashboard.php yüklənəndə çalışır
 */

require_once __DIR__ . '/config.php';

function sync_tools(): array {
    $toolsDir = dirname(dirname(__DIR__)) . '/tools/';
    if (!is_dir($toolsDir)) return ['added' => 0, 'skipped' => 0];

    $added   = 0;
    $skipped = 0;
    $updated = 0;

    // Bütün HTML fayllarını rekursiv tap
    $iterator = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($toolsDir, RecursiveDirectoryIterator::SKIP_DOTS)
    );

    foreach ($iterator as $file) {
        if (!$file->isFile()) continue;
        $ext = strtolower($file->getExtension());
        if (!in_array($ext, ['html', 'htm', 'php'])) continue;

        // Relative path from tools/
        $realPath = $file->getRealPath();
        $relativePath = 'tools/' . str_replace('\\', '/', substr($realPath, strlen($toolsDir)));

        // DB-də varsa keç
        $existing = DB::fetch("SELECT id FROM tools WHERE path=?", [$relativePath]);
        if ($existing) { $skipped++; continue; }

        // Fayl adından tool məlumatlarını çıxar
        $filename = $file->getFilename();
        $nameWithoutExt = pathinfo($filename, PATHINFO_FILENAME);

        // slug: fayl adından
        $slug = slugify($nameWithoutExt);

        // slug artıq varsa unique et
        $slugCheck = DB::fetch("SELECT id FROM tools WHERE slug=?", [$slug]);
        if ($slugCheck) {
            $slug = $slug . '-' . substr(md5($relativePath), 0, 4);
        }

        // Adı gözəlləşdir: word-to-pdf → Word To Pdf
        $name = ucwords(str_replace(['-', '_'], ' ', $nameWithoutExt));

        // Faylın içindən <title> tag-ı oxu
        $content = @file_get_contents($realPath);
        if ($content) {
            if (preg_match('/<title[^>]*>(.*?)<\/title>/is', $content, $m)) {
                $titleFromFile = trim(strip_tags($m[1]));
                if ($titleFromFile && strlen($titleFromFile) < 200) $name = $titleFromFile;
            }
            // <meta name="description" content="...">
            $desc = '';
            if (preg_match('/<meta\s+name=["\']description["\']\s+content=["\']([^"\']+)["\']/i', $content, $m2)) {
                $desc = trim($m2[1]);
            }
        }

        // Qovluğa görə kateqoriya təyin et
        $subDir = dirname($relativePath);
        $subDir = str_replace('tools/', '', $subDir);
        $subDir = str_replace('tools', '', $subDir);
        $subDir = trim($subDir, '/');

        $catId = null;
        if ($subDir && $subDir !== '.') {
            // Qovluq adına görə kateqoriya axtar
            $catSlug = slugify($subDir);
            $cat = DB::fetch("SELECT id FROM categories WHERE slug=? OR slug LIKE ?", [$catSlug, '%'.$catSlug.'%']);
            if ($cat) {
                $catId = $cat['id'];
            } else {
                // Yeni kateqoriya yarat
                $catName = ucwords(str_replace(['-','_'], ' ', $subDir));
                $catId = DB::insert('categories', [
                    'name'       => $catName,
                    'slug'       => $catSlug,
                    'icon'       => '🔧',
                    'color'      => '#6366f1',
                    'status'     => 1,
                    'sort_order' => 99,
                ]);
            }
        }

        // DB-yə əlavə et
        DB::insert('tools', [
            'name'        => $name,
            'slug'        => $slug,
            'icon'        => '🔧',
            'category_id' => $catId,
            'description' => $desc ?: $name . ' — free online tool.',
            'path'        => $relativePath,
            'status'      => 'active',
            'is_featured'  => 0,
            'is_premium'   => 0,
            'views'        => 0,
            'views_week'   => 0,
            'sort_order'   => 0,
        ]);

        $added++;
    }

    // DB-də var amma fayl silinibsə — inactive et
    $dbTools = DB::fetchAll("SELECT id, path FROM tools WHERE path LIKE 'tools/%'");
    foreach ($dbTools as $dt) {
        $fullPath = dirname(dirname(__DIR__)) . '/' . $dt['path'];
        if (!file_exists($fullPath)) {
            DB::query("UPDATE tools SET status='inactive' WHERE id=?", [$dt['id']]);
        }
    }

    return ['added' => $added, 'skipped' => $skipped, 'updated' => $updated];
}
