<?php
// ============================================================
// SuperTools — Configuration
// ============================================================
define('ST_VERSION', '1.0.0');
define('ST_NAME',    'SuperTools');

// ── Database ────────────────────────────────────────────────
define('DB_HOST',    'localhost');
define('DB_PORT',    '3306');
define('DB_NAME',    'supertools');   // ← Change
define('DB_USER',    'root');          // ← Change
define('DB_PASS',    '');              // ← Change
define('DB_CHARSET', 'utf8mb4');

// ── Security ────────────────────────────────────────────────
define('SECRET_KEY',     bin2hex(random_bytes(32)));
define('SESSION_EXPIRE', 3600 * 8);
define('BCRYPT_COST',    12);

// ── Paths ────────────────────────────────────────────────────
define('BASE_URL',    'http://localhost/supertools');        // ← Change
define('ADMIN_URL',   BASE_URL . '/admin');
define('UPLOAD_PATH', dirname(dirname(__DIR__)) . '/uploads/');
define('UPLOAD_URL',  BASE_URL . '/uploads/');

date_default_timezone_set('UTC');
error_reporting(0);

// ════════════════════════════════════════════════════════════
// DB Class
// ════════════════════════════════════════════════════════════
class DB {
    private static ?PDO $pdo = null;

    public static function get(): PDO {
        if (self::$pdo === null) {
            $dsn = sprintf('mysql:host=%s;port=%s;dbname=%s;charset=%s',
                DB_HOST, DB_PORT, DB_NAME, DB_CHARSET);
            self::$pdo = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ]);
        }
        return self::$pdo;
    }

    public static function query(string $sql, array $p = []): PDOStatement {
        $s = self::get()->prepare($sql);
        $s->execute($p);
        return $s;
    }

    public static function fetch(string $sql, array $p = []): ?array {
        return self::query($sql, $p)->fetch() ?: null;
    }

    public static function fetchAll(string $sql, array $p = []): array {
        return self::query($sql, $p)->fetchAll();
    }

    public static function insert(string $table, array $data): int {
        $cols = implode(',', array_map(fn($k) => "`$k`", array_keys($data)));
        $vals = implode(',', array_map(fn($k) => ":$k", array_keys($data)));
        self::query("INSERT INTO `$table` ($cols) VALUES ($vals)", $data);
        return (int) self::get()->lastInsertId();
    }

    public static function update(string $table, array $data, string $where, array $wp = []): int {
        $set = implode(',', array_map(fn($k) => "`$k`=:$k", array_keys($data)));
        return self::query("UPDATE `$table` SET $set WHERE $where",
            array_merge($data, $wp))->rowCount();
    }

    public static function delete(string $table, string $where, array $p = []): int {
        return self::query("DELETE FROM `$table` WHERE $where", $p)->rowCount();
    }
}

// ════════════════════════════════════════════════════════════
// Settings Class
// ════════════════════════════════════════════════════════════
class ST_Settings {
    private static array $cache = [];

    public static function get(string $key, mixed $default = ''): mixed {
        if (!isset(self::$cache[$key])) {
            try {
                $row = DB::fetch("SELECT setting_value FROM settings WHERE setting_key=?", [$key]);
                self::$cache[$key] = $row ? $row['setting_value'] : $default;
            } catch (Exception $e) {
                return $default;
            }
        }
        return self::$cache[$key];
    }

    public static function set(string $key, mixed $value): void {
        DB::query("INSERT INTO settings(setting_key,setting_value) VALUES(?,?) ON DUPLICATE KEY UPDATE setting_value=?",
            [$key, $value, $value]);
        self::$cache[$key] = $value;
    }

    public static function setMany(array $data): void {
        foreach ($data as $k => $v) self::set($k, $v);
    }

    public static function getGroup(string $group): array {
        $rows = DB::fetchAll("SELECT setting_key,setting_value FROM settings WHERE setting_group=?", [$group]);
        return array_column($rows, 'setting_value', 'setting_key');
    }
}

// ════════════════════════════════════════════════════════════
// Auth (Admin)
// ════════════════════════════════════════════════════════════
class Auth {
    public static function start(): void {
        if (session_status() === PHP_SESSION_NONE) {
            ini_set('session.cookie_httponly', 1);
            ini_set('session.use_strict_mode', 1);
            session_start();
        }
    }

    public static function check(): bool {
        self::start();
        if (!isset($_SESSION['admin_id'])) return false;
        if (time() - ($_SESSION['last_active'] ?? 0) > SESSION_EXPIRE) {
            self::logout(); return false;
        }
        $_SESSION['last_active'] = time();
        return true;
    }

    public static function require(): void {
        if (!self::check()) {
            header('Location: ' . ADMIN_URL . '/login.php'); exit;
        }
    }

    public static function login(string $username, string $pass): bool {
        $user = DB::fetch("SELECT * FROM admin_users WHERE (username=? OR email=?) AND status=1",
            [$username, $username]);
        if (!$user || !password_verify($pass, $user['password'])) return false;
        self::start();
        session_regenerate_id(true);
        $_SESSION['admin_id']    = $user['id'];
        $_SESSION['admin_name']  = $user['username'];
        $_SESSION['admin_role']  = $user['role'];
        $_SESSION['last_active'] = time();
        DB::query("UPDATE admin_users SET last_login=NOW(), login_ip=? WHERE id=?",
            [$_SERVER['REMOTE_ADDR'] ?? '', $user['id']]);
        return true;
    }

    public static function logout(): void {
        self::start();
        session_destroy();
    }

    public static function user(): ?array {
        if (!isset($_SESSION['admin_id'])) return null;
        return DB::fetch("SELECT * FROM admin_users WHERE id=?", [$_SESSION['admin_id']]);
    }

    public static function log(string $action, string $type = '', int $id = 0, string $note = ''): void {
        DB::query("INSERT INTO activity_log(admin_id,action,entity_type,entity_id,new_value,ip) VALUES(?,?,?,?,?,?)",
            [$_SESSION['admin_id'] ?? 0, $action, $type, $id, $note, $_SERVER['REMOTE_ADDR'] ?? '']);
    }
}

// ════════════════════════════════════════════════════════════
// User Auth (Frontend)
// ════════════════════════════════════════════════════════════
class UserAuth {
    public static function start(): void {
        if (session_status() === PHP_SESSION_NONE) session_start();
    }

    public static function check(): bool {
        self::start();
        return !empty($_SESSION['user_id']);
    }

    public static function user(): ?array {
        if (!self::check()) return null;
        return DB::fetch(
            "SELECT u.*, p.name plan_name, p.price plan_price, p.tool_limit
             FROM users u LEFT JOIN plans p ON p.id=u.plan_id WHERE u.id=?",
            [$_SESSION['user_id']]
        );
    }

    public static function login(array $user): void {
        self::start();
        session_regenerate_id(true);
        $_SESSION['user_id']    = $user['id'];
        $_SESSION['user_email'] = $user['email'];
        $_SESSION['user_name']  = $user['name'] ?? $user['email'];
        DB::query("UPDATE users SET last_active=NOW() WHERE id=?", [$user['id']]);
    }

    public static function logout(): void {
        self::start();
        session_destroy();
    }
}

// ════════════════════════════════════════════════════════════
// Language / i18n
// ════════════════════════════════════════════════════════════
class Lang {
    private static array $strings = [];
    private static string $current = 'en';

    public static function detect(): string {
        // 1. URL param  2. Cookie  3. User pref  4. Browser  5. Default
        if (!empty($_GET['lang'])) {
            $l = preg_replace('/[^a-z]/', '', strtolower($_GET['lang']));
            if (self::isValid($l)) { setcookie('lang', $l, time()+3600*24*30, '/'); self::$current=$l; return $l; }
        }
        if (!empty($_COOKIE['lang'])) { $l=$_COOKIE['lang']; if(self::isValid($l)){self::$current=$l;return $l;} }
        if (UserAuth::check()) {
            $u = DB::fetch("SELECT lang FROM users WHERE id=?", [$_SESSION['user_id']]);
            if ($u && self::isValid($u['lang'])) { self::$current=$u['lang']; return $u['lang']; }
        }
        $def = DB::fetch("SELECT code FROM languages WHERE is_default=1 LIMIT 1");
        $l = $def['code'] ?? 'en';
        self::$current = $l;
        return $l;
    }

    public static function isValid(string $code): bool {
        static $valid = null;
        if ($valid === null) {
            try { $rows=DB::fetchAll("SELECT code FROM languages WHERE status=1"); $valid=array_column($rows,'code'); }
            catch(Exception $e){ $valid=['en']; }
        }
        return in_array($code, $valid);
    }

    public static function load(string $code): void {
        self::$current = $code;
        try {
            $rows = DB::fetchAll("SELECT trans_key,trans_value FROM translations WHERE lang_code=?", [$code]);
            self::$strings = array_column($rows, 'trans_value', 'trans_key');
        } catch (Exception $e) {
            self::$strings = [];
        }
    }

    public static function t(string $key, array $replace = []): string {
        $str = self::$strings[$key] ?? $key;
        foreach ($replace as $k => $v) $str = str_replace('{{'.$k.'}}', $v, $str);
        return $str;
    }

    public static function current(): string { return self::$current; }

    public static function getAll(): array {
        try { return DB::fetchAll("SELECT * FROM languages WHERE status=1 ORDER BY sort_order"); }
        catch(Exception $e){ return []; }
    }
}

// ════════════════════════════════════════════════════════════
// Helpers
// ════════════════════════════════════════════════════════════
function api_json(mixed $data, int $code = 200): void {
    http_response_code($code);
    header('Content-Type: application/json');
    echo json_encode(['success' => $code < 400, 'data' => $data]);
    exit;
}

function api_error(string $msg, int $code = 400): void {
    http_response_code($code);
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'error' => $msg]);
    exit;
}

function slugify(string $str): string {
    $str = strtolower(trim($str));
    $str = preg_replace('/[^a-z0-9\-]/', '-', $str);
    return preg_replace('/-+/', '-', trim($str, '-'));
}

function sanitize(string $str): string {
    return htmlspecialchars(strip_tags(trim($str)), ENT_QUOTES, 'UTF-8');
}

function get_client_ip(): string {
    foreach (['HTTP_CF_CONNECTING_IP','HTTP_X_FORWARDED_FOR','REMOTE_ADDR'] as $k) {
        if (!empty($_SERVER[$k])) return explode(',', $_SERVER[$k])[0];
    }
    return '0.0.0.0';
}

function get_country(): string {
    $ip = get_client_ip();
    if (function_exists('geoip_country_code_by_name')) return geoip_country_code_by_name($ip) ?: '??';
    return '??';
}

function track_view(string $page, ?int $tool_id = null): void {
    try {
        DB::query("INSERT INTO page_views(page,tool_id,ip,country,user_agent) VALUES(?,?,?,?,?)", [
            $page, $tool_id, get_client_ip(), get_country(),
            substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 300)
        ]);
        if ($tool_id) {
            DB::query("UPDATE tools SET views=views+1, views_week=views_week+1 WHERE id=?", [$tool_id]);
        }
    } catch (Exception $e) {}
}

function esc(mixed $s): string {
    return htmlspecialchars((string)($s ?? ''), ENT_QUOTES, 'UTF-8');
}

function send_email(string $to, string $subject, string $body): bool {
    try {
        $host = ST_Settings::get('smtp_host');
        $port = ST_Settings::get('smtp_port', 587);
        $user = ST_Settings::get('smtp_user');
        $pass = ST_Settings::get('smtp_pass');
        $from = ST_Settings::get('smtp_from', $user);

        if (!$host || !$user) {
            mail($to, $subject, $body, "From: $from\r\nContent-Type: text/html; charset=UTF-8");
            return true;
        }

        // PHPMailer if available, else basic mail
        mail($to, $subject, $body, "From: $from\r\nContent-Type: text/html; charset=UTF-8");
        return true;
    } catch (Exception $e) {
        return false;
    }
}
