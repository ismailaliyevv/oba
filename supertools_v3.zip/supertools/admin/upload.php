<?php
require_once __DIR__ . '/includes/config.php';
Auth::require();
header('Content-Type: application/json');
if (!isset($_FILES['file'])) { echo json_encode(['success'=>false,'error'=>'No file']); exit; }
$file = $_FILES['file'];
$allowed = ['jpg','jpeg','png','gif','webp'];
$ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
if (!in_array($ext, $allowed)) { echo json_encode(['success'=>false,'error'=>'Invalid type']); exit; }
if ($file['size'] > 5*1024*1024) { echo json_encode(['success'=>false,'error'=>'Max 5MB']); exit; }
$dir = dirname(__DIR__).'/uploads/';
if (!is_dir($dir)) mkdir($dir, 0755, true);
$name = uniqid().'.'.$ext;
move_uploaded_file($file['tmp_name'], $dir.$name);
echo json_encode(['success'=>true,'url'=>BASE_URL.'/../uploads/'.$name]);
