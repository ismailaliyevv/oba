<?php
require_once __DIR__ . '/admin/includes/config.php';

UserAuth::start();
$lang = Lang::detect();
Lang::load($lang);

$slug = sanitize($_GET['slug'] ?? '');
if (!$slug) { header('Location: index.php'); exit; }

$tool = DB::fetch(
    "SELECT t.*, c.name cat_name, c.icon cat_icon, c.color cat_color
     FROM tools t LEFT JOIN categories c ON c.id=t.category_id
     WHERE t.slug=? AND t.status='active'",
    [$slug]
);
if (!$tool) { header('HTTP/1.0 404 Not Found'); include __DIR__.'/404.php'; exit; }

// Premium check
$currentUser = UserAuth::check() ? UserAuth::user() : null;
if ($tool['is_premium'] && (!$currentUser || $currentUser['plan_price'] <= 0)) {
    // Show upgrade prompt
    $requiresUpgrade = true;
}

// Track view
track_view('/tool/'.$slug, $tool['id']);

$siteName   = ST_Settings::get('site_name', 'SuperTools');
$themeColor = ST_Settings::get('theme_color', '#6366f1');
$logoIcon   = ST_Settings::get('logo_icon', '⚡');
$gaId       = ST_Settings::get('google_analytics_id', '');

$metaTitle = $tool['meta_title'] ?: $tool['name'].' — '.$siteName;
$metaDesc  = $tool['meta_desc']  ?: $tool['description'];

// Related tools
$related = DB::fetchAll(
    "SELECT t.* FROM tools t WHERE t.category_id=? AND t.id!=? AND t.status='active' ORDER BY t.views_week DESC LIMIT 4",
    [$tool['category_id'], $tool['id']]
);

// Ads
$sidebarAd  = DB::fetch("SELECT code FROM advertisements WHERE slot='sidebar' AND status=1 LIMIT 1");
$incontentAd= DB::fetch("SELECT code FROM advertisements WHERE slot='incontent' AND status=1 LIMIT 1");
?>
<!DOCTYPE html>
<html lang="<?= esc($lang) ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= esc($metaTitle) ?></title>
<meta name="description" content="<?= esc($metaDesc) ?>">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;500;600;700;800&family=DM+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<?php if($gaId): ?><script async src="https://www.googletagmanager.com/gtag/js?id=<?=esc($gaId)?>"></script><script>window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments)}gtag('js',new Date());gtag('config','<?=esc($gaId)?>');</script><?php endif; ?>
<style>
:root{
  --accent:<?= esc($themeColor) ?>;
  --bg:#fafafa;--surface:#fff;--border:#e5e7eb;
  --text:#111827;--muted:#6b7280;--dark:#0f172a;--dark2:#1e293b;
  --radius:14px;--shadow:0 4px 24px rgba(0,0,0,.08);
}
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:'DM Sans',sans-serif;background:var(--bg);color:var(--text)}
/* Navbar same as index */
.navbar{background:var(--dark);position:sticky;top:0;z-index:100;border-bottom:1px solid rgba(255,255,255,.08);}
.nav-inner{max-width:1280px;margin:0 auto;padding:0 24px;height:64px;display:flex;align-items:center;gap:20px;}
.nav-logo{display:flex;align-items:center;gap:10px;text-decoration:none;}
.logo-mark{width:36px;height:36px;background:var(--accent);border-radius:9px;display:flex;align-items:center;justify-content:center;font-size:18px;}
.logo-name{font-family:'Syne',sans-serif;font-size:20px;font-weight:800;color:#fff;}
.nav-back{display:flex;align-items:center;gap:6px;color:rgba(255,255,255,.6);text-decoration:none;font-size:13px;font-weight:500;padding:7px 12px;border-radius:8px;transition:.15s;}
.nav-back:hover{color:#fff;background:rgba(255,255,255,.08);}
.nav-spacer{flex:1}
.user-nav-item{display:flex;align-items:center;gap:6px;padding:7px 14px;border-radius:8px;background:rgba(255,255,255,.08);color:rgba(255,255,255,.7);text-decoration:none;font-size:13px;font-weight:500;}

/* Breadcrumb */
.breadcrumb{max-width:1280px;margin:20px auto;padding:0 24px;display:flex;align-items:center;gap:8px;font-size:13px;color:var(--muted);}
.breadcrumb a{color:var(--accent);text-decoration:none;}
.breadcrumb a:hover{text-decoration:underline;}
.breadcrumb-sep{color:var(--border);}

/* Layout */
.tool-layout{max-width:1280px;margin:0 auto;padding:0 24px 60px;display:grid;grid-template-columns:1fr 300px;gap:24px;align-items:start;}
.tool-main{}
.tool-sidebar{position:sticky;top:84px;}

/* Tool header */
.tool-header{background:var(--surface);border:1.5px solid var(--border);border-radius:var(--radius);padding:28px;margin-bottom:20px;}
.tool-header-top{display:flex;align-items:flex-start;gap:16px;margin-bottom:16px;}
.tool-icon-big{width:64px;height:64px;border-radius:16px;background:<?= esc($tool['cat_color']??'#6366f1') ?>22;display:flex;align-items:center;justify-content:center;font-size:32px;flex-shrink:0;}
.tool-info{}
.tool-title{font-family:'Syne',sans-serif;font-size:26px;font-weight:800;color:var(--text);margin-bottom:6px;}
.tool-description{font-size:14px;color:var(--muted);line-height:1.7;}
.tool-badges{display:flex;gap:8px;flex-wrap:wrap;margin-top:12px;}
.badge{display:inline-flex;align-items:center;gap:4px;padding:4px 10px;border-radius:20px;font-size:12px;font-weight:600;}
.badge-cat{background:<?= esc($tool['cat_color']??'#6366f1') ?>22;color:<?= esc($tool['cat_color']??'#6366f1') ?>;}
.badge-views{background:var(--bg);color:var(--muted);border:1px solid var(--border);}
.badge-premium{background:linear-gradient(135deg,#f59e0b,#d97706);color:#fff;}

/* Tool frame */
.tool-frame-wrap{background:var(--surface);border:1.5px solid var(--border);border-radius:var(--radius);overflow:hidden;margin-bottom:20px;}
.tool-frame-header{padding:12px 20px;background:var(--bg);border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;}
.tool-frame-title{font-size:13px;font-weight:700;color:var(--muted);text-transform:uppercase;letter-spacing:.5px;}
.tool-frame{width:100%;border:none;min-height:500px;display:block;}

/* Premium lock */
.premium-lock{text-align:center;padding:60px 24px;background:var(--surface);border:1.5px solid var(--border);border-radius:var(--radius);margin-bottom:20px;}
.lock-icon{font-size:48px;margin-bottom:16px;}
.lock-title{font-family:'Syne',sans-serif;font-size:22px;font-weight:800;margin-bottom:8px;}
.lock-desc{font-size:14px;color:var(--muted);margin-bottom:24px;}
.btn-upgrade{display:inline-flex;align-items:center;gap:8px;padding:12px 28px;background:var(--accent);color:#fff;border-radius:10px;font-weight:700;text-decoration:none;font-size:15px;transition:.2s;}
.btn-upgrade:hover{opacity:.9;transform:translateY(-1px);}

/* Sidebar */
.sidebar-card{background:var(--surface);border:1.5px solid var(--border);border-radius:var(--radius);padding:20px;margin-bottom:16px;}
.sidebar-title{font-size:13px;font-weight:700;color:var(--muted);text-transform:uppercase;letter-spacing:.5px;margin-bottom:14px;}
.related-tool{display:flex;align-items:center;gap:12px;padding:10px 0;border-bottom:1px solid var(--border);text-decoration:none;transition:.15s;}
.related-tool:last-child{border:none;}
.related-tool:hover .related-name{color:var(--accent);}
.related-icon{width:36px;height:36px;border-radius:9px;background:var(--bg);display:flex;align-items:center;justify-content:center;font-size:18px;flex-shrink:0;}
.related-name{font-size:13px;font-weight:600;color:var(--text);}
.related-views{font-size:11px;color:var(--muted);}

/* Share */
.share-btns{display:flex;gap:8px;flex-wrap:wrap;}
.share-btn{display:flex;align-items:center;gap:6px;padding:8px 12px;border-radius:8px;font-size:12px;font-weight:600;cursor:pointer;border:1.5px solid var(--border);background:none;color:var(--text);transition:.15s;font-family:inherit;}
.share-btn:hover{border-color:var(--accent);color:var(--accent);}

@media(max-width:768px){
  .tool-layout{grid-template-columns:1fr;}
  .tool-sidebar{position:static;}
  .tool-header-top{flex-direction:column;}
}
</style>
</head>
<body>

<nav class="navbar">
  <div class="nav-inner">
    <a href="index.php" class="nav-logo">
      <div class="logo-mark"><?= esc($logoIcon) ?></div>
      <div class="logo-name"><?= esc($siteName) ?></div>
    </a>
    <a href="javascript:history.back()" class="nav-back">← Back</a>
    <div class="nav-spacer"></div>
    <?php if($currentUser): ?>
    <a href="profile.php" class="user-nav-item">
      👤 <?= esc($currentUser['name'] ?? 'Profile') ?>
    </a>
    <?php else: ?>
    <a href="auth.php?action=login" class="user-nav-item">Log in</a>
    <?php endif; ?>
  </div>
</nav>

<div class="breadcrumb">
  <a href="index.php">Home</a>
  <span class="breadcrumb-sep">›</span>
  <a href="index.php#cat-<?= esc($tool['slug']) ?>"><?= esc($tool['cat_icon'].' '.$tool['cat_name']) ?></a>
  <span class="breadcrumb-sep">›</span>
  <span><?= esc($tool['name']) ?></span>
</div>

<div class="tool-layout">
  <div class="tool-main">

    <!-- Tool Header -->
    <div class="tool-header">
      <div class="tool-header-top">
        <div class="tool-icon-big"><?= esc($tool['icon']) ?></div>
        <div class="tool-info">
          <div class="tool-title"><?= esc($tool['name']) ?></div>
          <div class="tool-description"><?= esc($tool['description']) ?></div>
          <div class="tool-badges">
            <span class="badge badge-cat"><?= esc($tool['cat_icon'].' '.$tool['cat_name']) ?></span>
            <span class="badge badge-views">👁 <?= number_format($tool['views']) ?> uses</span>
            <?php if($tool['is_premium']): ?>
            <span class="badge badge-premium">⭐ PRO</span>
            <?php endif; ?>
          </div>
        </div>
      </div>
    </div>

    <?php if(isset($requiresUpgrade)): ?>
    <!-- Premium Lock -->
    <div class="premium-lock">
      <div class="lock-icon">🔒</div>
      <div class="lock-title">This is a PRO Tool</div>
      <div class="lock-desc">Upgrade your plan to access this tool and many more premium features.</div>
      <a href="pricing.php" class="btn-upgrade">⚡ Upgrade to Pro</a>
    </div>
    <?php elseif($tool['path']): ?>
    <!-- Tool Frame -->
    <div class="tool-frame-wrap">
      <div class="tool-frame-header">
        <span class="tool-frame-title"><?= esc($tool['name']) ?></span>
        <span style="font-size:12px;color:var(--muted)">Free Tool</span>
      </div>
      <?php
      $toolFile = __DIR__.'/'.$tool['path'];
      if (file_exists($toolFile)):
      ?>
      <iframe class="tool-frame" src="<?= esc(BASE_URL.'/'.$tool['path']) ?>" id="tool-iframe"
        onload="resizeIframe(this)"></iframe>
      <?php else: ?>
      <div style="padding:60px;text-align:center;color:var(--muted)">
        <div style="font-size:48px;margin-bottom:12px">🚧</div>
        <div>This tool is coming soon!</div>
      </div>
      <?php endif; ?>
    </div>
    <?php endif; ?>

    <!-- In-content Ad -->
    <?php if($incontentAd): ?>
    <div style="margin-bottom:20px"><?= $incontentAd['code'] ?></div>
    <?php endif; ?>

  </div>

  <!-- Sidebar -->
  <div class="tool-sidebar">

    <!-- Related Tools -->
    <?php if(!empty($related)): ?>
    <div class="sidebar-card">
      <div class="sidebar-title">Related Tools</div>
      <?php foreach($related as $rt): ?>
      <a href="tool.php?slug=<?= esc($rt['slug']) ?>" class="related-tool">
        <div class="related-icon"><?= esc($rt['icon']) ?></div>
        <div>
          <div class="related-name"><?= esc($rt['name']) ?></div>
          <div class="related-views">👁 <?= number_format($rt['views_week']) ?> uses</div>
        </div>
      </a>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <!-- Share -->
    <div class="sidebar-card">
      <div class="sidebar-title">Share Tool</div>
      <div class="share-btns">
        <button class="share-btn" onclick="copyLink()">📋 Copy Link</button>
        <button class="share-btn" onclick="share('twitter')">🐦 Twitter</button>
        <button class="share-btn" onclick="share('whatsapp')">💬 WhatsApp</button>
      </div>
    </div>

    <!-- Sidebar Ad -->
    <?php if($sidebarAd): ?>
    <div class="sidebar-card" style="padding:0;overflow:hidden">
      <?= $sidebarAd['code'] ?>
    </div>
    <?php endif; ?>

    <!-- Upgrade CTA -->
    <?php if(!$currentUser || ($currentUser['plan_price']??0) <= 0): ?>
    <div class="sidebar-card" style="background:linear-gradient(135deg,var(--accent),color-mix(in srgb,var(--accent) 70%,#000));border-color:transparent">
      <div style="font-family:'Syne',sans-serif;font-size:16px;font-weight:800;color:#fff;margin-bottom:8px">⚡ Go Pro</div>
      <div style="font-size:13px;color:rgba(255,255,255,.8);margin-bottom:16px">Unlock all premium tools, no ads, and priority support.</div>
      <a href="pricing.php" style="display:block;text-align:center;padding:10px;background:rgba(255,255,255,.15);color:#fff;border-radius:8px;font-weight:700;text-decoration:none;font-size:13px;border:1px solid rgba(255,255,255,.2)">View Plans →</a>
    </div>
    <?php endif; ?>

  </div>
</div>

<script>
function resizeIframe(iframe){
  try{
    iframe.style.height=Math.max(500,iframe.contentDocument?.body?.scrollHeight||500)+'px';
  }catch(e){}
}

function copyLink(){
  navigator.clipboard.writeText(window.location.href).then(()=>{
    const btn=event.target;btn.textContent='✅ Copied!';
    setTimeout(()=>btn.textContent='📋 Copy Link',2000);
  });
}

function share(platform){
  const url=encodeURIComponent(window.location.href);
  const title=encodeURIComponent('<?= esc($tool['name']) ?> — <?= esc($siteName) ?>');
  const urls={
    twitter:`https://twitter.com/intent/tweet?url=${url}&text=${title}`,
    whatsapp:`https://wa.me/?text=${title}%20${url}`,
  };
  window.open(urls[platform],'_blank','width=600,height=400');
}
</script>
</body>
</html>
