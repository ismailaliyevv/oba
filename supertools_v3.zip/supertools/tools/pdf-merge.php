<?php
/**
 * PDF Merger Tool
 * PDFtk və ya GhostScript ilə birləşdirmə
 */

$error   = '';
$result  = null;
$tmpDir  = sys_get_temp_dir() . '/supertools/';
if (!is_dir($tmpDir)) mkdir($tmpDir, 0755, true);

// Download
if (isset($_GET['download'])) {
    $safe = basename($_GET['download']);
    $fp   = $tmpDir . $safe;
    if (file_exists($fp) && preg_match('/^merged_[a-f0-9]+\.pdf$/', $safe)) {
        header('Content-Type: application/pdf');
        header('Content-Disposition: attachment; filename="merged.pdf"');
        header('Content-Length: ' . filesize($fp));
        readfile($fp);
        @unlink($fp);
        exit;
    }
    exit('File not found.');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $files = $_FILES['files'] ?? [];
    $names = $files['name']    ?? [];

    if (empty($names) || count($names) < 2) {
        $error = 'Please upload at least 2 PDF files.';
    } else {
        $uploaded = [];
        foreach ($names as $i => $name) {
            if ($files['error'][$i] !== UPLOAD_ERR_OK) continue;
            $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
            if ($ext !== 'pdf') { $error = 'Only PDF files are allowed.'; break; }
            if ($files['size'][$i] > 50*1024*1024) { $error = 'Each file max 50MB.'; break; }
            $tmp = $tmpDir . uniqid('pdf_') . '.pdf';
            move_uploaded_file($files['tmp_name'][$i], $tmp);
            $uploaded[] = $tmp;
        }

        if (!$error && count($uploaded) >= 2) {
            $outFile = $tmpDir . 'merged_' . uniqid() . '.pdf';

            // Try pdftk
            $pdftk = '';
            foreach (['/usr/bin/pdftk','/usr/local/bin/pdftk'] as $p) { if(file_exists($p)){$pdftk=$p;break;} }

            // Try ghostscript
            $gs = '';
            foreach (['/usr/bin/gs','/usr/local/bin/gs'] as $p) { if(file_exists($p)){$gs=$p;break;} }

            if ($pdftk) {
                $cmd = escapeshellcmd($pdftk) . ' ' .
                       implode(' ', array_map('escapeshellarg', $uploaded)) .
                       ' cat output ' . escapeshellarg($outFile) . ' 2>&1';
                exec($cmd, $out, $code);
                if ($code === 0 && file_exists($outFile)) {
                    $result = basename($outFile);
                } else {
                    $error = 'PDFtk merge failed.';
                }
            } elseif ($gs) {
                $inputs = implode(' ', array_map('escapeshellarg', $uploaded));
                $cmd = escapeshellcmd($gs) .
                       ' -dBATCH -dNOPAUSE -q -sDEVICE=pdfwrite -sOutputFile=' .
                       escapeshellarg($outFile) . ' ' . $inputs . ' 2>&1';
                exec($cmd, $out, $code);
                if ($code === 0 && file_exists($outFile)) {
                    $result = basename($outFile);
                } else {
                    $error = 'GhostScript merge failed.';
                }
            } else {
                $error = 'demo';
            }

            foreach ($uploaded as $f) @unlink($f);
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>PDF Merger</title>
<meta name="description" content="Free online PDF merger. Combine multiple PDF files into one.">
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:'DM Sans','Segoe UI',sans-serif;background:#fff;color:#111827;padding:28px 24px;max-width:640px;margin:0 auto;}
h1{font-size:22px;font-weight:800;margin-bottom:6px;}
.sub{font-size:14px;color:#6b7280;margin-bottom:24px;line-height:1.5;}
.drop{border:2px dashed #d1d5db;border-radius:12px;padding:40px 24px;text-align:center;cursor:pointer;transition:.2s;position:relative;background:#fafafa;}
.drop:hover,.drop.over{border-color:#ef4444;background:#fff5f5;}
.drop-icon{font-size:40px;display:block;margin-bottom:8px;}
.drop-title{font-size:15px;font-weight:700;color:#374151;}
.drop-sub{font-size:12px;color:#9ca3af;margin-top:4px;}
input[type=file]{position:absolute;inset:0;opacity:0;cursor:pointer;width:100%;height:100%;}
.file-list{margin-top:14px;display:flex;flex-direction:column;gap:8px;}
.file-item{display:flex;align-items:center;gap:10px;padding:10px 14px;background:#f9fafb;border:1px solid #e5e7eb;border-radius:9px;}
.file-item-icon{font-size:20px;flex-shrink:0;}
.file-item-name{font-size:13px;font-weight:600;color:#374151;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
.file-item-size{font-size:11px;color:#9ca3af;flex-shrink:0;}
.rm{background:none;border:none;color:#ef4444;cursor:pointer;font-size:16px;padding:0 4px;flex-shrink:0;}
.order-note{font-size:12px;color:#6b7280;margin:8px 0 4px;text-align:center;}
.prog{height:5px;background:#e5e7eb;border-radius:3px;margin:14px 0;overflow:hidden;display:none;}
.prog-fill{height:100%;background:#ef4444;border-radius:3px;width:0%;transition:width .3s;}
.status{font-size:12px;color:#6b7280;text-align:center;min-height:18px;margin-bottom:4px;}
.btn{width:100%;padding:13px;background:#ef4444;color:#fff;border:none;border-radius:10px;font-size:14px;font-weight:700;cursor:pointer;transition:.2s;font-family:inherit;margin-top:4px;}
.btn:hover{background:#dc2626;}
.btn:disabled{opacity:.4;cursor:not-allowed;}
.result{display:none;text-align:center;padding:24px;background:#f0fdf4;border:1px solid #bbf7d0;border-radius:12px;margin-top:14px;}
.result.show{display:block;}
.result-icon{font-size:40px;margin-bottom:8px;}
.dl-btn{display:inline-flex;align-items:center;gap:8px;padding:11px 24px;background:#16a34a;color:#fff;border-radius:9px;font-weight:700;font-size:13px;text-decoration:none;transition:.2s;}
.dl-btn:hover{background:#15803d;}
.err{padding:11px 14px;background:#fef2f2;border:1px solid #fecaca;border-radius:9px;font-size:13px;color:#dc2626;margin-top:12px;}
.demo-note{padding:11px 14px;background:#fffbeb;border:1px solid #fde68a;border-radius:9px;font-size:12px;color:#92400e;margin-top:12px;line-height:1.6;}
.note{font-size:11px;color:#9ca3af;text-align:center;margin-top:16px;}
.count-badge{display:inline-block;padding:2px 8px;background:#fee2e2;color:#dc2626;border-radius:20px;font-size:11px;font-weight:700;}
</style>
</head>
<body>
<h1>🔀 PDF Merger</h1>
<div class="sub">Combine multiple PDF files into one. Drag to reorder before merging.</div>

<?php if ($error === 'demo'): ?>
<div class="demo-note">ℹ️ <strong>PDFtk/GhostScript not found.</strong><br>
Install: <code>sudo apt install pdftk</code> or <code>sudo apt install ghostscript</code></div>
<?php elseif ($error): ?>
<div class="err">⚠️ <?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<?php if ($result): ?>
<div class="result show">
  <div class="result-icon">✅</div>
  <div style="font-size:15px;font-weight:700;color:#166534;margin-bottom:4px">PDFs merged successfully!</div>
  <div style="font-size:12px;color:#4ade80;margin-bottom:16px">Your merged PDF is ready</div>
  <a href="?download=<?= urlencode($result) ?>" class="dl-btn">⬇ Download Merged PDF</a>
</div>
<?php endif; ?>

<form method="POST" enctype="multipart/form-data" id="merge-form">
  <div class="drop" id="drop-area">
    <span class="drop-icon">📑</span>
    <div class="drop-title">Select PDF Files</div>
    <div class="drop-sub">Select 2 or more PDF files · Max 50MB each</div>
    <input type="file" name="files[]" id="file-input" accept=".pdf" multiple onchange="handleFiles(this.files)">
  </div>

  <div class="file-list" id="file-list"></div>
  <div class="order-note" id="order-note" style="display:none">Drag files to change merge order</div>

  <div class="prog" id="prog"><div class="prog-fill" id="prog-fill"></div></div>
  <div class="status" id="status-lbl"></div>

  <button type="submit" class="btn" id="merge-btn" disabled onclick="startProgress()">
    Merge PDFs <span id="file-count-badge"></span>
  </button>
</form>

<div class="note">Files are merged on server and deleted after download.</div>

<script>
let selectedFiles = [];
const dropArea = document.getElementById('drop-area');

dropArea.addEventListener('dragover', e => { e.preventDefault(); dropArea.classList.add('over'); });
dropArea.addEventListener('dragleave', () => dropArea.classList.remove('over'));
dropArea.addEventListener('drop', e => {
  e.preventDefault(); dropArea.classList.remove('over');
  handleFiles(e.dataTransfer.files);
});

function handleFiles(files) {
  for (const f of files) {
    if (!f.name.match(/\.pdf$/i)) { alert('Only PDF files: ' + f.name); continue; }
    if (f.size > 50*1024*1024) { alert('Too large: ' + f.name); continue; }
    selectedFiles.push(f);
  }
  renderList();
}

function renderList() {
  const list = document.getElementById('file-list');
  const btn  = document.getElementById('merge-btn');
  const note = document.getElementById('order-note');
  const badge= document.getElementById('file-count-badge');

  list.innerHTML = selectedFiles.map((f,i) => `
    <div class="file-item" draggable="true" data-i="${i}">
      <span class="file-item-icon">📄</span>
      <span class="file-item-name">${i+1}. ${esc(f.name)}</span>
      <span class="file-item-size">${fmt(f.size)}</span>
      <button type="button" class="rm" onclick="removeFile(${i})">✕</button>
    </div>`).join('');

  btn.disabled = selectedFiles.length < 2;
  note.style.display = selectedFiles.length >= 2 ? 'block' : 'none';
  badge.innerHTML = selectedFiles.length >= 2 ? `<span class="count-badge">${selectedFiles.length}</span>` : '';

  // Rebuild FormData on submit
  updateFormFiles();
}

function removeFile(i) {
  selectedFiles.splice(i, 1);
  renderList();
}

function updateFormFiles() {
  // We use a hidden file input approach — just let the form submit with original files
  // For reordering, we'd need fetch API. For simplicity, keep original order.
}

function startProgress() {
  document.getElementById('prog').style.display = 'block';
  const fill   = document.getElementById('prog-fill');
  const status = document.getElementById('status-lbl');
  let p = 0;
  const msgs = ['Uploading files…','Merging PDFs…','Finalizing…'];
  const t = setInterval(() => {
    p = Math.min(p + 2, 88);
    fill.style.width = p + '%';
    status.textContent = msgs[Math.floor(p/30)] || msgs[2];
    if (p >= 88) clearInterval(t);
  }, 100);
}

function fmt(b){if(b<1024)return b+' B';if(b<1048576)return(b/1024).toFixed(1)+' KB';return(b/1048576).toFixed(1)+' MB';}
function esc(s){return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');}
</script>
</body>
</html>
