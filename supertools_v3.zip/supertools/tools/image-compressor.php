<?php
/**
 * Image Compressor Tool — PHP GD ilə
 */

$error  = '';
$result = null;
$tmpDir = sys_get_temp_dir() . '/supertools/';
if (!is_dir($tmpDir)) mkdir($tmpDir, 0755, true);

// Download
if (isset($_GET['download'])) {
    $safe = basename($_GET['download']);
    $fp   = $tmpDir . $safe;
    if (file_exists($fp) && preg_match('/^comp_[a-f0-9]+\.(jpg|jpeg|png|webp)$/', $safe)) {
        $mime = match(pathinfo($safe, PATHINFO_EXTENSION)) {
            'png'  => 'image/png',
            'webp' => 'image/webp',
            default => 'image/jpeg',
        };
        header('Content-Type: ' . $mime);
        header('Content-Disposition: attachment; filename="' . ($_GET['fn'] ?? 'compressed.jpg') . '"');
        header('Content-Length: ' . filesize($fp));
        readfile($fp);
        @unlink($fp);
        exit;
    }
    exit('File not found.');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $file    = $_FILES['image'] ?? null;
    $quality = max(1, min(100, (int)($_POST['quality'] ?? 80)));
    $allowed = ['jpg','jpeg','png','webp','gif'];

    if (!$file || $file['error'] !== UPLOAD_ERR_OK) {
        $error = 'Upload failed. Please try again.';
    } else {
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        if (!in_array($ext, $allowed)) {
            $error = 'Unsupported format. Use JPG, PNG, WebP or GIF.';
        } elseif ($file['size'] > 20*1024*1024) {
            $error = 'Max file size is 20MB.';
        } elseif (!extension_loaded('gd')) {
            $error = 'GD library not available on server.';
        } else {
            $src = $file['tmp_name'];
            $info = getimagesize($src);

            if (!$info) {
                $error = 'Invalid image file.';
            } else {
                // Load image
                $img = match($info[2]) {
                    IMAGETYPE_JPEG => imagecreatefromjpeg($src),
                    IMAGETYPE_PNG  => imagecreatefrompng($src),
                    IMAGETYPE_WEBP => imagecreatefromwebp($src),
                    IMAGETYPE_GIF  => imagecreatefromgif($src),
                    default        => null
                };

                if (!$img) {
                    $error = 'Could not process image.';
                } else {
                    $outExt  = in_array($ext, ['jpg','jpeg']) ? 'jpg' : ($ext === 'png' ? 'png' : 'jpg');
                    $outName = 'comp_' . uniqid() . '.' . $outExt;
                    $outPath = $tmpDir . $outName;

                    $origSize = $file['size'];
                    $ok = false;

                    if ($outExt === 'jpg') {
                        // JPEG quality 1-100
                        $ok = imagejpeg($img, $outPath, $quality);
                    } elseif ($outExt === 'png') {
                        // PNG compression 0-9
                        $pngComp = (int)round((100 - $quality) / 11);
                        $ok = imagepng($img, $outPath, $pngComp);
                    } elseif (function_exists('imagewebp')) {
                        $ok = imagewebp($img, $outPath, $quality);
                    }

                    imagedestroy($img);

                    if ($ok && file_exists($outPath)) {
                        $newSize = filesize($outPath);
                        $saved   = $origSize - $newSize;
                        $pct     = $origSize > 0 ? round(($saved / $origSize) * 100) : 0;
                        $result  = [
                            'file'     => $outName,
                            'orig'     => $origSize,
                            'new'      => $newSize,
                            'saved'    => $saved,
                            'pct'      => $pct,
                            'filename' => pathinfo($file['name'], PATHINFO_FILENAME) . '_compressed.' . $outExt,
                            'w'        => $info[0],
                            'h'        => $info[1],
                        ];
                    } else {
                        $error = 'Compression failed.';
                    }
                }
            }
        }
    }
}

function fmtBytes($b) {
    if ($b < 1024) return $b . ' B';
    if ($b < 1048576) return round($b/1024, 1) . ' KB';
    return round($b/1048576, 1) . ' MB';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Image Compressor</title>
<meta name="description" content="Free online image compressor. Reduce image file size without losing quality.">
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:'DM Sans','Segoe UI',sans-serif;background:#fff;color:#111827;padding:28px 24px;max-width:640px;margin:0 auto;}
h1{font-size:22px;font-weight:800;margin-bottom:6px;}
.sub{font-size:14px;color:#6b7280;margin-bottom:24px;line-height:1.5;}
.drop{border:2px dashed #d1d5db;border-radius:12px;padding:48px 24px;text-align:center;cursor:pointer;transition:.2s;position:relative;background:#fafafa;}
.drop:hover,.drop.over{border-color:#10b981;background:#f0fdf4;}
.drop-icon{font-size:44px;display:block;margin-bottom:10px;}
input[type=file]{position:absolute;inset:0;opacity:0;cursor:pointer;width:100%;height:100%;}
.preview-wrap{margin-top:14px;display:none;position:relative;}
.preview-wrap.show{display:block;}
.preview-img{width:100%;border-radius:10px;max-height:260px;object-fit:contain;background:#f9fafb;border:1px solid #e5e7eb;}
.rm-btn{position:absolute;top:8px;right:8px;background:rgba(0,0,0,.5);color:#fff;border:none;border-radius:50%;width:26px;height:26px;cursor:pointer;font-size:14px;display:flex;align-items:center;justify-content:center;}
.file-info{display:flex;align-items:center;justify-content:space-between;padding:8px 12px;background:#f9fafb;border:1px solid #e5e7eb;border-radius:8px;margin-top:8px;font-size:12px;color:#6b7280;}
.quality-wrap{margin:16px 0;}
.quality-label{display:flex;justify-content:space-between;font-size:13px;font-weight:600;margin-bottom:8px;}
.quality-val{color:#10b981;font-weight:700;}
input[type=range]{width:100%;accent-color:#10b981;}
.quality-hints{display:flex;justify-content:space-between;font-size:10px;color:#9ca3af;margin-top:4px;}
.btn{width:100%;padding:13px;background:#10b981;color:#fff;border:none;border-radius:10px;font-size:14px;font-weight:700;cursor:pointer;transition:.2s;font-family:inherit;}
.btn:hover{background:#059669;}
.btn:disabled{opacity:.4;cursor:not-allowed;}
.result{display:none;margin-top:14px;}
.result.show{display:block;}
.result-grid{display:grid;grid-template-columns:1fr 1fr 1fr;gap:10px;margin-bottom:14px;}
.result-stat{text-align:center;padding:14px 10px;background:#f9fafb;border:1px solid #e5e7eb;border-radius:10px;}
.result-stat-num{font-size:18px;font-weight:800;color:#111827;}
.result-stat-num.green{color:#10b981;}
.result-stat-label{font-size:11px;color:#9ca3af;margin-top:3px;}
.dl-btn{display:flex;align-items:center;justify-content:center;gap:8px;padding:12px;background:#10b981;color:#fff;border-radius:9px;font-weight:700;font-size:14px;text-decoration:none;transition:.2s;}
.dl-btn:hover{background:#059669;}
.err{padding:11px 14px;background:#fef2f2;border:1px solid #fecaca;border-radius:9px;font-size:13px;color:#dc2626;margin-top:12px;}
.note{font-size:11px;color:#9ca3af;text-align:center;margin-top:16px;}
</style>
</head>
<body>
<h1>🗜️ Image Compressor</h1>
<div class="sub">Compress JPG, PNG and WebP images. Reduce file size while preserving quality.</div>

<?php if ($error): ?><div class="err">⚠️ <?= htmlspecialchars($error) ?></div><?php endif; ?>

<?php if ($result): ?>
<div class="result show">
  <div class="result-grid">
    <div class="result-stat"><div class="result-stat-num"><?= fmtBytes($result['orig']) ?></div><div class="result-stat-label">Original</div></div>
    <div class="result-stat"><div class="result-stat-num"><?= fmtBytes($result['new']) ?></div><div class="result-stat-label">Compressed</div></div>
    <div class="result-stat"><div class="result-stat-num green"><?= $result['pct'] ?>%</div><div class="result-stat-label">Saved</div></div>
  </div>
  <a href="?download=<?= urlencode($result['file']) ?>&fn=<?= urlencode($result['filename']) ?>" class="dl-btn">⬇ Download Compressed Image</a>
  <div style="text-align:center;margin-top:8px;font-size:11px;color:#9ca3af"><?= $result['w'] ?>×<?= $result['h'] ?>px · <?= htmlspecialchars($result['filename']) ?></div>
</div>
<?php endif; ?>

<form method="POST" enctype="multipart/form-data">
  <div class="drop" id="drop-area">
    <span class="drop-icon">🖼️</span>
    <div style="font-size:15px;font-weight:700;color:#374151">Select Image or Drop Here</div>
    <div style="font-size:12px;color:#9ca3af;margin-top:4px">JPG, PNG, WebP, GIF — Max 20MB</div>
    <input type="file" name="image" id="file-inp" accept=".jpg,.jpeg,.png,.webp,.gif" onchange="preview(this)">
  </div>

  <div class="preview-wrap" id="preview-wrap">
    <img class="preview-img" id="preview-img" src="" alt="preview">
    <button type="button" class="rm-btn" onclick="clearFile()">✕</button>
    <div class="file-info">
      <span id="file-name-info">—</span>
      <span id="file-size-info">—</span>
    </div>
  </div>

  <div class="quality-wrap">
    <div class="quality-label">
      <span>Compression Quality</span>
      <span class="quality-val" id="quality-val">80%</span>
    </div>
    <input type="range" name="quality" id="quality-range" min="10" max="100" value="80" step="5" oninput="document.getElementById('quality-val').textContent=this.value+'%'">
    <div class="quality-hints"><span>Smaller file</span><span>Best quality</span></div>
  </div>

  <button type="submit" class="btn" id="compress-btn" disabled>Compress Image</button>
</form>

<div class="note">Images are processed on server and immediately deleted after download.</div>

<script>
document.getElementById('drop-area').addEventListener('dragover',e=>{e.preventDefault();e.currentTarget.classList.add('over');});
document.getElementById('drop-area').addEventListener('dragleave',e=>e.currentTarget.classList.remove('over'));
document.getElementById('drop-area').addEventListener('drop',e=>{e.preventDefault();e.currentTarget.classList.remove('over');const f=e.dataTransfer.files[0];if(f){const dt=new DataTransfer();dt.items.add(f);document.getElementById('file-inp').files=dt.files;preview(document.getElementById('file-inp'));}});

function preview(inp){
  const f=inp.files[0];if(!f)return;
  const url=URL.createObjectURL(f);
  document.getElementById('preview-img').src=url;
  document.getElementById('preview-wrap').classList.add('show');
  document.getElementById('file-name-info').textContent=f.name;
  document.getElementById('file-size-info').textContent=fmt(f.size);
  document.getElementById('compress-btn').disabled=false;
}
function clearFile(){document.getElementById('file-inp').value='';document.getElementById('preview-wrap').classList.remove('show');document.getElementById('compress-btn').disabled=true;}
function fmt(b){if(b<1024)return b+' B';if(b<1048576)return(b/1024).toFixed(1)+' KB';return(b/1048576).toFixed(1)+' MB';}
</script>
</body>
</html>
