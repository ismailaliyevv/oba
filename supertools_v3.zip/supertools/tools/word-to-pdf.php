<?php
/**
 * Word to PDF Converter
 * LibreOffice və ya unoconv ilə çevirmə
 */

$error  = '';
$result = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['file'])) {
    $file = $_FILES['file'];
    $allowed = ['doc','docx'];
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

    if ($file['error'] !== UPLOAD_ERR_OK) {
        $error = 'Upload error. Please try again.';
    } elseif (!in_array($ext, $allowed)) {
        $error = 'Only .doc and .docx files are allowed.';
    } elseif ($file['size'] > 50 * 1024 * 1024) {
        $error = 'File too large. Max 50MB.';
    } else {
        $uploadDir = sys_get_temp_dir() . '/supertools/';
        if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);

        $tmpName  = uniqid('wtopdf_') . '.' . $ext;
        $tmpPath  = $uploadDir . $tmpName;
        $pdfName  = uniqid('output_') . '.pdf';
        $pdfPath  = $uploadDir . $pdfName;

        move_uploaded_file($file['tmp_name'], $tmpPath);

        // LibreOffice ilə çevir (server-də quraşdırılmalıdır)
        $libreCmd = '';
        foreach (['/usr/bin/libreoffice', '/usr/bin/soffice', '/usr/local/bin/libreoffice'] as $path) {
            if (file_exists($path)) { $libreCmd = $path; break; }
        }

        if ($libreCmd) {
            $cmd = escapeshellcmd($libreCmd) .
                   ' --headless --convert-to pdf ' .
                   escapeshellarg($tmpPath) .
                   ' --outdir ' . escapeshellarg($uploadDir) . ' 2>&1';
            exec($cmd, $output, $code);

            $generatedPdf = $uploadDir . pathinfo($tmpName, PATHINFO_FILENAME) . '.pdf';
            if ($code === 0 && file_exists($generatedPdf)) {
                rename($generatedPdf, $pdfPath);
                $result = ['path' => $pdfPath, 'name' => pathinfo($file['name'], PATHINFO_FILENAME) . '.pdf'];
            } else {
                $error = 'Conversion failed. LibreOffice returned error. Please install LibreOffice on server.';
            }
        } else {
            // LibreOffice yoxdur — demo mode
            $error = 'demo';
        }

        @unlink($tmpPath);
    }
}

// PDF download
if (isset($_GET['download']) && $_GET['download']) {
    $safeName = basename($_GET['download']);
    $filePath = sys_get_temp_dir() . '/supertools/' . $safeName;
    if (file_exists($filePath) && preg_match('/^output_[a-f0-9]+\.pdf$/', $safeName)) {
        header('Content-Type: application/pdf');
        header('Content-Disposition: attachment; filename="' . ($_GET['filename'] ?? 'converted.pdf') . '"');
        header('Content-Length: ' . filesize($filePath));
        readfile($filePath);
        @unlink($filePath);
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Word to PDF Converter</title>
<meta name="description" content="Free online Word to PDF converter. Convert .doc and .docx files to PDF instantly.">
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:'DM Sans','Segoe UI',sans-serif;background:#fff;color:#111827;padding:28px 24px;max-width:640px;margin:0 auto;}
h1{font-size:22px;font-weight:800;color:#111827;margin-bottom:6px;}
.sub{font-size:14px;color:#6b7280;margin-bottom:24px;line-height:1.5;}
.drop{border:2px dashed #d1d5db;border-radius:12px;padding:48px 24px;text-align:center;cursor:pointer;transition:.2s;position:relative;background:#fafafa;}
.drop:hover,.drop.over{border-color:#6366f1;background:#f5f3ff;}
.drop-icon{font-size:44px;display:block;margin-bottom:10px;}
.drop-title{font-size:15px;font-weight:700;color:#374151;margin-bottom:4px;}
.drop-sub{font-size:12px;color:#9ca3af;}
input[type=file]{position:absolute;inset:0;opacity:0;cursor:pointer;width:100%;height:100%;}
.file-row{display:none;align-items:center;gap:12px;padding:12px 14px;background:#f9fafb;border:1px solid #e5e7eb;border-radius:9px;margin-top:12px;}
.file-row.show{display:flex;}
.file-icon{font-size:22px;flex-shrink:0;}
.file-name{font-size:13px;font-weight:600;color:#374151;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
.file-size{font-size:11px;color:#9ca3af;flex-shrink:0;}
.rm{background:none;border:none;color:#ef4444;cursor:pointer;font-size:18px;flex-shrink:0;padding:0 4px;}
.prog{height:5px;background:#e5e7eb;border-radius:3px;margin:14px 0;overflow:hidden;display:none;}
.prog-fill{height:100%;background:#6366f1;border-radius:3px;width:0%;transition:width .3s;}
.status{font-size:12px;color:#6b7280;text-align:center;min-height:18px;margin-bottom:4px;}
.btn{width:100%;padding:13px;background:#111827;color:#fff;border:none;border-radius:10px;font-size:14px;font-weight:700;cursor:pointer;transition:.2s;font-family:inherit;margin-top:4px;}
.btn:hover{background:#374151;}
.btn:disabled{opacity:.4;cursor:not-allowed;}
.result{display:none;text-align:center;padding:24px;background:#f0fdf4;border:1px solid #bbf7d0;border-radius:12px;margin-top:14px;}
.result.show{display:block;}
.result-icon{font-size:40px;margin-bottom:8px;}
.result-title{font-size:15px;font-weight:700;color:#166534;margin-bottom:4px;}
.result-sub{font-size:12px;color:#4ade80;margin-bottom:16px;}
.dl-btn{display:inline-flex;align-items:center;gap:8px;padding:11px 24px;background:#16a34a;color:#fff;border-radius:9px;font-weight:700;font-size:13px;text-decoration:none;border:none;cursor:pointer;font-family:inherit;transition:.2s;}
.dl-btn:hover{background:#15803d;}
.err{padding:11px 14px;background:#fef2f2;border:1px solid #fecaca;border-radius:9px;font-size:13px;color:#dc2626;margin-top:12px;}
.demo-note{padding:11px 14px;background:#fffbeb;border:1px solid #fde68a;border-radius:9px;font-size:12px;color:#92400e;margin-top:12px;line-height:1.6;}
.note{font-size:11px;color:#9ca3af;text-align:center;margin-top:16px;line-height:1.6;}
</style>
</head>
<body>
<h1>📄 Word to PDF</h1>
<div class="sub">Convert .doc and .docx files to PDF format. Free, fast, and secure.</div>

<?php if ($error === 'demo'): ?>
<div class="demo-note">
  ℹ️ <strong>LibreOffice not found on server.</strong><br>
  To enable real conversion: <code>sudo apt install libreoffice</code><br>
  Currently running in demo mode.
</div>
<?php elseif ($error): ?>
<div class="err">⚠️ <?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<?php if ($result): ?>
<div class="result show">
  <div class="result-icon">✅</div>
  <div class="result-title">PDF ready!</div>
  <div class="result-sub"><?= htmlspecialchars($result['name']) ?></div>
  <a href="?download=<?= urlencode(basename($result['path'])) ?>&filename=<?= urlencode($result['name']) ?>" class="dl-btn">⬇ Download PDF</a>
</div>
<?php endif; ?>

<form method="POST" enctype="multipart/form-data" id="upload-form">
  <div class="drop" id="drop-area">
    <span class="drop-icon">📝</span>
    <div class="drop-title">Select File or Drag & Drop</div>
    <div class="drop-sub">.doc, .docx — Max 50MB</div>
    <input type="file" name="file" id="file-input" accept=".doc,.docx" onchange="handleFile(this)">
  </div>

  <div class="file-row" id="file-row">
    <span class="file-icon">📄</span>
    <span class="file-name" id="file-name-lbl"></span>
    <span class="file-size" id="file-size-lbl"></span>
    <button type="button" class="rm" onclick="clearFile()">✕</button>
  </div>

  <div class="prog" id="prog"><div class="prog-fill" id="prog-fill"></div></div>
  <div class="status" id="status-lbl"></div>

  <button type="submit" class="btn" id="convert-btn" disabled onclick="startProgress()">
    Convert to PDF
  </button>
</form>

<div class="note">Files are processed on server and deleted after download.<br>We do not store your documents.</div>

<script>
const dropArea = document.getElementById('drop-area');

dropArea.addEventListener('dragover', e => { e.preventDefault(); dropArea.classList.add('over'); });
dropArea.addEventListener('dragleave', () => dropArea.classList.remove('over'));
dropArea.addEventListener('drop', e => {
  e.preventDefault(); dropArea.classList.remove('over');
  const f = e.dataTransfer.files[0];
  if (f) { document.getElementById('file-input').files = e.dataTransfer.files; handleFile(document.getElementById('file-input')); }
});

function handleFile(input) {
  const f = input.files[0];
  if (!f) return;
  if (!f.name.match(/\.(doc|docx)$/i)) { alert('Please select .doc or .docx file.'); return; }
  if (f.size > 50*1024*1024) { alert('Max 50MB.'); return; }
  document.getElementById('file-row').classList.add('show');
  document.getElementById('file-name-lbl').textContent = f.name;
  document.getElementById('file-size-lbl').textContent = fmt(f.size);
  document.getElementById('convert-btn').disabled = false;
}

function clearFile() {
  document.getElementById('file-input').value = '';
  document.getElementById('file-row').classList.remove('show');
  document.getElementById('convert-btn').disabled = true;
}

function startProgress() {
  const prog = document.getElementById('prog');
  const fill = document.getElementById('prog-fill');
  const status = document.getElementById('status-lbl');
  prog.style.display = 'block';
  let p = 0;
  const msgs = ['Uploading…','Processing document…','Generating PDF…','Almost done…'];
  const t = setInterval(() => {
    p = Math.min(p + 3, 90);
    fill.style.width = p + '%';
    status.textContent = msgs[Math.floor(p/25)] || msgs[3];
    if (p >= 90) clearInterval(t);
  }, 120);
}

function fmt(b) {
  if (b < 1024) return b + ' B';
  if (b < 1024*1024) return (b/1024).toFixed(1) + ' KB';
  return (b/(1024*1024)).toFixed(1) + ' MB';
}
</script>
</body>
</html>
