<?php
require_once __DIR__ . '/admin/includes/config.php';
UserAuth::start();
$lang = Lang::detect();
Lang::load($lang);

if (!UserAuth::check()) { header('Location: auth.php?action=login'); exit; }

$user = UserAuth::user();
$siteName   = ST_Settings::get('site_name', 'SuperTools');
$themeColor = ST_Settings::get('theme_color', '#6366f1');
$logoIcon   = ST_Settings::get('logo_icon', '⚡');

$error   = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $sub = $_POST['sub'] ?? '';
    if ($sub === 'name') {
        $name = sanitize($_POST['name'] ?? '');
        if ($name) {
            DB::query("UPDATE users SET name=?, lang=? WHERE id=?", [$name, $_POST['lang']??$lang, $user['id']]);
            $_SESSION['user_name'] = $name;
            $success = 'Profile updated!';
            $user = UserAuth::user();
        }
    } elseif ($sub === 'password') {
        $old = $_POST['old_password'] ?? '';
        $new = $_POST['new_password'] ?? '';
        if (!password_verify($old, $user['password'])) { $error = 'Current password is incorrect.'; }
        elseif (strlen($new) < 6) { $error = 'New password must be at least 6 characters.'; }
        else {
            DB::query("UPDATE users SET password=? WHERE id=?", [password_hash($new, PASSWORD_BCRYPT, ['cost'=>12]), $user['id']]);
            $success = 'Password updated!';
        }
    }
}

$transactions = DB::fetchAll("SELECT t.*, p.name plan_name FROM transactions t LEFT JOIN plans p ON p.id=t.plan_id WHERE t.user_id=? ORDER BY t.created_at DESC LIMIT 10", [$user['id']]);
$langs = Lang::getAll();
?>
<!DOCTYPE html>
<html lang="<?= esc($lang) ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Profile — <?= esc($siteName) ?></title>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=DM+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
:root{--accent:<?= esc($themeColor) ?>;--dark:#0f172a;--dark2:#1e293b;--border:#e5e7eb;--text:#111827;--muted:#6b7280;--bg:#fafafa;--surface:#fff;}
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:'DM Sans',sans-serif;background:var(--bg);color:var(--text);}
.navbar{background:var(--dark);padding:0 24px;height:64px;display:flex;align-items:center;gap:16px;position:sticky;top:0;z-index:10;}
.logo{display:flex;align-items:center;gap:10px;text-decoration:none;}
.logo-mark{width:34px;height:34px;background:var(--accent);border-radius:9px;display:flex;align-items:center;justify-content:center;font-size:16px;}
.logo-name{font-family:'Syne',sans-serif;font-size:18px;font-weight:800;color:#fff;}
.spacer{flex:1;}
.nav-link{color:rgba(255,255,255,.6);text-decoration:none;font-size:13px;padding:7px 12px;border-radius:8px;transition:.15s;}
.nav-link:hover{color:#fff;background:rgba(255,255,255,.08);}
.wrap{max-width:900px;margin:40px auto;padding:0 24px 60px;}
.page-title{font-family:'Syne',sans-serif;font-size:26px;font-weight:800;margin-bottom:28px;}
.grid{display:grid;grid-template-columns:260px 1fr;gap:20px;align-items:start;}
.card{background:var(--surface);border:1.5px solid var(--border);border-radius:14px;padding:24px;margin-bottom:16px;}
.avatar-big{width:72px;height:72px;background:var(--accent);border-radius:18px;display:flex;align-items:center;justify-content:center;font-size:28px;font-weight:800;color:#fff;margin:0 auto 14px;}
.user-name{font-family:'Syne',sans-serif;font-size:17px;font-weight:700;text-align:center;}
.user-email{font-size:12px;color:var(--muted);text-align:center;margin-top:4px;}
.plan-badge{display:inline-flex;align-items:center;gap:5px;background:var(--accent);color:#fff;border-radius:20px;padding:4px 12px;font-size:11px;font-weight:700;margin:12px auto 0;display:block;width:fit-content;}
.stat-row{display:flex;justify-content:space-between;font-size:13px;padding:9px 0;border-bottom:1px solid var(--border);}
.stat-row:last-child{border:none;}
.stat-k{color:var(--muted);}
.stat-v{font-weight:600;}
.logout-btn{display:flex;align-items:center;justify-content:center;gap:7px;width:100%;margin-top:14px;padding:10px;background:rgba(239,68,68,.08);color:#ef4444;border:1px solid rgba(239,68,68,.2);border-radius:9px;font-size:13px;font-weight:600;text-decoration:none;transition:.2s;}
.logout-btn:hover{background:rgba(239,68,68,.15);}
.card-title{font-size:15px;font-weight:700;margin-bottom:18px;display:flex;align-items:center;gap:8px;}
.form-group{margin-bottom:14px;}
label{display:block;font-size:11px;font-weight:700;color:var(--muted);text-transform:uppercase;letter-spacing:.5px;margin-bottom:6px;}
input,select{width:100%;padding:10px 14px;background:var(--bg);border:1.5px solid var(--border);border-radius:8px;font-family:'DM Sans',sans-serif;font-size:14px;outline:none;transition:.2s;color:var(--text);}
input:focus,select:focus{border-color:var(--accent);}
.btn-save{padding:10px 20px;background:var(--accent);color:#fff;border:none;border-radius:8px;font-family:'DM Sans',sans-serif;font-size:13px;font-weight:700;cursor:pointer;transition:.2s;}
.btn-save:hover{opacity:.9;}
.alert{padding:10px 14px;border-radius:8px;font-size:13px;margin-bottom:14px;display:flex;align-items:center;gap:8px;}
.alert.error{background:#fef2f2;border:1px solid #fecaca;color:#dc2626;}
.alert.success{background:#f0fdf4;border:1px solid #bbf7d0;color:#16a34a;}
.upgrade-cta{background:linear-gradient(135deg,var(--accent),color-mix(in srgb,var(--accent) 70%,#000));border-radius:14px;padding:24px;text-align:center;color:#fff;margin-bottom:16px;}
.upgrade-cta h3{font-family:'Syne',sans-serif;font-size:18px;font-weight:800;margin-bottom:6px;}
.upgrade-cta p{font-size:13px;opacity:.8;margin-bottom:16px;}
.btn-upgrade{display:inline-block;padding:10px 24px;background:rgba(255,255,255,.2);border:1px solid rgba(255,255,255,.3);border-radius:9px;color:#fff;font-weight:700;text-decoration:none;font-size:13px;}
table{width:100%;border-collapse:collapse;font-size:13px;}
th{padding:8px 12px;text-align:left;font-size:11px;font-weight:700;color:var(--muted);text-transform:uppercase;letter-spacing:.4px;border-bottom:1px solid var(--border);}
td{padding:11px 12px;border-bottom:1px solid rgba(0,0,0,.04);}
.badge{display:inline-flex;align-items:center;padding:3px 9px;border-radius:20px;font-size:11px;font-weight:700;}
.badge-green{background:#dcfce7;color:#16a34a;}.badge-yellow{background:#fef9c3;color:#a16207;}.badge-red{background:#fee2e2;color:#dc2626;}
@media(max-width:680px){.grid{grid-template-columns:1fr;}}
</style>
</head>
<body>
<nav class="navbar">
  <a href="index.php" class="logo">
    <div class="logo-mark"><?= esc($logoIcon) ?></div>
    <div class="logo-name"><?= esc($siteName) ?></div>
  </a>
  <div class="spacer"></div>
  <a href="index.php" class="nav-link">Home</a>
  <a href="auth.php?action=logout" class="nav-link" style="color:#f87171">Sign Out</a>
</nav>

<div class="wrap">
  <div class="page-title">👤 My Profile</div>
  <?php if($error): ?><div class="alert error">⚠️ <?= esc($error) ?></div><?php endif; ?>
  <?php if($success): ?><div class="alert success">✅ <?= esc($success) ?></div><?php endif; ?>

  <div class="grid">
    <!-- Left -->
    <div>
      <div class="card" style="text-align:center">
        <div class="avatar-big"><?= strtoupper(substr($user['name']??$user['email']??'U',0,1)) ?></div>
        <div class="user-name"><?= esc($user['name']??'User') ?></div>
        <div class="user-email"><?= esc($user['email']) ?></div>
        <div class="plan-badge">⚡ <?= esc($user['plan_name']??'Free') ?> Plan</div>
        <div class="stat-row" style="margin-top:16px"><span class="stat-k">Status</span><span class="stat-v" style="color:#16a34a">● Active</span></div>
        <div class="stat-row"><span class="stat-k">Joined</span><span class="stat-v"><?= date('M Y', strtotime($user['created_at'])) ?></span></div>
        <div class="stat-row"><span class="stat-k">Last Active</span><span class="stat-v"><?= $user['last_active'] ? date('d M Y', strtotime($user['last_active'])) : 'Today' ?></span></div>
        <a href="auth.php?action=logout" class="logout-btn">🚪 Sign Out</a>
      </div>

      <?php if(($user['plan_price']??0) <= 0): ?>
      <div class="upgrade-cta">
        <h3>⚡ Go Pro</h3>
        <p>Unlock all premium tools and features.</p>
        <a href="pricing.php" class="btn-upgrade">View Plans →</a>
      </div>
      <?php endif; ?>
    </div>

    <!-- Right -->
    <div>
      <!-- Edit Profile -->
      <div class="card">
        <div class="card-title">✏️ Edit Profile</div>
        <form method="POST">
          <input type="hidden" name="sub" value="name">
          <div class="form-group"><label>Full Name</label><input name="name" value="<?= esc($user['name']??'') ?>" placeholder="Your name"></div>
          <div class="form-group"><label>Email</label><input value="<?= esc($user['email']) ?>" readonly style="opacity:.5"></div>
          <div class="form-group">
            <label>Language</label>
            <select name="lang">
              <?php foreach($langs as $l): ?>
              <option value="<?= esc($l['code']) ?>" <?= $l['code']===$lang?'selected':'' ?>><?= esc($l['flag'].' '.$l['name']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <button class="btn-save">💾 Save Changes</button>
        </form>
      </div>

      <!-- Change Password -->
      <div class="card" id="billing">
        <div class="card-title">🔒 Change Password</div>
        <form method="POST">
          <input type="hidden" name="sub" value="password">
          <div class="form-group"><label>Current Password</label><input name="old_password" type="password" placeholder="••••••••"></div>
          <div class="form-group"><label>New Password</label><input name="new_password" type="password" placeholder="Min 6 characters"></div>
          <button class="btn-save">🔐 Update Password</button>
        </form>
      </div>

      <!-- Transactions -->
      <?php if(!empty($transactions)): ?>
      <div class="card">
        <div class="card-title">💳 Transaction History</div>
        <table>
          <thead><tr><th>Plan</th><th>Amount</th><th>Status</th><th>Date</th></tr></thead>
          <tbody>
            <?php foreach($transactions as $tx): ?>
            <tr>
              <td><?= esc($tx['plan_name']??'—') ?></td>
              <td style="font-weight:700">$<?= number_format($tx['amount'],2) ?></td>
              <td><span class="badge badge-<?= $tx['status']==='completed'?'green':($tx['status']==='pending'?'yellow':'red') ?>"><?= esc($tx['status']) ?></span></td>
              <td style="color:var(--muted)"><?= date('M j, Y', strtotime($tx['created_at'])) ?></td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
      <?php endif; ?>
    </div>
  </div>
</div>
</body>
</html>
