<?php
require_once __DIR__ . '/admin/includes/config.php';

// Language
UserAuth::start();
$lang = Lang::detect();
Lang::load($lang);
$langs = Lang::getAll();

// Site settings
$siteName    = ST_Settings::get('site_name', 'SuperTools');
$siteTagline = ST_Settings::get('site_tagline', 'Free Online Tools for Everyone');
$themeColor  = ST_Settings::get('theme_color', '#6366f1');
$logoIcon    = ST_Settings::get('logo_icon', '⚡');
$metaTitle   = ST_Settings::get('meta_title', $siteName);
$metaDesc    = ST_Settings::get('meta_description', $siteTagline);
$ogImage     = ST_Settings::get('og_image', '');
$gaId        = ST_Settings::get('google_analytics_id', '');

// Maintenance
if (ST_Settings::get('maintenance_mode') === '1' && !Auth::check()) {
    include __DIR__ . '/maintenance.php'; exit;
}

// Track view
track_view('/');

// Load categories + tools
$categories = DB::fetchAll("SELECT * FROM categories WHERE status=1 ORDER BY sort_order");
$featured   = DB::fetchAll("SELECT t.*, c.name cat_name, c.icon cat_icon FROM tools t LEFT JOIN categories c ON c.id=t.category_id WHERE t.status='active' AND t.is_featured=1 ORDER BY t.views_week DESC LIMIT 8");
$popular    = DB::fetchAll("SELECT t.*, c.name cat_name FROM tools t LEFT JOIN categories c ON c.id=t.category_id WHERE t.status='active' ORDER BY t.views_week DESC LIMIT 12");

// Current user
$currentUser = UserAuth::check() ? UserAuth::user() : null;

// Ads
$headerAd  = DB::fetch("SELECT code FROM advertisements WHERE slot='header' AND status=1 LIMIT 1");
$sidebarAd = DB::fetch("SELECT code FROM advertisements WHERE slot='sidebar' AND status=1 LIMIT 1");
?>
<!DOCTYPE html>
<html lang="<?= esc($lang) ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= esc($metaTitle) ?></title>
<meta name="description" content="<?= esc($metaDesc) ?>">
<meta property="og:title" content="<?= esc($metaTitle) ?>">
<meta property="og:description" content="<?= esc($metaDesc) ?>">
<?php if($ogImage): ?><meta property="og:image" content="<?= esc($ogImage) ?>"><?php endif; ?>
<meta name="theme-color" content="<?= esc($themeColor) ?>">
<?php if($gaId): ?>
<script async src="https://www.googletagmanager.com/gtag/js?id=<?= esc($gaId) ?>"></script>
<script>window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments)}gtag('js',new Date());gtag('config','<?= esc($gaId) ?>');</script>
<?php endif; ?>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;500;600;700;800&family=DM+Sans:ital,opsz,wght@0,9..40,100;0,9..40,200;0,9..40,300;0,9..40,400;0,9..40,500;0,9..40,600;0,9..40,700;0,9..40,800;0,9..40,900;1,9..40,300;1,9..40,400&display=swap" rel="stylesheet">
<style>
/* ── TİPOQRAFİYA SİSTEMİ ── */
:root {
  --font-display: 'Syne', sans-serif;
  --font-body:    'DM Sans', sans-serif;
  /* Ölçülər */
  --text-xs:   11px;
  --text-sm:   13px;
  --text-base: 15px;
  --text-md:   17px;
  --text-lg:   20px;
  --text-xl:   24px;
  --text-2xl:  30px;
  --text-3xl:  38px;
  --text-4xl:  52px;
  --text-5xl:  68px;
  /* Ağırlıqlar */
  --fw-thin:      100;
  --fw-light:     300;
  --fw-regular:   400;
  --fw-medium:    500;
  --fw-semibold:  600;
  --fw-bold:      700;
  --fw-extrabold: 800;
  --fw-black:     900;
  /* Sətir hündürlükləri */
  --lh-tight:   1.1;
  --lh-snug:    1.3;
  --lh-normal:  1.6;
  --lh-relaxed: 1.8;
}
:root {
  --accent: <?= esc($themeColor) ?>;
  --accent-dark: color-mix(in srgb, <?= esc($themeColor) ?> 80%, black);
  --bg: #fafafa;
  --bg2: #f3f4f6;
  --surface: #ffffff;
  --border: #e5e7eb;
  --text: #111827;
  --muted: #6b7280;
  --dark: #0f172a;
  --dark2: #1e293b;
  --radius: 14px;
  --shadow: 0 4px 24px rgba(0,0,0,.08);
  --shadow-lg: 0 16px 48px rgba(0,0,0,.12);
}

* { margin:0; padding:0; box-sizing:border-box; }
html { scroll-behavior: smooth; }
body {
  font-family: 'DM Sans', sans-serif;
  background: var(--bg);
  color: var(--text);
  line-height: 1.6;
}

/* ─── SCROLLBAR ─── */
::-webkit-scrollbar { width: 6px; }
::-webkit-scrollbar-track { background: var(--bg2); }
::-webkit-scrollbar-thumb { background: var(--accent); border-radius: 3px; }

/* ─── NAVBAR ─── */
.navbar {
  background: var(--dark);
  position: sticky;
  top: 0;
  z-index: 100;
  border-bottom: 1px solid rgba(255,255,255,.08);
}
.nav-inner {
  max-width: 1280px;
  margin: 0 auto;
  padding: 0 24px;
  height: 64px;
  display: flex;
  align-items: center;
  gap: 24px;
}
.nav-logo {
  display: flex;
  align-items: center;
  gap: 10px;
  text-decoration: none;
  flex-shrink: 0;
}
.logo-mark {
  width: 36px;
  height: 36px;
  background: var(--accent);
  border-radius: 9px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 18px;
}
.logo-name {
  font-family: 'Syne', sans-serif;
  font-size: 20px;
  font-weight: 800;
  color: #fff;
  letter-spacing: -.3px;
}
.nav-links {
  display: flex;
  align-items: center;
  gap: 4px;
  flex: 1;
  justify-content: center;
}
.nav-link {
  padding: 7px 14px;
  border-radius: 8px;
  text-decoration: none;
  font-size: 14px;
  font-weight: 500;
  color: rgba(255,255,255,.7);
  transition: .15s;
}
.nav-link:hover, .nav-link.active { color: #fff; background: rgba(255,255,255,.1); }
.nav-actions { display: flex; align-items: center; gap: 10px; }
.lang-btn {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 7px 12px;
  border-radius: 8px;
  background: rgba(255,255,255,.08);
  border: 1px solid rgba(255,255,255,.12);
  color: rgba(255,255,255,.8);
  font-size: 13px;
  font-weight: 500;
  cursor: pointer;
  position: relative;
  font-family: inherit;
}
.lang-dropdown {
  position: absolute;
  top: calc(100% + 8px);
  right: 0;
  background: var(--dark2);
  border: 1px solid rgba(255,255,255,.1);
  border-radius: 12px;
  min-width: 160px;
  box-shadow: 0 16px 40px rgba(0,0,0,.4);
  z-index: 200;
  display: none;
  overflow: hidden;
}
.lang-dropdown.open { display: block; }
.lang-item {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 10px 14px;
  font-size: 13px;
  color: rgba(255,255,255,.7);
  cursor: pointer;
  transition: .15s;
  text-decoration: none;
}
.lang-item:hover { background: rgba(255,255,255,.08); color: #fff; }
.lang-item.active { color: var(--accent); }
.btn-login {
  padding: 8px 16px;
  border-radius: 8px;
  background: rgba(255,255,255,.1);
  border: 1px solid rgba(255,255,255,.15);
  color: rgba(255,255,255,.85);
  font-size: 13px;
  font-weight: 600;
  text-decoration: none;
  transition: .15s;
}
.btn-login:hover { background: rgba(255,255,255,.18); color: #fff; }
.btn-signup {
  padding: 8px 18px;
  border-radius: 8px;
  background: var(--accent);
  color: #fff;
  font-size: 13px;
  font-weight: 700;
  text-decoration: none;
  transition: .15s;
}
.btn-signup:hover { opacity: .9; transform: translateY(-1px); }
.user-menu { position: relative; }
.user-avatar {
  width: 36px;
  height: 36px;
  border-radius: 50%;
  background: var(--accent);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 14px;
  font-weight: 700;
  color: #fff;
  cursor: pointer;
  border: 2px solid rgba(255,255,255,.2);
}
.user-dropdown {
  position: absolute;
  top: calc(100% + 10px);
  right: 0;
  background: #fff;
  border: 1px solid var(--border);
  border-radius: 14px;
  width: 220px;
  box-shadow: var(--shadow-lg);
  z-index: 200;
  display: none;
  overflow: hidden;
}
.user-dropdown.open { display: block; }
.ud-head {
  padding: 14px 16px;
  background: var(--bg2);
  border-bottom: 1px solid var(--border);
}
.ud-name { font-size: 14px; font-weight: 700; color: var(--text); }
.ud-email { font-size: 12px; color: var(--muted); margin-top: 2px; }
.ud-item {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 10px 16px;
  font-size: 13px;
  color: var(--text);
  text-decoration: none;
  transition: .15s;
}
.ud-item:hover { background: var(--bg2); }
.ud-divider { height: 1px; background: var(--border); }
.ud-item.danger { color: #ef4444; }

/* ─── HERO ─── */
.hero {
  background: var(--dark);
  padding: 80px 24px 60px;
  text-align: center;
  position: relative;
  overflow: hidden;
}
.hero::before {
  content: '';
  position: absolute;
  inset: 0;
  background: radial-gradient(ellipse 80% 60% at 50% 0%, color-mix(in srgb, var(--accent) 25%, transparent), transparent 70%);
  pointer-events: none;
}
.hero-inner { max-width: 800px; margin: 0 auto; position: relative; }
.hero-badge {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 5px 14px;
  background: rgba(255,255,255,.08);
  border: 1px solid rgba(255,255,255,.12);
  border-radius: 20px;
  font-size: 12px;
  font-weight: 600;
  color: rgba(255,255,255,.7);
  margin-bottom: 20px;
}
.hero h1 {
  font-family: 'Syne', sans-serif;
  font-size: clamp(32px, 6vw, 64px);
  font-weight: 800;
  color: #fff;
  line-height: 1.1;
  margin-bottom: 16px;
  letter-spacing: -1px;
}
.hero h1 span {
  background: linear-gradient(135deg, var(--accent), color-mix(in srgb, var(--accent) 60%, white));
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
}
.hero p {
  font-size: 18px;
  color: rgba(255,255,255,.6);
  margin-bottom: 36px;
  max-width: 560px;
  margin-left: auto;
  margin-right: auto;
}
.search-hero {
  max-width: 560px;
  margin: 0 auto;
  position: relative;
}
.search-hero input {
  width: 100%;
  padding: 16px 60px 16px 24px;
  background: rgba(255,255,255,.08);
  border: 1.5px solid rgba(255,255,255,.15);
  border-radius: 14px;
  color: #fff;
  font-family: 'DM Sans', sans-serif;
  font-size: 15px;
  outline: none;
  transition: .2s;
}
.search-hero input::placeholder { color: rgba(255,255,255,.4); }
.search-hero input:focus {
  background: rgba(255,255,255,.12);
  border-color: var(--accent);
  box-shadow: 0 0 0 4px color-mix(in srgb, var(--accent) 20%, transparent);
}
.search-icon {
  position: absolute;
  right: 16px;
  top: 50%;
  transform: translateY(-50%);
  color: rgba(255,255,255,.4);
  font-size: 20px;
  pointer-events: none;
}
.hero-stats {
  display: flex;
  justify-content: center;
  gap: 40px;
  margin-top: 40px;
  padding-top: 40px;
  border-top: 1px solid rgba(255,255,255,.08);
}
.hero-stat-num {
  font-family: 'Syne', sans-serif;
  font-size: 28px;
  font-weight: 800;
  color: #fff;
}
.hero-stat-label { font-size: 13px; color: rgba(255,255,255,.5); margin-top: 2px; }

/* ─── AD BANNER ─── */
.ad-banner {
  max-width: 1280px;
  margin: 24px auto 0;
  padding: 0 24px;
  text-align: center;
}

/* ─── SECTION ─── */
.section {
  max-width: 1280px;
  margin: 0 auto;
  padding: 48px 24px;
}
.section-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 28px;
}
.section-title {
  font-family: 'Syne', sans-serif;
  font-size: 22px;
  font-weight: 800;
  color: var(--text);
  display: flex;
  align-items: center;
  gap: 10px;
}
.section-link {
  font-size: 13px;
  font-weight: 600;
  color: var(--accent);
  text-decoration: none;
}
.section-link:hover { text-decoration: underline; }

/* ─── CATEGORIES ─── */
.cats-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
  gap: 12px;
  margin-bottom: 48px;
}
.cat-card {
  padding: 20px 16px;
  background: var(--surface);
  border: 1.5px solid var(--border);
  border-radius: var(--radius);
  cursor: pointer;
  transition: .2s;
  text-decoration: none;
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
  gap: 10px;
}
.cat-card:hover {
  border-color: var(--accent);
  transform: translateY(-2px);
  box-shadow: var(--shadow);
}
.cat-icon-wrap {
  width: 48px;
  height: 48px;
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 22px;
}
.cat-name { font-size: 13px; font-weight: 700; color: var(--text); }
.cat-count { font-size: 11px; color: var(--muted); }

/* ─── TOOLS GRID ─── */
.tools-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
  gap: 14px;
}
.tool-card {
  background: var(--surface);
  border: 1.5px solid var(--border);
  border-radius: var(--radius);
  padding: 20px 16px;
  cursor: pointer;
  transition: .2s;
  text-decoration: none;
  display: flex;
  flex-direction: column;
  gap: 10px;
  position: relative;
  overflow: hidden;
}
.tool-card::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 3px;
  background: var(--accent);
  transform: scaleX(0);
  transition: transform .2s;
}
.tool-card:hover {
  border-color: var(--accent);
  transform: translateY(-3px);
  box-shadow: var(--shadow-lg);
}
.tool-card:hover::before { transform: scaleX(1); }
.tool-icon-wrap {
  width: 44px;
  height: 44px;
  border-radius: 10px;
  background: var(--bg2);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 22px;
}
.tool-name { font-size: 14px; font-weight: 700; color: var(--text); }
.tool-desc { font-size: 12px; color: var(--muted); line-height: 1.5; flex: 1; }
.tool-meta {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-top: 4px;
}
.tool-cat-badge {
  font-size: 10px;
  font-weight: 600;
  padding: 2px 8px;
  border-radius: 20px;
  background: var(--bg2);
  color: var(--muted);
}
.tool-views { font-size: 11px; color: var(--muted); }
.tool-premium-badge {
  position: absolute;
  top: 10px;
  right: 10px;
  font-size: 10px;
  font-weight: 700;
  padding: 2px 7px;
  background: linear-gradient(135deg, #f59e0b, #d97706);
  color: #fff;
  border-radius: 20px;
}
.tool-new-badge {
  position: absolute;
  top: 10px;
  right: 10px;
  font-size: 10px;
  font-weight: 700;
  padding: 2px 7px;
  background: linear-gradient(135deg, #10b981, #059669);
  color: #fff;
  border-radius: 20px;
}

/* ─── ALL TOOLS SECTION ─── */
.all-tools-wrap {
  max-width: 1280px;
  margin: 0 auto;
  padding: 0 24px 60px;
}
.cat-section { margin-bottom: 48px; }
.cat-section-header {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 20px;
  padding-bottom: 12px;
  border-bottom: 2px solid var(--border);
}
.cat-section-icon {
  width: 40px;
  height: 40px;
  border-radius: 10px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 20px;
}
.cat-section-name {
  font-family: 'Syne', sans-serif;
  font-size: 18px;
  font-weight: 700;
  color: var(--text);
}
.cat-section-count {
  font-size: 12px;
  color: var(--muted);
  background: var(--bg2);
  padding: 2px 8px;
  border-radius: 20px;
  margin-left: 4px;
}

/* ─── SEARCH RESULTS ─── */
#search-results {
  display: none;
  max-width: 1280px;
  margin: 0 auto;
  padding: 24px;
}
#search-results.show { display: block; }
.no-results {
  text-align: center;
  padding: 60px 20px;
  color: var(--muted);
  font-size: 15px;
}
.no-results-icon { font-size: 48px; margin-bottom: 12px; }

/* ─── PRICING SECTION ─── */
.pricing-section {
  background: var(--dark);
  padding: 64px 24px;
}
.pricing-inner { max-width: 1000px; margin: 0 auto; }
.pricing-title {
  font-family: 'Syne', sans-serif;
  font-size: 32px;
  font-weight: 800;
  color: #fff;
  text-align: center;
  margin-bottom: 8px;
}
.pricing-sub {
  text-align: center;
  color: rgba(255,255,255,.5);
  margin-bottom: 40px;
}
.plans-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
  gap: 20px;
}
.plan-card {
  background: rgba(255,255,255,.05);
  border: 1.5px solid rgba(255,255,255,.1);
  border-radius: 18px;
  padding: 28px 24px;
  position: relative;
  overflow: hidden;
}
.plan-card.popular {
  border-color: var(--accent);
  background: rgba(99,102,241,.1);
}
.plan-popular-badge {
  position: absolute;
  top: -1px;
  left: 50%;
  transform: translateX(-50%);
  background: var(--accent);
  color: #fff;
  font-size: 11px;
  font-weight: 700;
  padding: 4px 16px;
  border-radius: 0 0 10px 10px;
}
.plan-name {
  font-family: 'Syne', sans-serif;
  font-size: 18px;
  font-weight: 700;
  color: #fff;
  margin-top: 8px;
}
.plan-price {
  font-family: 'Syne', sans-serif;
  font-size: 40px;
  font-weight: 900;
  color: var(--accent);
  margin: 12px 0 4px;
}
.plan-price span { font-size: 16px; color: rgba(255,255,255,.4); font-weight: 400; }
.plan-features { list-style: none; margin: 20px 0; }
.plan-features li {
  font-size: 13px;
  color: rgba(255,255,255,.7);
  padding: 5px 0;
  display: flex;
  align-items: center;
  gap: 8px;
}
.plan-features li::before { content: '✓'; color: var(--accent); font-weight: 700; }
.btn-plan {
  display: block;
  width: 100%;
  padding: 12px;
  border-radius: 10px;
  font-family: 'DM Sans', sans-serif;
  font-size: 14px;
  font-weight: 700;
  text-align: center;
  text-decoration: none;
  transition: .2s;
  border: none;
  cursor: pointer;
}
.btn-plan.primary { background: var(--accent); color: #fff; }
.btn-plan.primary:hover { opacity: .9; transform: translateY(-1px); }
.btn-plan.secondary {
  background: rgba(255,255,255,.08);
  border: 1px solid rgba(255,255,255,.15);
  color: rgba(255,255,255,.8);
}
.btn-plan.secondary:hover { background: rgba(255,255,255,.14); }

/* ─── FOOTER ─── */
.footer {
  background: var(--dark2);
  border-top: 1px solid rgba(255,255,255,.06);
  padding: 40px 24px 24px;
}
.footer-inner {
  max-width: 1280px;
  margin: 0 auto;
  display: grid;
  grid-template-columns: 2fr 1fr 1fr 1fr;
  gap: 40px;
  margin-bottom: 32px;
}
.footer-brand { }
.footer-logo { display: flex; align-items: center; gap: 10px; margin-bottom: 12px; }
.footer-logo-mark {
  width: 32px; height: 32px; background: var(--accent);
  border-radius: 8px; display: flex; align-items: center;
  justify-content: center; font-size: 16px;
}
.footer-logo-name { font-family:'Syne',sans-serif; font-size:18px; font-weight:800; color:#fff; }
.footer-desc { font-size: 13px; color: rgba(255,255,255,.4); line-height: 1.7; }
.footer-col h4 { font-size: 13px; font-weight: 700; color: rgba(255,255,255,.6); text-transform: uppercase; letter-spacing: .6px; margin-bottom: 14px; }
.footer-col a { display: block; font-size: 13px; color: rgba(255,255,255,.5); text-decoration: none; margin-bottom: 8px; transition: .15s; }
.footer-col a:hover { color: #fff; }
.footer-bottom {
  border-top: 1px solid rgba(255,255,255,.06);
  padding-top: 20px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  max-width: 1280px;
  margin: 0 auto;
}
.footer-copy { font-size: 12px; color: rgba(255,255,255,.3); }
.footer-links { display: flex; gap: 20px; }
.footer-links a { font-size: 12px; color: rgba(255,255,255,.3); text-decoration: none; }
.footer-links a:hover { color: rgba(255,255,255,.7); }

/* ─── MOBILE MENU ─── */
.hamburger {
  display: none;
  background: none;
  border: none;
  cursor: pointer;
  padding: 6px;
  color: rgba(255,255,255,.8);
}
.mobile-menu {
  display: none;
  position: fixed;
  inset: 0;
  background: var(--dark);
  z-index: 300;
  flex-direction: column;
  padding: 24px;
}
.mobile-menu.open { display: flex; }
.mobile-menu-close {
  align-self: flex-end;
  background: none;
  border: none;
  color: rgba(255,255,255,.7);
  font-size: 24px;
  cursor: pointer;
  margin-bottom: 32px;
}
.mobile-link {
  font-size: 22px;
  font-weight: 700;
  color: rgba(255,255,255,.8);
  text-decoration: none;
  padding: 14px 0;
  border-bottom: 1px solid rgba(255,255,255,.06);
  font-family: 'Syne', sans-serif;
}

/* ─── RESPONSIVE ─── */
@media (max-width: 768px) {
  .nav-links { display: none; }
  .hamburger { display: block; }
  .btn-login, .btn-signup { display: none; }
  .hero { padding: 50px 20px 40px; }
  .hero-stats { gap: 24px; flex-wrap: wrap; }
  .cats-grid { grid-template-columns: repeat(3, 1fr); }
  .tools-grid { grid-template-columns: repeat(2, 1fr); }
  .footer-inner { grid-template-columns: 1fr 1fr; gap: 24px; }
  .footer-brand { grid-column: 1 / -1; }
  .plans-grid { grid-template-columns: 1fr; }
  .footer-bottom { flex-direction: column; gap: 12px; text-align: center; }
}
@media (max-width: 480px) {
  .cats-grid { grid-template-columns: repeat(2, 1fr); }
  .tools-grid { grid-template-columns: 1fr; }
}

/* ─── TOAST ─── */
#toast { position:fixed; bottom:24px; right:24px; z-index:999; display:flex; flex-direction:column; gap:8px; }
.toast-msg {
  background: var(--dark2);
  color: #fff;
  padding: 12px 18px;
  border-radius: 10px;
  font-size: 13px;
  font-weight: 600;
  box-shadow: var(--shadow-lg);
  animation: slideIn .25s ease;
  display: flex;
  align-items: center;
  gap: 8px;
}
@keyframes slideIn { from{opacity:0;transform:translateX(20px)} to{opacity:1;transform:none} }
</style>
</head>
<body>

<!-- ── NAVBAR ── -->
<nav class="navbar">
  <div class="nav-inner">
    <a href="index.php" class="nav-logo">
      <div class="logo-mark"><?= esc($logoIcon) ?></div>
      <div class="logo-name"><?= esc($siteName) ?></div>
    </a>

    <div class="nav-links">
      <a href="index.php" class="nav-link active">Home</a>
      <a href="blog.php" class="nav-link">Blog</a>
      <a href="pricing.php" class="nav-link">Pricing</a>
      <a href="pages.php?slug=about" class="nav-link">About</a>
      <a href="pages.php?slug=contact" class="nav-link">Contact</a>
    </div>

    <div class="nav-actions">
      <!-- Language Switcher -->
      <div style="position:relative">
        <button class="lang-btn" onclick="toggleLang()" id="lang-btn">
          <?php foreach($langs as $l): if($l['code']===$lang): ?>
          <?= esc($l['flag']) ?> <?= esc(strtoupper($l['code'])) ?> ▾
          <?php endif; endforeach; ?>
        </button>
        <div class="lang-dropdown" id="lang-dd">
          <?php foreach($langs as $l): ?>
          <a href="?lang=<?= esc($l['code']) ?>" class="lang-item <?= $l['code']===$lang?'active':'' ?>">
            <?= esc($l['flag']) ?> <?= esc($l['name']) ?>
          </a>
          <?php endforeach; ?>
        </div>
      </div>

      <?php if ($currentUser): ?>
      <div class="user-menu">
        <div class="user-avatar" onclick="toggleUserDd()" id="user-avatar-btn">
          <?= strtoupper(substr($currentUser['name'] ?? $currentUser['email'] ?? 'U', 0, 1)) ?>
        </div>
        <div class="user-dropdown" id="user-dd">
          <div class="ud-head">
            <div class="ud-name"><?= esc($currentUser['name'] ?? '') ?></div>
            <div class="ud-email"><?= esc($currentUser['email']) ?></div>
          </div>
          <a href="profile.php" class="ud-item">👤 Profile</a>
          <a href="profile.php#billing" class="ud-item">💳 Billing</a>
          <div class="ud-divider"></div>
          <a href="auth.php?action=logout" class="ud-item danger">🚪 Sign Out</a>
        </div>
      </div>
      <?php else: ?>
      <a href="auth.php?action=login" class="btn-login">Log in</a>
      <a href="auth.php?action=register" class="btn-signup">Get Started →</a>
      <?php endif; ?>

      <button class="hamburger" onclick="openMobileMenu()">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round">
          <line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="18" x2="21" y2="18"/>
        </svg>
      </button>
    </div>
  </div>
</nav>

<!-- ── MOBILE MENU ── -->
<div class="mobile-menu" id="mobile-menu">
  <button class="mobile-menu-close" onclick="closeMobileMenu()">✕</button>
  <a href="index.php" class="mobile-link">Home</a>
  <a href="blog.php" class="mobile-link">Blog</a>
  <a href="pricing.php" class="mobile-link">Pricing</a>
  <a href="pages.php?slug=about" class="mobile-link">About</a>
  <?php if($currentUser): ?>
  <a href="profile.php" class="mobile-link">Profile</a>
  <a href="auth.php?action=logout" class="mobile-link">Sign Out</a>
  <?php else: ?>
  <a href="auth.php?action=login" class="mobile-link">Log in</a>
  <a href="auth.php?action=register" class="mobile-link">Get Started</a>
  <?php endif; ?>
</div>

<!-- ── HERO ── -->
<section class="hero">
  <div class="hero-inner">
    <div class="hero-badge">⚡ <?= count($categories) ?>+ Tool Categories</div>
    <h1>
      Digital <span>Tools Portal</span><br>
      For Everyone
    </h1>
    <p>Free online tools for text, documents, images, SEO, and more. Fast, simple, and powerful.</p>
    <div class="search-hero">
      <input type="text" id="search-input" placeholder="Search tools… (e.g. PDF, Image, SEO)" autocomplete="off" oninput="searchTools(this.value)">
      <span class="search-icon">🔍</span>
    </div>
    <div class="hero-stats">
      <div>
        <div class="hero-stat-num"><?= number_format(DB::fetch("SELECT COUNT(*) c FROM tools WHERE status='active'")['c'] ?? 0) ?>+</div>
        <div class="hero-stat-label">Free Tools</div>
      </div>
      <div>
        <div class="hero-stat-num"><?= number_format(DB::fetch("SELECT SUM(views) s FROM tools")['s'] ?? 0) ?>+</div>
        <div class="hero-stat-label">Total Uses</div>
      </div>
      <div>
        <div class="hero-stat-num"><?= number_format(DB::fetch("SELECT COUNT(*) c FROM users")['c'] ?? 0) ?>+</div>
        <div class="hero-stat-label">Users</div>
      </div>
      <div>
        <div class="hero-stat-num">100%</div>
        <div class="hero-stat-label">Free Forever</div>
      </div>
    </div>
  </div>
</section>

<!-- ── AD BANNER ── -->
<?php if($headerAd): ?>
<div class="ad-banner"><?= $headerAd['code'] ?></div>
<?php endif; ?>

<!-- ── SEARCH RESULTS (hidden by default) ── -->
<div id="search-results">
  <div class="section-header">
    <div class="section-title">🔍 Search Results: <span id="search-query-label"></span></div>
    <a href="#" class="section-link" onclick="clearSearch();return false">Clear</a>
  </div>
  <div class="tools-grid" id="search-tools-grid"></div>
  <div class="no-results" id="no-results" style="display:none">
    <div class="no-results-icon">😕</div>
    <div>No tools found for your search.</div>
  </div>
</div>

<!-- ── MAIN CONTENT (hidden during search) ── -->
<div id="main-content">

  <!-- Categories -->
  <div class="section">
    <div class="section-header">
      <div class="section-title">📁 Browse by Category</div>
    </div>
    <div class="cats-grid">
      <?php foreach($categories as $cat):
        $toolCount = DB::fetch("SELECT COUNT(*) c FROM tools WHERE category_id=? AND status='active'", [$cat['id']])['c'] ?? 0;
      ?>
      <a href="#cat-<?= esc($cat['slug']) ?>" class="cat-card" onclick="scrollToCat('<?= esc($cat['slug']) ?>')">
        <div class="cat-icon-wrap" style="background:<?= esc($cat['color']) ?>22">
          <?= esc($cat['icon']) ?>
        </div>
        <div class="cat-name"><?= esc($cat['name']) ?></div>
        <div class="cat-count"><?= $toolCount ?> tools</div>
      </a>
      <?php endforeach; ?>
    </div>
  </div>

  <!-- Featured Tools -->
  <?php if(!empty($featured)): ?>
  <div class="section" style="padding-top:0">
    <div class="section-header">
      <div class="section-title">⭐ Featured Tools</div>
      <a href="#all-tools" class="section-link">View all →</a>
    </div>
    <div class="tools-grid">
      <?php foreach($featured as $tool): ?>
      <a href="tool.php?slug=<?= esc($tool['slug']) ?>" class="tool-card">
        <?php if($tool['is_premium']): ?>
        <span class="tool-premium-badge">PRO</span>
        <?php endif; ?>
        <div class="tool-icon-wrap"><?= esc($tool['icon']) ?></div>
        <div class="tool-name"><?= esc($tool['name']) ?></div>
        <div class="tool-desc"><?= esc(substr($tool['description']??'',0,60)) ?>...</div>
        <div class="tool-meta">
          <span class="tool-cat-badge"><?= esc($tool['cat_icon'].' '.$tool['cat_name']) ?></span>
          <span class="tool-views"><?= number_format($tool['views_week']) ?> uses</span>
        </div>
      </a>
      <?php endforeach; ?>
    </div>
  </div>
  <?php endif; ?>

  <!-- All Tools by Category -->
  <div class="all-tools-wrap" id="all-tools">
    <?php foreach($categories as $cat):
      $tools = DB::fetchAll("SELECT * FROM tools WHERE category_id=? AND status='active' ORDER BY sort_order,views_week DESC", [$cat['id']]);
      if(empty($tools)) continue;
    ?>
    <div class="cat-section" id="cat-<?= esc($cat['slug']) ?>">
      <div class="cat-section-header">
        <div class="cat-section-icon" style="background:<?= esc($cat['color']) ?>22">
          <?= esc($cat['icon']) ?>
        </div>
        <div class="cat-section-name"><?= esc($cat['name']) ?></div>
        <span class="cat-section-count"><?= count($tools) ?></span>
      </div>
      <div class="tools-grid">
        <?php foreach($tools as $tool): ?>
        <a href="tool.php?slug=<?= esc($tool['slug']) ?>" class="tool-card">
          <?php if($tool['is_premium']): ?>
          <span class="tool-premium-badge">PRO</span>
          <?php endif; ?>
          <div class="tool-icon-wrap"><?= esc($tool['icon']) ?></div>
          <div class="tool-name"><?= esc($tool['name']) ?></div>
          <div class="tool-desc"><?= esc(substr($tool['description']??'',0,60)) ?>...</div>
          <div class="tool-meta">
            <span class="tool-views">👁 <?= number_format($tool['views_week']) ?></span>
          </div>
        </a>
        <?php endforeach; ?>
      </div>
    </div>
    <?php endforeach; ?>
  </div>

</div><!-- /main-content -->

<!-- ── PRICING ── -->
<?php
$plans = DB::fetchAll("SELECT * FROM plans WHERE status=1 ORDER BY sort_order");
if(!empty($plans)):
?>
<section class="pricing-section">
  <div class="pricing-inner">
    <div class="pricing-title">Simple, Transparent Pricing</div>
    <div class="pricing-sub">Start free. Upgrade when you need more.</div>
    <div class="plans-grid">
      <?php foreach($plans as $plan):
        $features = json_decode($plan['features']??'[]', true) ?: [];
      ?>
      <div class="plan-card <?= $plan['is_popular']?'popular':'' ?>">
        <?php if($plan['is_popular']): ?>
        <div class="plan-popular-badge">⭐ POPULAR</div>
        <?php endif; ?>
        <div class="plan-name"><?= esc($plan['name']) ?></div>
        <div class="plan-price">
          $<?= number_format($plan['price'],2) ?>
          <span>/<?= esc($plan['billing_cycle']) ?></span>
        </div>
        <ul class="plan-features">
          <?php foreach($features as $f): ?>
          <li><?= esc($f) ?></li>
          <?php endforeach; ?>
        </ul>
        <?php if($currentUser): ?>
        <a href="billing.php?plan=<?= $plan['id'] ?>" class="btn-plan <?= $plan['is_popular']?'primary':'secondary' ?>">
          <?= $plan['price']>0?'Upgrade Now':'Current Plan' ?>
        </a>
        <?php else: ?>
        <a href="auth.php?action=register&plan=<?= $plan['id'] ?>" class="btn-plan <?= $plan['is_popular']?'primary':'secondary' ?>">
          <?= $plan['price']>0?'Get Started':'Start Free' ?>
        </a>
        <?php endif; ?>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>
<?php endif; ?>

<!-- ── FOOTER ── -->
<?php
$footerPages = DB::fetchAll("SELECT title,slug FROM pages WHERE status='published' LIMIT 6");
$footerText  = ST_Settings::get('footer_text', '© '.date('Y').' '.$siteName);
?>
<footer class="footer">
  <div class="footer-inner">
    <div class="footer-brand">
      <div class="footer-logo">
        <div class="footer-logo-mark"><?= esc($logoIcon) ?></div>
        <div class="footer-logo-name"><?= esc($siteName) ?></div>
      </div>
      <p class="footer-desc"><?= esc($siteTagline) ?></p>
    </div>
    <div class="footer-col">
      <h4>Tools</h4>
      <?php foreach(array_slice($categories,0,5) as $c): ?>
      <a href="#cat-<?= esc($c['slug']) ?>"><?= esc($c['icon'].' '.$c['name']) ?></a>
      <?php endforeach; ?>
    </div>
    <div class="footer-col">
      <h4>Company</h4>
      <a href="blog.php">Blog</a>
      <a href="pricing.php">Pricing</a>
      <a href="pages.php?slug=about">About</a>
      <a href="pages.php?slug=contact">Contact</a>
    </div>
    <div class="footer-col">
      <h4>Legal</h4>
      <?php foreach($footerPages as $fp): ?>
      <a href="pages.php?slug=<?= esc($fp['slug']) ?>"><?= esc($fp['title']) ?></a>
      <?php endforeach; ?>
      <a href="pages.php?slug=privacy">Privacy Policy</a>
      <a href="pages.php?slug=terms">Terms of Use</a>
    </div>
  </div>
  <div class="footer-bottom">
    <div class="footer-copy"><?= esc($footerText) ?></div>
    <div class="footer-links">
      <?php foreach($langs as $l): ?>
      <a href="?lang=<?= esc($l['code']) ?>"><?= esc($l['flag'].' '.$l['name']) ?></a>
      <?php endforeach; ?>
    </div>
  </div>
</footer>

<div id="toast"></div>

<script>
// ── All tools data for search ──
const allTools = <?= json_encode(DB::fetchAll("SELECT t.id,t.name,t.slug,t.icon,t.description,t.is_premium,t.views_week,c.name cat_name,c.icon cat_icon FROM tools t LEFT JOIN categories c ON c.id=t.category_id WHERE t.status='active' ORDER BY t.views_week DESC")) ?>;

// ── Lang dropdown ──
function toggleLang(){document.getElementById('lang-dd').classList.toggle('open');}
document.addEventListener('click',e=>{if(!e.target.closest('#lang-btn'))document.getElementById('lang-dd').classList.remove('open');});

// ── User dropdown ──
function toggleUserDd(){document.getElementById('user-dd').classList.toggle('open');}
document.addEventListener('click',e=>{if(!e.target.closest('.user-menu'))document.getElementById('user-dd')?.classList.remove('open');});

// ── Mobile menu ──
function openMobileMenu(){document.getElementById('mobile-menu').classList.add('open');}
function closeMobileMenu(){document.getElementById('mobile-menu').classList.remove('open');}

// ── Search ──
let searchTimer;
function searchTools(q){
  clearTimeout(searchTimer);
  searchTimer=setTimeout(()=>{
    const query=q.trim().toLowerCase();
    const sr=document.getElementById('search-results');
    const mc=document.getElementById('main-content');
    const grid=document.getElementById('search-tools-grid');
    const noRes=document.getElementById('no-results');
    const label=document.getElementById('search-query-label');
    if(!query){clearSearch();return;}
    const results=allTools.filter(t=>
      t.name.toLowerCase().includes(query)||
      (t.description||'').toLowerCase().includes(query)||
      (t.cat_name||'').toLowerCase().includes(query)
    );
    label.textContent='"'+q+'"';
    sr.classList.add('show');
    mc.style.display='none';
    if(results.length){
      noRes.style.display='none';
      grid.innerHTML=results.map(t=>`
        <a href="tool.php?slug=${t.slug}" class="tool-card">
          ${t.is_premium?'<span class="tool-premium-badge">PRO</span>':''}
          <div class="tool-icon-wrap">${t.icon||'🔧'}</div>
          <div class="tool-name">${esc(t.name)}</div>
          <div class="tool-desc">${esc((t.description||'').substring(0,60))}...</div>
          <div class="tool-meta">
            <span class="tool-cat-badge">${esc((t.cat_icon||'')+(t.cat_name||''))}</span>
            <span class="tool-views">👁 ${(+t.views_week||0).toLocaleString()}</span>
          </div>
        </a>`).join('');
    } else {
      grid.innerHTML='';
      noRes.style.display='block';
    }
  },200);
}

function clearSearch(){
  document.getElementById('search-input').value='';
  document.getElementById('search-results').classList.remove('show');
  document.getElementById('main-content').style.display='';
}

function scrollToCat(slug){
  const el=document.getElementById('cat-'+slug);
  if(el){setTimeout(()=>el.scrollIntoView({behavior:'smooth',block:'start'}),50);}
}

function esc(s){return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');}

// ── Toast ──
function toast(msg,type='info'){
  const t=document.createElement('div');
  t.className='toast-msg';
  t.textContent=msg;
  document.getElementById('toast').appendChild(t);
  setTimeout(()=>t.remove(),3500);
}
</script>
</body>
</html>
